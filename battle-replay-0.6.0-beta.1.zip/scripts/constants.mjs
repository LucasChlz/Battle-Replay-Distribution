export const MODULE_ID = "battle-replay";
export const MODULE_TITLE = "Battle Replay";
export const REPLAY_SCHEMA_VERSION = 2;
export const TOOL_ID = "battle-replay-library";
export const DIALOG_ID = "battle-replay-library-dialog";
export const SOCKET_CHANNEL = `module.${MODULE_ID}`;

export const SETTINGS = Object.freeze({
  ACTIVE_RECORDING: "activeRecording",
  AUTO_RECORD: "autoRecord",
  CHECKPOINT_INTERVAL: "checkpointInterval",
  CINEMATIC_ENABLED: "cinematicEnabled",
  CINEMATIC_PRESET: "cinematicPreset",
  CREATOR_FORMAT: "creatorFormat",
  DATA_FOLDER_ID: "dataFolderId",
  LIBRARY_THEME: "libraryTheme",
  MAX_REPLAYS: "maxReplays",
  PLAYBACK_SPEED: "playbackSpeed",
  REPLAYS: "replays",
  STORAGE_VERSION: "storageVersion"
});

export const LIMITS = Object.freeze({
  MAX_EVENTS_PER_REPLAY: 25_000,
  MIN_REPLAYS: 1,
  MAX_REPLAYS: 500,
  MAX_IMPORT_BYTES: 10_000_000,
  MIN_CHECKPOINT_INTERVAL: 1,
  MAX_CHECKPOINT_INTERVAL: 100
});

export const RECORDING_MODES = Object.freeze({
  AUTOMATIC: "automatic",
  MANUAL: "manual"
});

export const LIBRARY_THEMES = Object.freeze({
  AUTO: "auto",
  DARK: "dark",
  LIGHT: "light"
});

export const CINEMATIC_PRESETS = Object.freeze({
  OFF: "off",
  TACTICAL: "tactical",
  CINEMATIC: "cinematic",
  CREATOR: "creator"
});

export const CREATOR_FORMATS = Object.freeze({
  AUTO: "auto",
  LANDSCAPE: "landscape",
  VERTICAL: "vertical"
});

export const STORAGE_VERSION = 2;
export const DATA_FOLDER_NAME = ".Battle Replay Data";
