import { LIMITS, SOCKET_CHANNEL } from "./constants.mjs";
import { normalizeCinematicPreset, normalizeCreatorFormat } from "./cinematic-director.mjs";
import { FEATURES } from "./entitlements.mjs";
import { createId, localize, warn } from "./utils.mjs";

export const LIVE_REPLAY_PACKET = "live-replay";

export const LIVE_REPLAY_ACTIONS = Object.freeze({
  HELLO: "hello",
  START: "start",
  STATE: "state",
  STOP: "stop"
});

/**
 * Keeps one GM-owned playback session synchronized across connected clients.
 * Replay data is sent ephemerally over Foundry's module socket and is never
 * persisted in a player's world data.
 */
export class LiveReplayController {
  constructor({ playback, entitlements = null } = {}) {
    this.playback = playback;
    this.entitlements = entitlements ?? { can: () => true };
    this.session = null;
    this.boundSocketHandler = (packet) => void this.receive(packet);
  }

  get isHosting() {
    return Boolean(this.session?.role === "host");
  }

  get status() {
    return Object.freeze({
      active: Boolean(this.session),
      hostUserId: this.session?.hostUserId ?? null,
      replayId: this.session?.replay?.id ?? null,
      role: this.session?.role ?? null,
      sessionId: this.session?.id ?? null
    });
  }

  initialize() {
    game.socket?.on?.(SOCKET_CHANNEL, this.boundSocketHandler);
    this.requestSync();
  }

  requestSync() {
    if (game.user?.isGM) return false;
    this.emit(LIVE_REPLAY_ACTIONS.HELLO);
    return true;
  }

  start(replay) {
    if (!game.user?.isGM || !replay || !this.entitlements.can(FEATURES.LIVE_SHARING) ||
      !this.canDisplay(replay)) return false;

    if (this.session) this.stop();
    const sharedReplay = prepareSharedReplay(replay);
    if (!sharedReplay) {
      ui.notifications.error(localize("BATTLE_REPLAY.notifications.liveReplayInvalid"));
      return false;
    }

    this.session = {
      id: createId(),
      hostUserId: game.user.id,
      replay: sharedReplay,
      revision: 0,
      role: "host"
    };

    void this.playback.play(sharedReplay, {
      interactive: true,
      liveRole: "host",
      onStateChange: (state) => this.handleHostState(state),
      startPaused: true
    });

    this.broadcastStart();
    const viewers = activePlayerCount();
    ui.notifications.info(localize("BATTLE_REPLAY.notifications.liveReplayStarted", { count: viewers }));
    return true;
  }

  stop() {
    if (!this.session) return false;
    if (this.isHosting) {
      this.playback.stop();
      if (this.session) this.finishHostSession();
    } else {
      this.playback.stop();
      this.session = null;
    }
    return true;
  }

  syncUser(user, connected = true) {
    if (!this.isHosting || connected === false || !user?.active || user.isGM) return false;
    this.broadcastStart(user.id);
    return true;
  }

  handleHostState(state) {
    if (!this.isHosting) return;
    if (state?.reason === "stopped" || state?.reason === "ended" || state?.active === false) {
      this.finishHostSession();
      return;
    }
    this.emit(LIVE_REPLAY_ACTIONS.STATE, {
      revision: this.nextRevision(),
      sessionId: this.session.id,
      state: normalizePlaybackState(state)
    });
  }

  async receive(packet) {
    if (packet?.type !== LIVE_REPLAY_PACKET) return false;
    if (packet.senderId === game.user?.id) return false;
    if (packet.targetUserId && packet.targetUserId !== game.user?.id) return false;

    if (packet.action === LIVE_REPLAY_ACTIONS.HELLO) {
      if (!this.isHosting) return false;
      const user = game.users?.get?.(packet.senderId);
      return this.syncUser(user, true);
    }

    if (game.user?.isGM || !isTrustedGM(packet.senderId)) return false;

    if (packet.action === LIVE_REPLAY_ACTIONS.START) {
      return this.receiveStart(packet);
    }
    if (!this.session || packet.sessionId !== this.session.id) return false;
    if (packet.senderId !== this.session.hostUserId) return false;
    if (Number(packet.revision) <= this.session.revision) return false;
    this.session.revision = Number(packet.revision);

    if (packet.action === LIVE_REPLAY_ACTIONS.STATE) {
      return this.playback.synchronize(packet.state, {
        force: ["pause", "seek", "position", "completed"].includes(packet.state?.reason)
      });
    }
    if (packet.action === LIVE_REPLAY_ACTIONS.STOP) {
      this.playback.stop();
      this.session = null;
      ui.notifications.info(localize("BATTLE_REPLAY.notifications.liveReplayStopped"));
      return true;
    }
    return false;
  }

  receiveStart(packet) {
    if (this.session?.id === packet.sessionId &&
      Number(packet.revision) <= this.session.revision) return false;
    const replay = prepareSharedReplay(packet.replay);
    if (!replay || !this.canDisplay(replay, true)) return false;

    if (this.session) this.playback.stop();
    this.session = {
      id: String(packet.sessionId),
      hostUserId: packet.senderId,
      replay,
      revision: Number(packet.revision) || 0,
      role: "viewer"
    };
    void this.playback.play(replay, {
      allowPlayer: true,
      interactive: true,
      liveRole: "viewer",
      onStateChange: (state) => this.handleViewerState(state, packet.sessionId),
      readOnly: true,
      cinematicEnabled: packet.state?.cinematicEnabled,
      cinematicPreset: packet.state?.cinematicPreset,
      creatorFormat: packet.state?.creatorFormat,
      speed: packet.state?.speed,
      startPaused: true
    });
    this.playback.synchronize(packet.state, { force: true });
    ui.notifications.info(localize("BATTLE_REPLAY.notifications.liveReplayJoined", {
      title: replay.title
    }));
    return true;
  }

  handleViewerState(state, sessionId) {
    if (!this.session || this.session.id !== String(sessionId)) return;
    if (state?.reason === "stopped" || state?.reason === "ended" || state?.active === false) {
      this.session = null;
    }
  }

  broadcastStart(targetUserId = null) {
    if (!this.isHosting) return;
    this.emit(LIVE_REPLAY_ACTIONS.START, {
      replay: this.session.replay,
      revision: this.nextRevision(),
      sessionId: this.session.id,
      state: normalizePlaybackState(this.playback.status),
      targetUserId
    });
  }

  finishHostSession() {
    if (!this.isHosting) return;
    this.emit(LIVE_REPLAY_ACTIONS.STOP, {
      revision: this.nextRevision(),
      sessionId: this.session.id
    });
    this.session = null;
  }

  nextRevision() {
    if (!this.session) return 0;
    this.session.revision += 1;
    return this.session.revision;
  }

  emit(action, data = {}) {
    game.socket?.emit?.(SOCKET_CHANNEL, {
      type: LIVE_REPLAY_PACKET,
      action,
      senderId: game.user?.id ?? null,
      ...data
    });
  }

  canDisplay(replay, remote = false) {
    if (canvas.ready && canvas.scene?.id === replay.sceneId) return true;
    ui.notifications.warn(localize(remote
      ? "BATTLE_REPLAY.notifications.liveReplayWrongScene"
      : "BATTLE_REPLAY.notifications.wrongScene", {
      scene: replay.sceneName
    }));
    return false;
  }
}

export function prepareSharedReplay(source) {
  if (!source || typeof source !== "object" || !source.id || !source.sceneId) return null;
  try {
    const sourceTokens = Array.isArray(source.tokens) ? source.tokens : [];
    const hiddenTokenIds = new Set(sourceTokens
      .filter((token) => token?.hidden === true && token?.id)
      .map((token) => String(token.id)));
    const hiddenActorIds = new Set(sourceTokens
      .filter((token) => token?.hidden === true && token?.actorId)
      .map((token) => String(token.actorId)));

    const sourceEvents = Array.isArray(source.events)
      ? source.events.slice(0, LIMITS.MAX_EVENTS_PER_REPLAY)
      : [];
    collectHiddenReferences(sourceEvents, hiddenTokenIds, hiddenActorIds);

    const tokens = sourceTokens
      .filter((token) => token?.hidden !== true)
      .map((token) => sanitizeSharedValue(token));
    const events = sourceEvents
      .filter((event) => !referencesHiddenDocument(event, hiddenTokenIds, hiddenActorIds))
      .map((event) => sanitizeSharedValue(event));

    return JSON.parse(JSON.stringify({
      schemaVersion: source.schemaVersion,
      id: source.id,
      sceneId: source.sceneId,
      sceneName: source.sceneName,
      title: source.title,
      startedAt: source.startedAt,
      endedAt: source.endedAt,
      system: source.system,
      tokens,
      events
    }));
  } catch (error) {
    warn("Could not prepare a replay for live sharing.", error);
    return null;
  }
}

const PRIVATE_SHARED_KEYS = new Set([
  "actorUuid",
  "combatantId",
  "dc",
  "formula",
  "messageId",
  "userId",
  "uuid"
]);

function collectHiddenReferences(value, hiddenTokenIds, hiddenActorIds) {
  if (Array.isArray(value)) {
    for (const entry of value) collectHiddenReferences(entry, hiddenTokenIds, hiddenActorIds);
    return;
  }
  if (!value || typeof value !== "object") return;

  if (value.hidden === true) {
    if (value.id) hiddenTokenIds.add(String(value.id));
    if (value.tokenId) hiddenTokenIds.add(String(value.tokenId));
    if (value.actorId) hiddenActorIds.add(String(value.actorId));
  }
  for (const entry of Object.values(value)) {
    collectHiddenReferences(entry, hiddenTokenIds, hiddenActorIds);
  }
}

function referencesHiddenDocument(value, hiddenTokenIds, hiddenActorIds, key = "") {
  if (Array.isArray(value)) {
    return value.some((entry) => referencesHiddenDocument(entry, hiddenTokenIds, hiddenActorIds, key));
  }
  if (!value || typeof value !== "object") {
    if (value === null || value === undefined) return false;
    const text = String(value);
    if (key.toLowerCase().includes("tokenid") && hiddenTokenIds.has(text)) return true;
    if (key.toLowerCase().includes("actorid") && hiddenActorIds.has(text)) return true;
    return false;
  }
  if (value.hidden === true) return true;
  return Object.entries(value).some(([entryKey, entry]) => {
    return referencesHiddenDocument(entry, hiddenTokenIds, hiddenActorIds, entryKey);
  });
}

function sanitizeSharedValue(value) {
  if (Array.isArray(value)) return value.map((entry) => sanitizeSharedValue(entry));
  if (!value || typeof value !== "object") return value;

  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !PRIVATE_SHARED_KEYS.has(key))
    .map(([key, entry]) => [key, sanitizeSharedValue(entry)]));
}

function normalizePlaybackState(source = {}) {
  return {
    active: source.active !== false,
    completed: Boolean(source.completed),
    cinematicEnabled: source.cinematicEnabled !== false,
    cinematicPreset: normalizeCinematicPreset(source.cinematicPreset),
    creatorFormat: normalizeCreatorFormat(source.creatorFormat),
    eventIndex: Math.max(0, Number(source.eventIndex) || 0),
    paused: Boolean(source.paused),
    reason: String(source.reason ?? "sync"),
    speed: Math.max(0.25, Number(source.speed) || 2)
  };
}

function isTrustedGM(userId) {
  return Boolean(userId && game.users?.get?.(userId)?.isGM);
}

function activePlayerCount() {
  const users = game.users?.filter?.((user) => user.active && !user.isGM) ?? [];
  return users.length;
}
