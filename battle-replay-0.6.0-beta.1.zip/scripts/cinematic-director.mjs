import { CINEMATIC_PRESETS, CREATOR_FORMATS } from "./constants.mjs";

const LARGE_SPELL_PATTERN = /fire\s?ball|explosion|cone|burst|blast|tempest|storm|meteor|dragon|breath|bola de fogo|explos[aã]o|tempestade|meteoro/i;

const PRESET_RULES = Object.freeze({
  [CINEMATIC_PRESETS.TACTICAL]: Object.freeze({
    cameraDuration: 720,
    defeatHold: 320,
    fade: false,
    focusTurns: false,
    movementCamera: false,
    shake: 0,
    slowMotion: 1,
    transition: "smooth"
  }),
  [CINEMATIC_PRESETS.CINEMATIC]: Object.freeze({
    cameraDuration: 520,
    defeatHold: 850,
    fade: true,
    focusTurns: true,
    movementCamera: true,
    shake: 5,
    slowMotion: 0.55,
    transition: "smooth"
  }),
  [CINEMATIC_PRESETS.CREATOR]: Object.freeze({
    cameraDuration: 260,
    defeatHold: 1050,
    fade: true,
    focusTurns: true,
    movementCamera: true,
    shake: 8,
    slowMotion: 0.42,
    transition: "cut"
  })
});

export class CinematicDirector {
  constructor({
    enabled = true,
    preset = CINEMATIC_PRESETS.CINEMATIC,
    creatorFormat = CREATOR_FORMATS.AUTO
  } = {}) {
    this.configure({ enabled, preset, creatorFormat });
  }

  configure({ enabled = this.isEnabled, preset = this.preset, creatorFormat = this.creatorFormat } = {}) {
    const normalizedPreset = normalizeCinematicPreset(preset);
    this.isEnabled = Boolean(enabled) && normalizedPreset !== CINEMATIC_PRESETS.OFF;
    this.preset = normalizedPreset === CINEMATIC_PRESETS.OFF
      ? CINEMATIC_PRESETS.CINEMATIC
      : normalizedPreset;
    this.creatorFormat = normalizeCreatorFormat(creatorFormat);
    return this;
  }

  get enabled() {
    return this.isEnabled;
  }

  plan(event = {}) {
    if (!this.enabled || !event?.type) return null;
    const rules = PRESET_RULES[this.preset];
    const data = event.data ?? {};
    const sourceId = cleanId(data.source?.tokenId);
    const targetIds = uniqueIds(data.targets?.map((target) => target?.tokenId));
    const common = {
      eventType: event.type,
      preset: this.preset,
      creatorFormat: this.preset === CINEMATIC_PRESETS.CREATOR
        ? this.creatorFormat
        : null,
      cameraDuration: rules.cameraDuration,
      transition: rules.transition,
      fade: false,
      holdMs: 0,
      playbackRate: 1,
      shake: 0
    };

    if (event.type === "attack-result") {
      const critical = normalizeOutcome(data.outcome) === "criticalsuccess";
      return compactCue({
        ...common,
        kind: critical ? "critical" : "attack",
        framing: critical ? "close" : "pair",
        focusTokenIds: uniqueIds([sourceId, ...targetIds]),
        holdMs: critical ? Math.round(280 / rules.slowMotion) : 0,
        playbackRate: critical ? rules.slowMotion : 1,
        shake: critical ? rules.shake : 0
      });
    }

    if (event.type === "item-use") {
      const largeSpell = isLargeSpell(data.item);
      const magical = isSpell(data.item);
      return compactCue({
        ...common,
        kind: largeSpell ? "large-spell" : magical ? "spell" : "action",
        framing: largeSpell ? "wide" : targetIds.length ? "pair" : "close",
        focusTokenIds: uniqueIds([sourceId, ...targetIds]),
        holdMs: largeSpell && this.preset !== CINEMATIC_PRESETS.TACTICAL ? 220 : 0
      });
    }

    if (event.type === "template-created") {
      return compactCue({
        ...common,
        kind: "area",
        framing: "wide",
        points: [finitePoint(data)].filter(Boolean),
        holdMs: this.preset === CINEMATIC_PRESETS.TACTICAL ? 0 : 180
      });
    }

    if (event.type === "visual-effect") {
      const points = [finitePoint(data.sourcePosition ?? data.source), finitePoint(data.targetPosition ?? data.target)]
        .filter(Boolean);
      return compactCue({
        ...common,
        kind: "visual-effect",
        framing: points.length > 1 ? "pair" : "close",
        focusTokenIds: uniqueIds([data.source?.tokenId, data.target?.tokenId]),
        points
      });
    }

    if (event.type === "combatant-defeated") {
      return compactCue({
        ...common,
        kind: "defeat",
        framing: "close",
        focusTokenIds: uniqueIds([data.tokenId]),
        fade: rules.fade,
        holdMs: rules.defeatHold,
        playbackRate: this.preset === CINEMATIC_PRESETS.TACTICAL ? 1 : 0.65
      });
    }

    if (event.type === "turn-change" && rules.focusTurns) {
      return compactCue({
        ...common,
        kind: "turn",
        framing: "close",
        focusTokenIds: uniqueIds([data.current?.tokenId])
      });
    }

    if (event.type === "token-move" && rules.movementCamera) {
      return compactCue({
        ...common,
        kind: "movement",
        framing: "follow",
        focusTokenIds: uniqueIds([data.tokenId]),
        points: [finitePoint(data.destination)].filter(Boolean)
      });
    }

    return null;
  }
}

export function normalizeCinematicPreset(value) {
  const normalized = String(value ?? "").toLowerCase();
  return Object.values(CINEMATIC_PRESETS).includes(normalized)
    ? normalized
    : CINEMATIC_PRESETS.CINEMATIC;
}

export function normalizeCreatorFormat(value) {
  const normalized = String(value ?? "").toLowerCase();
  return Object.values(CREATOR_FORMATS).includes(normalized)
    ? normalized
    : CREATOR_FORMATS.AUTO;
}

export function isLargeSpell(item = {}) {
  if (!isSpell(item)) return false;
  const rank = Number(item?.castRank);
  return (Number.isFinite(rank) && rank >= 3) || LARGE_SPELL_PATTERN.test(String(item?.name ?? ""));
}

function isSpell(item = {}) {
  const rank = item?.castRank;
  const hasCastRank = rank !== null && rank !== undefined && rank !== ""
    && Number.isFinite(Number(rank));
  return item?.type === "spell" || hasCastRank;
}

function normalizeOutcome(value) {
  return String(value ?? "").replaceAll(/[-_\s]/g, "").toLowerCase();
}

function cleanId(value) {
  const result = String(value ?? "").trim();
  return result || null;
}

function uniqueIds(values = []) {
  return [...new Set((Array.isArray(values) ? values : [])
    .map(cleanId)
    .filter(Boolean))];
}

function finitePoint(value = {}) {
  const x = Number(value?.x);
  const y = Number(value?.y);
  return Number.isFinite(x) && Number.isFinite(y) ? { x, y } : null;
}

function compactCue(cue) {
  const points = (cue.points ?? []).filter(Boolean);
  if (!cue.focusTokenIds?.length && !points.length) return null;
  return { ...cue, points };
}
