import { MODULE_ID, SOCKET_CHANNEL } from "./constants.mjs";
import { clamp, isAbortError, warn } from "./utils.mjs";

export const SEQUENCER_MODULE_ID = "sequencer";
export const SEQUENCER_EFFECT_HOOK = "preCreateSequencerEffect";
export const SEQUENCER_SOCKET_CHANNEL = SOCKET_CHANNEL;
export const SEQUENCER_PLAYBACK_ORIGIN = `${MODULE_ID}.playback`;

const MAX_FILE_LENGTH = 2_048;
const MAX_LABEL_LENGTH = 200;
const RECENT_EFFECT_WINDOW_MS = 1_000;
let replayingEffectCount = 0;

/**
 * Captures Sequencer's evaluated effect payload without persisting the original
 * object. A normalized player-originated effect is forwarded to the
 * authoritative GM because preCreateSequencerEffect runs on the client that
 * starts the Sequence.
 */
export class SequencerEffectAdapter {
  constructor(recorder) {
    this.recorder = recorder;
    this.recentEffects = new Map();
    this.boundSocketHandler = (packet) => this.receive(packet);
  }

  initialize() {
    game.socket?.on?.(SEQUENCER_SOCKET_CHANNEL, this.boundSocketHandler);
  }

  capture(effectData) {
    const recording = this.recorder.active ?? this.recorder.storage?.getActiveRecording?.();
    if (!recording || recording.endedAt || isSequencerReplayPlaybackActive()) return false;

    const data = normalizeSequencerEffect(effectData, {
      sceneId: recording.sceneId
    });
    if (!data) return false;

    const packet = {
      type: "visual-effect",
      combatId: recording.combatId,
      sceneId: recording.sceneId,
      userId: game.user?.id ?? null,
      data
    };

    if (this.recorder.isAuthoritativeGM()) {
      return this.record(packet);
    }

    game.socket?.emit?.(SEQUENCER_SOCKET_CHANNEL, packet);
    return true;
  }

  receive(packet) {
    if (!this.recorder.active || !this.recorder.isAuthoritativeGM()) return false;
    if (packet?.type !== "visual-effect") return false;
    if (packet.combatId !== this.recorder.active.combatId) return false;
    if (packet.sceneId !== this.recorder.active.sceneId) return false;

    const data = normalizeSequencerEffect(packet.data, {
      sceneId: this.recorder.active.sceneId
    });
    if (!data) return false;
    return this.record({ ...packet, data });
  }

  record(packet) {
    const now = Date.now();
    this.pruneRecentEffects(now);
    const fingerprint = packet.data.effectId ? effectFingerprint(packet.data) : null;
    if (fingerprint && this.recentEffects.has(fingerprint)) return false;
    if (fingerprint) this.recentEffects.set(fingerprint, now);

    return this.recorder.recordSemanticEvent("visual-effect", {
      ...packet.data,
      userId: packet.userId ?? null,
      provider: SEQUENCER_MODULE_ID
    });
  }

  pruneRecentEffects(now = Date.now()) {
    for (const [key, createdAt] of this.recentEffects) {
      if ((now - createdAt) > RECENT_EFFECT_WINDOW_MS) {
        this.recentEffects.delete(key);
      }
    }
  }
}

export function normalizeSequencerEffect(effectInput, options = {}) {
  const data = unwrapEffectData(effectInput);
  if (!data || typeof data !== "object") return null;

  const origin = firstString(data.origin, data.metadata?.origin, data.options?.origin);
  if (origin?.startsWith(SEQUENCER_PLAYBACK_ORIGIN)) return null;

  const expectedSceneId = cleanString(options.sceneId, MAX_LABEL_LENGTH);
  const effectSceneId = firstString(data.sceneId, data.scene, data.context?.sceneId);
  if (expectedSceneId && effectSceneId && effectSceneId !== expectedSceneId) return null;

  const file = normalizeEffectFile(
    data.file,
    data.filePath,
    data.src,
    data.texture,
    data.video,
    data.files
  );
  if (!file) return null;

  const sourceValue = firstDefined(
    data.source,
    data.sourceData,
    data.sourcePosition,
    data.location,
    data.position,
    data.atLocation
  );
  const targetValue = firstDefined(
    data.target,
    data.targetData,
    data.targetPosition,
    typeof data.stretchTo === "object" ? data.stretchTo : undefined
  );
  const source = normalizeEffectEndpoint(sourceValue, options);
  const target = normalizeEffectEndpoint(targetValue, options);
  if (!source || !Number.isFinite(source.x) || !Number.isFinite(source.y)) return null;

  const normalized = {
    effectId: cleanString(
      firstString(data.id, data._id, data.effectId, effectInput?.id, effectInput?._id),
      MAX_LABEL_LENGTH
    ),
    sceneId: effectSceneId ?? expectedSceneId ?? null,
    file,
    source,
    target,
    stretch: Boolean(target && firstDefined(
      data.stretchTo,
      data.stretch,
      data.stretchTowards,
      data.target
    )),
    name: cleanString(firstString(data.name, data.effectName), MAX_LABEL_LENGTH),
    origin: cleanString(origin, MAX_LABEL_LENGTH),
    duration: finiteInRange(
      firstDefined(data.duration, data.effectDuration, data.totalDuration),
      0,
      120_000
    ),
    playbackRate: finiteInRange(data.playbackRate, 0.05, 20),
    opacity: finiteInRange(firstDefined(data.opacity, data.alpha), 0, 1),
    scale: normalizeScale(firstDefined(data.scale, data.spriteScale)),
    rotation: finiteInRange(firstDefined(data.rotation, data.angle), -36_000, 36_000),
    tint: normalizeTint(data.tint),
    width: finiteInRange(firstDefined(data.width, data.size?.width), 1, 20_000),
    height: finiteInRange(firstDefined(data.height, data.size?.height), 1, 20_000),
    persist: Boolean(data.persist ?? data.persistent)
  };

  return stripNullish(normalized);
}

export async function playSequencerVisualEffect(data, options = {}) {
  const speed = clamp(Number(options.speed) || 1, 0.25, 16);
  const signal = options.signal;
  if (signal?.aborted) throw createAbortError();
  if (!isSequencerAvailable()) {
    return { played: false, reason: "sequencer-unavailable" };
  }

  const normalized = normalizeSequencerEffect(data, { sceneId: data?.sceneId });
  if (!normalized) return { played: false, reason: "invalid-effect" };

  const effectName = `${SEQUENCER_PLAYBACK_ORIGIN}.${Date.now()}.${Math.random().toString(36).slice(2)}`;
  let abortHandler;

  try {
    replayingEffectCount += 1;
    const sequence = new globalThis.Sequence();
    const section = sequence.effect();
    section.file(normalized.file);
    section.atLocation({ x: normalized.source.x, y: normalized.source.y });

    if (normalized.target && normalized.stretch) {
      section.stretchTo({ x: normalized.target.x, y: normalized.target.y });
    }
    if (normalized.playbackRate != null && typeof section.playbackRate === "function") {
      section.playbackRate(clamp(normalized.playbackRate * speed, 0.05, 20));
    } else if (typeof section.playbackRate === "function") {
      section.playbackRate(speed);
    }
    if (normalized.opacity != null && typeof section.opacity === "function") {
      section.opacity(normalized.opacity);
    }
    if (normalized.rotation != null && typeof section.rotate === "function") {
      section.rotate(normalized.rotation);
    }
    if (normalized.tint != null && typeof section.tint === "function") {
      section.tint(normalized.tint);
    }
    applyScale(section, normalized.scale);
    if (normalized.width && normalized.height && typeof section.size === "function") {
      section.size({ width: normalized.width, height: normalized.height });
    }
    if (normalized.duration && typeof section.duration === "function") {
      section.duration(clamp(normalized.duration / speed, 100, 8_000));
    }
    section.name?.(effectName);
    section.origin?.(SEQUENCER_PLAYBACK_ORIGIN);
    section.locally?.();

    const playPromise = Promise.resolve(sequence.play());
    if (!signal) {
      await playPromise;
    } else {
      const abortPromise = new Promise((_, reject) => {
        abortHandler = () => {
          void globalThis.Sequencer?.EffectManager?.endEffects?.({
            name: effectName,
            sceneId: normalized.sceneId
          });
          reject(createAbortError());
        };
        signal.addEventListener("abort", abortHandler, { once: true });
      });
      await Promise.race([playPromise, abortPromise]);
    }

    return { played: true };
  } catch (error) {
    if (isAbortError(error)) throw error;
    warn("Could not replay a Sequencer visual effect.", error);
    return { played: false, reason: "playback-failed" };
  } finally {
    if (abortHandler) signal?.removeEventListener("abort", abortHandler);
    replayingEffectCount = Math.max(0, replayingEffectCount - 1);
  }
}

export function isSequencerAvailable() {
  return Boolean(
    game.modules?.get?.(SEQUENCER_MODULE_ID)?.active &&
    typeof globalThis.Sequence === "function"
  );
}

export function isSequencerReplayPlaybackActive() {
  return replayingEffectCount > 0;
}

function unwrapEffectData(effectInput) {
  if (!effectInput || typeof effectInput !== "object") return effectInput;
  if (isObject(effectInput.data)) return effectInput.data;
  if (isObject(effectInput.document?._source)) return effectInput.document._source;
  if (isObject(effectInput._source)) return effectInput._source;
  return effectInput;
}

function normalizeEffectFile(...candidates) {
  for (const candidate of candidates) {
    const file = extractFile(candidate);
    if (file) return cleanString(file, MAX_FILE_LENGTH);
  }
  return null;
}

function extractFile(candidate) {
  if (typeof candidate === "string") return candidate;
  if (Array.isArray(candidate)) {
    return candidate.map(extractFile).find(Boolean) ?? null;
  }
  if (!isObject(candidate)) return null;
  return firstString(
    candidate.path,
    candidate.dbPath,
    candidate.file,
    candidate.src,
    candidate.name,
    candidate.url
  );
}

function normalizeEffectEndpoint(value, options = {}) {
  if (!value) return null;
  const resolved = resolveEndpointReference(value) ?? value;
  const object = resolved.object ?? resolved;
  const document = object.document ?? resolved.document ?? null;
  const center = object.center ?? document?.object?.center ?? null;
  const gridSize = Number(options.gridSize ?? globalThis.canvas?.grid?.size ?? 100) || 100;

  let x = finiteOrNull(center?.x ?? object.x ?? document?.x);
  let y = finiteOrNull(center?.y ?? object.y ?? document?.y);
  if (!center && document && Number.isFinite(x) && Number.isFinite(y)) {
    x += (Number(document.width ?? 0) * gridSize) / 2;
    y += (Number(document.height ?? 0) * gridSize) / 2;
  }

  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
  return stripNullish({
    x,
    y,
    elevation: finiteOrNull(object.elevation ?? document?.elevation),
    rotation: finiteOrNull(object.rotation ?? document?.rotation),
    tokenId: cleanString(
      firstString(object.tokenId, document?.documentName === "Token" ? document.id : null),
      MAX_LABEL_LENGTH
    ),
    uuid: cleanString(firstString(object.uuid, document?.uuid, typeof value === "string" ? value : null), 500)
  });
}

function resolveEndpointReference(value) {
  if (typeof value !== "string" || typeof globalThis.fromUuidSync !== "function") return null;
  try {
    return globalThis.fromUuidSync(value);
  } catch {
    return null;
  }
}

function normalizeScale(value) {
  const uniform = finiteInRange(value, 0.01, 100);
  if (uniform != null) return uniform;
  if (!isObject(value)) return null;
  const x = finiteInRange(value.x, 0.01, 100);
  const y = finiteInRange(value.y, 0.01, 100);
  if (x == null && y == null) return null;
  return stripNullish({ x: x ?? y, y: y ?? x });
}

function applyScale(section, scale) {
  if (scale == null || typeof section.scale !== "function") return;
  if (typeof scale === "number") {
    section.scale(scale);
  } else {
    section.scale(scale);
  }
}

function normalizeTint(value) {
  if (typeof value === "string") {
    const normalized = value.trim().replace(/^#/, "");
    if (/^[0-9a-f]{6}$/i.test(normalized)) return Number.parseInt(normalized, 16);
  }
  return finiteInRange(value, 0, 0xFFFFFF);
}

function effectFingerprint(data) {
  if (data.effectId) return `id:${data.effectId}`;
  return JSON.stringify([
    data.file,
    data.source?.x,
    data.source?.y,
    data.target?.x,
    data.target?.y,
    data.duration,
    data.name,
    data.origin
  ]);
}

function firstDefined(...values) {
  return values.find((value) => value !== undefined && value !== null);
}

function firstString(...values) {
  return values.find((value) => typeof value === "string" && value.trim())?.trim() ?? null;
}

function cleanString(value, maximumLength) {
  if (typeof value !== "string") return null;
  const cleaned = value.trim();
  return cleaned ? cleaned.slice(0, maximumLength) : null;
}

function finiteOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function finiteInRange(value, minimum, maximum) {
  const number = finiteOrNull(value);
  return number == null ? null : clamp(number, minimum, maximum);
}

function stripNullish(source) {
  return Object.fromEntries(
    Object.entries(source).filter(([, value]) => value !== null && value !== undefined)
  );
}

function isObject(value) {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function createAbortError() {
  return new DOMException("Playback aborted", "AbortError");
}
