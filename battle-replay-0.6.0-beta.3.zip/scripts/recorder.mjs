import {
  LIMITS,
  MODULE_ID,
  REPLAY_SCHEMA_VERSION,
  SETTINGS
} from "./constants.mjs";
import { requestRecordingDecision } from "./recording-prompt.mjs";
import {
  createId,
  localize,
  log,
  pickPosition,
  positionsEqual,
  warn
} from "./utils.mjs";

export class CombatRecorder {
  constructor(storage) {
    this.storage = storage;
    this.active = null;
    this.finalizing = false;
    this.pendingCombatIds = new Set();
  }

  get status() {
    return {
      active: Boolean(this.active),
      combatId: this.active?.combatId ?? null,
      replayId: this.active?.id ?? null,
      title: this.active?.title ?? null,
      recorderUserId: this.active?.recorderUserId ?? null,
      eventCount: this.active?.events?.length ?? 0
    };
  }

  async resumeForCurrentUser() {
    if (!game.user?.isGM) return;

    const stored = this.storage.getActiveRecording();
    if (!stored || stored.endedAt) return;

    const owner = game.users.get(stored.recorderUserId);
    const canTakeOver = !owner?.active && this.isAuthoritativeGM();
    if (stored.recorderUserId !== game.user.id && !canTakeOver) return;

    this.active = stored;
    if (canTakeOver) {
      const priorRecorderUserId = stored.recorderUserId;
      this.active.recorderUserId = game.user.id;
      this.appendEvent("recorder-transferred", {
        priorRecorderUserId,
        recorderUserId: game.user.id
      });
    } else {
      this.appendEvent("recorder-resumed", {
        round: game.combats.get(stored.combatId)?.round ?? null,
        turn: game.combats.get(stored.combatId)?.turn ?? null
      });
    }

    if (!game.combats.get(stored.combatId)) {
      await this.finalize(stored.combatId, "orphaned");
      return;
    }

    await this.checkpoint(true);
    log("Resumed recording " + stored.id + ".");
  }

  async start(combat, updateData = {}) {
    if (!game.user?.isGM || !this.isAuthoritativeGM()) return;
    if (this.active?.combatId === combat.id || this.pendingCombatIds.has(combat.id)) return;

    this.pendingCombatIds.add(combat.id);
    try {
      if (this.active) await this.finalize(this.active.combatId, "interrupted");

      const scene = resolveCombatScene(combat);
      if (!scene) {
        ui.notifications.warn(localize("BATTLE_REPLAY.notifications.noScene"));
        return;
      }

      const tokens = snapshotCombatants(combat, scene);
      if (!tokens.length) {
        ui.notifications.warn(localize("BATTLE_REPLAY.notifications.noCombatants"));
        return;
      }

      const startedAt = Date.now();
      const automatic = Boolean(game.settings.get(MODULE_ID, SETTINGS.AUTO_RECORD));
      const decision = await requestRecordingDecision({ automatic, scene, startedAt });
      if (!decision.record) {
        ui.notifications.info(localize("BATTLE_REPLAY.notifications.recordingSkipped"));
        return;
      }

      const liveCombat = game.combats.get(combat.id);
      if (!liveCombat || liveCombat.started === false) {
        ui.notifications.warn(localize("BATTLE_REPLAY.notifications.combatEndedBeforeRecording"));
        return;
      }

      this.active = {
        schemaVersion: REPLAY_SCHEMA_VERSION,
        id: createId(),
        combatId: combat.id,
        recorderUserId: game.user.id,
        sceneId: scene.id,
        sceneName: scene.name,
        title: decision.title,
        tags: [],
        favorite: false,
        startedAt,
        endedAt: null,
        endReason: null,
        foundryVersion: game.version,
        system: {
          id: game.system.id,
          version: game.system.version
        },
        tokens,
        events: []
      };

      this.appendEvent("combat-start", {
        round: updateData.round ?? combat.round ?? 1,
        turn: updateData.turn ?? combat.turn ?? 0,
        combatantCount: tokens.length
      });

      await this.checkpoint(true);
      ui.notifications.info(localize("BATTLE_REPLAY.notifications.recordingStarted", {
        title: decision.title
      }));
      Hooks.callAll(MODULE_ID + ":recordingStarted", this.active);
      log("Started recording " + this.active.id + ".");
    } finally {
      this.pendingCombatIds.delete(combat.id);
    }
  }

  async cancel() {
    if (!this.active || this.active.recorderUserId !== game.user?.id) return false;
    const replay = this.active;
    this.active = null;
    await this.storage.clearActiveRecording();
    Hooks.callAll(MODULE_ID + ":recordingCancelled", replay);
    ui.notifications.info(localize("BATTLE_REPLAY.notifications.recordingCancelled"));
    return true;
  }

  async recordTurn(combat, prior, current) {
    if (!this.isRecording(combat)) return;

    this.appendEvent("turn-change", {
      prior: pickCombatHistory(prior),
      current: pickCombatHistory(current)
    });

    await this.checkpoint(true);
  }

  recordMovement(document, movement, user) {
    if (!this.isActiveRecorder() || document.parent?.id !== this.active.sceneId) return;

    const combat = game.combats.get(this.active.combatId);
    const isCombatant = combat?.combatants.some((combatant) => combatant.tokenId === document.id);
    if (!isCombatant) return;

    const movementId = movement.id ?? null;
    if (movementId && this.active.events.some((event) => {
      return event.type === "token-move" &&
        event.data?.tokenId === document.id &&
        event.data?.movementId === movementId;
    })) return;

    this.ensureTokenSnapshot(document, combat);

    const origin = pickPosition(movement.origin);
    const destination = pickPosition(movement.destination);
    if (positionsEqual(origin, destination)) return;

    const passedWaypoints = Array.isArray(movement.passed?.waypoints)
      ? movement.passed.waypoints.map(pickMovementWaypoint)
      : [];

    this.appendEvent("token-move", {
      tokenId: document.id,
      userId: user?.id ?? null,
      movementId,
      method: movement.method ?? "unknown",
      origin,
      destination,
      waypoints: passedWaypoints,
      animationDuration: finiteOrNull(movement.animation?.duration)
    });
  }

  recordCombatantCreated(combatant) {
    const combat = combatant.parent;
    if (!this.isRecording(combat)) return;
    const scene = resolveCombatScene(combat);
    const token = combatant.token ?? scene?.tokens.get(combatant.tokenId);
    if (!token) return;

    const snapshot = snapshotToken(token, combatant, scene);
    snapshot.initial = false;
    if (!this.active.tokens.some((entry) => entry.id === snapshot.id)) {
      this.active.tokens.push(snapshot);
    }
    this.appendEvent("combatant-added", {
      combatantId: combatant.id,
      token: snapshot
    });
  }

  recordCombatantDeleted(combatant) {
    if (!this.isActiveRecorder() || combatant.parent?.id !== this.active.combatId) return;
    const snapshot = this.active.tokens.find((entry) => entry.combatantId === combatant.id) ?? null;
    this.appendEvent("combatant-removed", {
      combatantId: combatant.id,
      tokenId: combatant.tokenId ?? snapshot?.id ?? null,
      actorId: combatant.actorId ?? snapshot?.actorId ?? null,
      name: combatant.name ?? snapshot?.name ?? null
    });
  }

  recordTokenDeleted(document) {
    if (!this.isActiveRecorder() || document.parent?.id !== this.active.sceneId) return;
    const snapshot = this.active.tokens.find((entry) => entry.id === document.id);
    if (!snapshot) return;
    this.appendEvent("token-deleted", {
      tokenId: document.id,
      actorId: snapshot.actorId,
      snapshot
    });
  }

  recordTokenCreated(document) {
    if (!this.isActiveRecorder() || document.parent?.id !== this.active.sceneId) return;
    const priorDeletion = this.active.events.findLast((event) => {
      return event.type === "token-deleted" &&
        event.data?.actorId &&
        event.data.actorId === document.actorId;
    });
    const combat = game.combats.get(this.active.combatId);
    const combatant = combat?.combatants.find((entry) => entry.tokenId === document.id) ?? null;
    if (!priorDeletion && !combatant) return;

    const snapshot = snapshotToken(document, combatant, document.parent);
    snapshot.initial = false;
    if (!this.active.tokens.some((entry) => entry.id === document.id)) {
      this.active.tokens.push(snapshot);
    }
    this.appendEvent("token-created", {
      replacesTokenId: priorDeletion?.data?.tokenId ?? null,
      token: snapshot
    });
  }

  recordTemplateCreated(document, userId) {
    if (!this.isActiveRecorder() || document.parent?.id !== this.active.sceneId) return;
    this.appendEvent("template-created", {
      templateId: document.id,
      userId,
      type: document.t ?? null,
      x: finiteOrNull(document.x),
      y: finiteOrNull(document.y),
      distance: finiteOrNull(document.distance),
      direction: finiteOrNull(document.direction),
      angle: finiteOrNull(document.angle),
      width: finiteOrNull(document.width),
      fillColor: document.fillColor ?? null
    });
  }

  recordSemanticEvent(type, data = {}) {
    if (!this.isActiveRecorder()) return false;
    if (data.messageId && this.active.events.some((event) => {
      return event.type === type && event.data?.messageId === data.messageId;
    })) return false;
    this.appendEvent(type, data);
    return true;
  }

  async handleCombatUpdate(combat, changed) {
    if (!this.isRecording(combat)) return;
    if (changed?.scene && changed.scene !== this.active.sceneId) {
      this.appendEvent("scene-changed", {
        priorSceneId: this.active.sceneId,
        sceneId: changed.scene
      });
      await this.finalize(combat.id, "scene-changed");
      return;
    }
    if (changed?.active === false || changed?.started === false) {
      await this.finalize(combat.id, "ended");
    }
  }

  async handleSceneDeleted(scene) {
    if (this.active?.sceneId === scene.id) {
      await this.finalize(this.active.combatId, "scene-deleted");
    }
  }

  async handleUserPresenceChange(user = null, connected = null) {
    if (!game.user?.isGM || this.active) return;
    const stored = this.storage.getActiveRecording();
    if (!stored || stored.endedAt) return;
    const owner = game.users.get(stored.recorderUserId);
    const ownerJustDisconnected = user?.id === stored.recorderUserId && connected === false;
    const elected = ownerJustDisconnected
      ? this.isElectedGM(stored.recorderUserId)
      : this.isAuthoritativeGM();
    if (!elected) return;
    if (owner?.active && !ownerJustDisconnected) return;

    this.active = stored;
    const priorRecorderUserId = stored.recorderUserId;
    this.active.recorderUserId = game.user.id;
    this.appendEvent("recorder-transferred", {
      priorRecorderUserId,
      recorderUserId: game.user.id
    });
    await this.checkpoint(true);
    ui.notifications.info(localize("BATTLE_REPLAY.notifications.recorderTransferred"));
  }

  async finalize(combatId, reason = "ended") {
    if (!this.active || this.active.combatId !== combatId || this.finalizing) return;

    this.finalizing = true;
    try {
      this.appendEvent("combat-end", { reason });
      this.active.endedAt = Date.now();
      this.active.endReason = reason;

      const replay = this.active;
      const substantive = replay.events.some((event) => {
        return ![
          "combat-start",
          "combat-end",
          "recorder-resumed",
          "recorder-transferred"
        ].includes(event.type);
      });

      if (substantive) {
        await this.storage.saveReplay(replay);
      }
      await this.storage.clearActiveRecording();
      this.active = null;

      if (substantive) {
        ui.notifications.info(localize("BATTLE_REPLAY.notifications.recordingSaved"));
        Hooks.callAll(MODULE_ID + ":recordingSaved", replay);
        log("Saved replay " + replay.id + " with " + replay.events.length + " events.");
      } else {
        ui.notifications.warn(localize("BATTLE_REPLAY.notifications.emptyRecordingDiscarded"));
      }
    } catch (error) {
      warn("Could not finalize combat recording.", error);
      ui.notifications.error(localize("BATTLE_REPLAY.notifications.saveFailed"));
    } finally {
      this.finalizing = false;
    }
  }

  isRecording(combat) {
    return Boolean(
      game.user?.isGM &&
      this.active &&
      this.active.recorderUserId === game.user.id &&
      this.active.combatId === combat?.id
    );
  }

  isActiveRecorder() {
    return Boolean(
      game.user?.isGM &&
      this.active &&
      this.active.recorderUserId === game.user.id &&
      this.isAuthoritativeGM()
    );
  }

  isRecordingActor(actor) {
    if (!this.active || !actor) return false;
    return this.active.tokens.some((token) => token.actorId === actor.id);
  }

  getTokenForActor(actor) {
    if (!this.active || !actor) return null;
    const combat = game.combats.get(this.active.combatId);
    const combatant = combat?.combatants.find((entry) => entry.actorId === actor.id);
    return combatant?.tokenId ??
      this.active.tokens.find((token) => token.actorId === actor.id)?.id ??
      null;
  }

  isAuthoritativeGM() {
    const stored = this.active ?? this.storage.getActiveRecording();
    const owner = stored?.recorderUserId ? game.users.get(stored.recorderUserId) : null;
    if (owner?.active) return owner.id === game.user?.id;

    return this.isElectedGM();
  }

  isElectedGM(excludedUserId = null) {
    const activeGMs = game.users
      .filter((user) => user.id !== excludedUserId && user.active && user.isGM)
      .sort((left, right) => left.id.localeCompare(right.id));
    return activeGMs[0]?.id === game.user?.id;
  }

  appendEvent(type, data = {}) {
    if (!this.active) return;

    if (this.active.events.length >= LIMITS.MAX_EVENTS_PER_REPLAY) {
      if (!this.active.truncated) {
        this.active.truncated = true;
        ui.notifications.warn(localize("BATTLE_REPLAY.notifications.eventLimit"));
      }
      return;
    }

    this.active.events.push({
      sequence: this.active.events.length,
      at: Date.now() - this.active.startedAt,
      type,
      data
    });
    this.checkpointIfNeeded();
  }

  checkpointIfNeeded() {
    const interval = Number(game.settings.get(MODULE_ID, SETTINGS.CHECKPOINT_INTERVAL)) || 5;
    if (this.active?.events.length % interval === 0) {
      void this.checkpoint(true);
    }
  }

  async checkpoint(force = false) {
    if (!this.active) return;
    if (!force) {
      const interval = Number(game.settings.get(MODULE_ID, SETTINGS.CHECKPOINT_INTERVAL)) || 5;
      if (this.active.events.length % interval !== 0) return;
    }
    await this.storage.saveActiveRecording(this.active);
  }

  ensureTokenSnapshot(document, combat) {
    if (this.active.tokens.some((token) => token.id === document.id)) return;
    const combatant = combat?.combatants.find((entry) => entry.tokenId === document.id) ?? null;
    this.active.tokens.push(snapshotToken(document, combatant, document.parent));
  }
}

function resolveCombatScene(combat) {
  const sceneId = combat.scene?.id ?? combat.scene ?? combat._source?.scene ?? canvas.scene?.id;
  return game.scenes.get(sceneId) ?? (canvas.scene?.id === sceneId ? canvas.scene : null);
}

function snapshotCombatants(combat, scene) {
  return combat.combatants
    .map((combatant) => {
      const token = combatant.token ?? scene.tokens.get(combatant.tokenId);
      if (!token) return null;
      const snapshot = snapshotToken(token, combatant, scene);
      snapshot.initial = true;
      return snapshot;
    })
    .filter(Boolean);
}

export function snapshotToken(document, combatant, scene) {
  const gridSize = Number(scene?.grid?.size ?? canvas.grid?.size ?? 100);
  const object = document.object;
  const texture = document.texture ?? {};
  const textureSource = texture.src ?? null;
  const actor = document.actor ?? combatant?.actor ?? null;

  return {
    id: document.id,
    initial: false,
    combatantId: combatant?.id ?? null,
    actorId: document.actorId ?? combatant?.actorId ?? null,
    name: combatant?.name ?? document.name ?? "Token",
    texture: textureSource,
    appearance: {
      texture: textureSource,
      scaleX: finiteOrNull(texture.scaleX) ?? 1,
      scaleY: finiteOrNull(texture.scaleY) ?? 1,
      offsetX: finiteOrNull(texture.offsetX) ?? 0,
      offsetY: finiteOrNull(texture.offsetY) ?? 0,
      rotation: finiteOrNull(texture.rotation) ?? 0,
      tint: primitiveOrNull(texture.tint)
    },
    health: snapshotHealth(actor),
    x: Number(document.x ?? 0),
    y: Number(document.y ?? 0),
    rotation: Number(document.rotation ?? 0),
    elevation: Number(document.elevation ?? 0),
    width: Number(document.width ?? 1),
    height: Number(document.height ?? 1),
    pixelWidth: Number(object?.w ?? document.width * gridSize),
    pixelHeight: Number(object?.h ?? document.height * gridSize),
    alpha: Number(document.alpha ?? 1),
    hidden: Boolean(document.hidden),
    disposition: Number(document.disposition ?? 0)
  };
}

function snapshotHealth(actor) {
  const hp = actor?.system?.attributes?.hp;
  const value = finiteOrNull(hp?.value);
  const maximum = finiteOrNull(hp?.max);
  const temporary = finiteOrNull(hp?.temp);
  const temporaryMaximum = finiteOrNull(hp?.tempmax);

  if ([value, maximum, temporary, temporaryMaximum].every((entry) => entry === null)) {
    return null;
  }

  return {
    value,
    maximum,
    temporary,
    temporaryMaximum
  };
}

function primitiveOrNull(value) {
  return ["string", "number"].includes(typeof value) ? value : null;
}

function pickCombatHistory(history = {}) {
  return {
    round: finiteOrNull(history.round),
    turn: finiteOrNull(history.turn),
    combatantId: history.combatantId ?? null,
    tokenId: history.tokenId ?? null
  };
}

function pickMovementWaypoint(waypoint = {}) {
  return {
    x: finiteOrNull(waypoint.x),
    y: finiteOrNull(waypoint.y),
    elevation: finiteOrNull(waypoint.elevation),
    rotation: finiteOrNull(waypoint.rotation),
    action: waypoint.action ?? null,
    checkpoint: Boolean(waypoint.checkpoint)
  };
}

function finiteOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}
