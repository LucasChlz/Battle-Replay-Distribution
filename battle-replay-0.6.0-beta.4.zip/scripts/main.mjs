import { MODULE_ID, RECORDING_MODES, SETTINGS } from "./constants.mjs";
import { buildCombatAnalytics } from "./analytics.mjs";
import { CombatEventAdapter } from "./combat-events.mjs";
import { EntitlementService, FEATURE_TIERS } from "./entitlements.mjs";
import { LiveReplayController } from "./live-replay.mjs";
import { PlaybackEngine } from "./playback.mjs";
import { CombatRecorder } from "./recorder.mjs";
import { registerSettings } from "./settings.mjs";
import {
  SEQUENCER_EFFECT_HOOK,
  SequencerEffectAdapter
} from "./sequencer-effects.mjs";
import { ReplayStorage } from "./storage.mjs";
import { attachReplayControl, openReplayLibrary } from "./ui.mjs";
import { localize, log, warn } from "./utils.mjs";

const storage = new ReplayStorage();
const recorder = new CombatRecorder(storage);
const entitlements = new EntitlementService();
const playback = new PlaybackEngine({ entitlements });
const liveReplay = new LiveReplayController({ playback, entitlements });
const eventAdapter = new CombatEventAdapter(recorder);
const sequencerEffects = new SequencerEffectAdapter(recorder);

Hooks.once("init", () => {
  registerSettings();
  log("Initialized.");
});

Hooks.once("ready", async () => {
  const entitlementContext = {
    userId: game.user?.id ?? null,
    worldId: game.world?.id ?? null
  };
  const developmentBuild = game.modules.get(MODULE_ID)?.flags?.[MODULE_ID]?.developmentBuild === true;
  if (developmentBuild) {
    await entitlements.setProvider({
      resolveEntitlement: async () => ({ tier: FEATURE_TIERS.DEVELOPMENT })
    }, entitlementContext);
  } else {
    await entitlements.refresh(entitlementContext);
  }
  try {
    await storage.initialize();
  } catch (error) {
    storage.enableLegacyFallback();
    warn("Journal storage initialization failed; using the legacy fallback.", error);
    ui.notifications.warn(localize("BATTLE_REPLAY.notifications.storageFallback"));
  }
  await recorder.resumeForCurrentUser();
  eventAdapter.initialize();
  sequencerEffects.initialize();
  liveReplay.initialize();

  const module = game.modules.get(MODULE_ID);
  if (module) {
    module.api = Object.freeze({
      getReplays: () => storage.getReplays(),
      getActiveRecording: () => recorder.active ?? storage.getActiveRecording(),
      getRecordingStatus: () => recorder.status,
      getPlaybackStatus: () => playback.status,
      getLiveReplayStatus: () => liveReplay.status,
      getFeatureAccess: () => entitlements.status,
      getStorageStats: () => storage.getStorageStats(),
      getCombatAnalytics: (replayOrId) => buildCombatAnalytics(
        typeof replayOrId === "string" ? storage.getReplay(replayOrId) : replayOrId
      ),
      getEffectCapabilities: () => ({
        sequencer: Boolean(game.modules.get("sequencer")?.active && globalThis.Sequence)
      }),
      openLibrary: () => openLibrary(),
      play: (replayOrId, options = {}) => playback.play(
        typeof replayOrId === "string" ? storage.getReplay(replayOrId) : replayOrId,
        options
      ),
      pause: () => playback.pause(),
      resume: () => playback.resume(),
      seek: (eventIndex) => playback.seek(eventIndex),
      step: (delta) => playback.step(delta),
      stop: () => playback.stop(),
      startLiveReplay: (replayOrId) => liveReplay.start(
        typeof replayOrId === "string" ? storage.getReplay(replayOrId) : replayOrId
      ),
      stopLiveReplay: () => liveReplay.stop(),
      setEntitlementProvider: (provider) => entitlements.setProvider(provider, {
        ...entitlementContext
      }),
      cancelRecording: () => recorder.cancel(),
      deleteReplay: (replayId) => storage.deleteReplay(replayId),
      updateReplay: (replayId, changes) => storage.updateReplay(replayId, changes),
      importReplay: (source) => storage.importReplay(source),
      setRecordingMode: (mode) => game.settings.set(
        MODULE_ID,
        SETTINGS.AUTO_RECORD,
        mode === RECORDING_MODES.AUTOMATIC
      )
    });
  }

  log("Ready.");
});

Hooks.on("combatStart", (combat, updateData) => {
  void recorder.start(combat, updateData);
});

Hooks.on("combatTurnChange", (combat, prior, current) => {
  void recorder.recordTurn(combat, prior, current);
});

Hooks.on("moveToken", (document, movement, operation, user) => {
  recorder.recordMovement(document, movement, user, operation);
});

Hooks.on("updateCombat", (combat, changed) => {
  void recorder.handleCombatUpdate(combat, changed);
});

Hooks.on("deleteCombat", (combat) => {
  void recorder.finalize(combat.id, "deleted");
});

Hooks.on("createCombatant", (combatant) => {
  recorder.recordCombatantCreated(combatant);
  eventAdapter.trackActor(combatant.actor);
});

Hooks.on("deleteCombatant", (combatant) => {
  recorder.recordCombatantDeleted(combatant);
});

Hooks.on("createToken", (token) => {
  recorder.recordTokenCreated(token);
});

Hooks.on("deleteToken", (token) => {
  recorder.recordTokenDeleted(token);
});

Hooks.on("deleteScene", (scene) => {
  void recorder.handleSceneDeleted(scene);
});

Hooks.on("createMeasuredTemplate", (template, _options, userId) => {
  recorder.recordTemplateCreated(template, userId);
});

Hooks.on("preUpdateActor", (actor) => {
  eventAdapter.preUpdateActor(actor);
});

Hooks.on("updateActor", (actor, changed, options, userId) => {
  eventAdapter.updateActor(actor, changed, options, userId);
});

Hooks.on("createItem", (item, options, userId) => {
  eventAdapter.createItem(item, options, userId);
});

Hooks.on("deleteItem", (item, options, userId) => {
  eventAdapter.deleteItem(item, options, userId);
});

Hooks.on("preUpdateItem", (item) => {
  eventAdapter.preUpdateItem(item);
});

Hooks.on("updateItem", (item, changed, options, userId) => {
  eventAdapter.updateItem(item, changed, options, userId);
});

Hooks.on("createChatMessage", (message) => {
  eventAdapter.createChatMessage(message);
});

Hooks.on("targetToken", (user, token, targeted) => {
  eventAdapter.targetToken(user, token, targeted);
});

Hooks.on(SEQUENCER_EFFECT_HOOK, (effectData) => {
  sequencerEffects.capture(effectData);
});

Hooks.on("userConnected", (user, connected) => {
  void recorder.handleUserPresenceChange(user, connected);
  liveReplay.syncUser(user, connected);
});

Hooks.on("updateUser", (_user, changed) => {
  if ("active" in changed) void recorder.handleUserPresenceChange();
});

Hooks.on(MODULE_ID + ":recordingStarted", () => {
  eventAdapter.seedActorStates();
});

Hooks.on("getSceneControlButtons", (controls) => {
  attachReplayControl(controls, openLibrary);
});

Hooks.on("canvasTearDown", () => {
  playback.stop();
});

Hooks.on("canvasReady", () => {
  liveReplay.requestSync();
});

Hooks.on("hotReload", () => {
  playback.stop();
});

function openLibrary() {
  return openReplayLibrary({ storage, recorder, playback, liveReplay });
}
