import { clamp, pickPosition } from "./utils.mjs";

export const TIMELINE_CATEGORIES = Object.freeze({
  ACTION: "action",
  ATTACK: "attack",
  CONDITION: "condition",
  DEFEAT: "defeat",
  HEALTH: "health",
  MAGIC: "magic",
  MOVEMENT: "movement",
  SAVE: "save",
  TURN: "turn"
});

const CATEGORY_ICONS = Object.freeze({
  [TIMELINE_CATEGORIES.ACTION]: "fa-bolt",
  [TIMELINE_CATEGORIES.ATTACK]: "fa-crosshairs",
  [TIMELINE_CATEGORIES.CONDITION]: "fa-circle-exclamation",
  [TIMELINE_CATEGORIES.DEFEAT]: "fa-skull",
  [TIMELINE_CATEGORIES.HEALTH]: "fa-heart-pulse",
  [TIMELINE_CATEGORIES.MAGIC]: "fa-wand-sparkles",
  [TIMELINE_CATEGORIES.MOVEMENT]: "fa-shoe-prints",
  [TIMELINE_CATEGORIES.SAVE]: "fa-shield-halved",
  [TIMELINE_CATEGORIES.TURN]: "fa-rotate"
});

export function timelineCategory(event = {}) {
  const type = event.type;
  if (["combat-start", "turn-change", "combat-end"].includes(type)) {
    return TIMELINE_CATEGORIES.TURN;
  }
  if (type === "token-move") return TIMELINE_CATEGORIES.MOVEMENT;
  if (["combatant-added", "combatant-removed", "token-created", "token-deleted"].includes(type)) {
    return TIMELINE_CATEGORIES.ACTION;
  }
  if (type === "attack-result") return TIMELINE_CATEGORIES.ATTACK;
  if (type === "combatant-defeated") return TIMELINE_CATEGORIES.DEFEAT;
  if (["damage-roll", "damage", "healing"].includes(type)) {
    return TIMELINE_CATEGORIES.HEALTH;
  }
  if (["condition-added", "condition-changed", "condition-removed"].includes(type)) {
    return TIMELINE_CATEGORIES.CONDITION;
  }
  if (["template-created", "visual-effect"].includes(type)) {
    return TIMELINE_CATEGORIES.MAGIC;
  }
  if (type === "item-use") {
    const item = event.data?.item ?? {};
    return item.type === "spell" || Number.isFinite(Number(item.castRank))
      ? TIMELINE_CATEGORIES.MAGIC
      : TIMELINE_CATEGORIES.ACTION;
  }
  if (type === "check-result") {
    return isSavingThrowEvent(event)
      ? TIMELINE_CATEGORIES.SAVE
      : TIMELINE_CATEGORIES.ACTION;
  }
  return null;
}

export function buildTimelineMarkers(replay, options = {}) {
  const events = Array.isArray(replay?.events) ? replay.events : [];
  const maximum = Math.max(1, Number(options.maxMarkers) || 240);
  const candidates = events.map((event, eventIndex) => {
    const category = timelineCategory(event);
    if (!category) return null;
    return {
      at: finiteOrNull(event.at) ?? 0,
      category,
      eventIndex,
      icon: CATEGORY_ICONS[category],
      index: eventIndex + 1,
      percent: events.length ? ((eventIndex + 1) / events.length) * 100 : 0,
      sequence: event.sequence,
      type: event.type
    };
  }).filter(Boolean);

  if (candidates.length <= maximum) return candidates;
  const important = candidates.filter((marker) => marker.category !== TIMELINE_CATEGORIES.MOVEMENT);
  const secondary = candidates.filter((marker) => marker.category === TIMELINE_CATEGORIES.MOVEMENT);
  if (important.length >= maximum) return sampleEvenly(important, maximum);
  return [...important, ...sampleEvenly(secondary, maximum - important.length)]
    .sort((left, right) => left.eventIndex - right.eventIndex);
}

export function buildVisualTimelineItems(replay, options = {}) {
  const events = Array.isArray(replay?.events) ? replay.events : [];
  const tokens = Array.isArray(replay?.tokens) ? replay.tokens : [];
  const tokensById = new Map(tokens.filter((token) => token?.id).map((token) => [token.id, token]));
  const tokensByActorId = new Map(
    tokens.filter((token) => token?.actorId).map((token) => [token.actorId, token])
  );

  return buildTimelineMarkers(replay, options).map((marker) => {
    const event = events[marker.eventIndex] ?? {};
    const data = event.data ?? {};
    const token = eventToken(data, tokensById, tokensByActorId);
    const item = data.item ?? null;
    const condition = data.condition ?? null;
    const actorName = firstString(
      data.source?.actorName,
      data.actorName,
      data.token?.name,
      data.snapshot?.name,
      token?.name
    );
    const targetNames = Array.isArray(data.targets)
      ? data.targets.map((target) => firstString(target?.name)).filter(Boolean)
      : [];

    return {
      ...marker,
      actorName,
      badge: eventBadge(event),
      image: firstString(
        item?.image,
        condition?.image,
        data.token?.appearance?.texture,
        data.token?.texture,
        data.snapshot?.appearance?.texture,
        data.snapshot?.texture,
        token?.appearance?.texture,
        token?.texture
      ),
      itemName: firstString(item?.name),
      targetNames,
      title: firstString(
        item?.name,
        condition?.name,
        data.name,
        actorName,
        event.type
      )
    };
  });
}

export function clampTimelineIndex(index, replayOrLength) {
  const length = typeof replayOrLength === "number"
    ? replayOrLength
    : Array.isArray(replayOrLength?.events) ? replayOrLength.events.length : 0;
  const value = Number(index);
  return Math.trunc(clamp(Number.isFinite(value) ? value : 0, 0, Math.max(0, length)));
}

export function computeReplayState(replay, appliedEventCount) {
  const events = Array.isArray(replay?.events) ? replay.events : [];
  const targetIndex = clampTimelineIndex(appliedEventCount, events.length);
  const tokens = new Map();

  for (const snapshot of replay?.tokens ?? []) {
    if (snapshot?.id && snapshot.initial !== false) addTokenState(tokens, snapshot);
  }

  let currentTurn = null;
  for (const event of events.slice(0, targetIndex)) {
    const data = event.data ?? {};
    switch (event.type) {
      case "turn-change":
        currentTurn = data.current ?? null;
        break;

      case "token-move": {
        const state = tokens.get(data.tokenId);
        if (!state) break;
        const destination = pickPosition(data.destination);
        state.position = mergePosition(state.position, destination);
        break;
      }

      case "combatant-added":
        addTokenState(tokens, data.token);
        break;

      case "combatant-removed":
      case "token-deleted":
        tokens.delete(data.tokenId);
        break;

      case "token-created":
        if (data.replacesTokenId) tokens.delete(data.replacesTokenId);
        addTokenState(tokens, data.token);
        break;

      case "damage":
      case "healing": {
        const state = findTokenState(tokens, data);
        if (!state) break;
        state.health = mergeHealth(state.health, data);
        break;
      }

      case "condition-added":
      case "condition-changed": {
        const state = findTokenState(tokens, data);
        if (!state || !data.condition) break;
        state.conditions.set(conditionKey(data.condition), data.condition);
        break;
      }

      case "condition-removed": {
        const state = findTokenState(tokens, data);
        if (!state || !data.condition) break;
        state.conditions.delete(conditionKey(data.condition));
        break;
      }

      default:
        break;
    }
  }

  return {
    currentEvent: targetIndex ? events[targetIndex - 1] : null,
    currentTurn,
    index: targetIndex,
    tokens: [...tokens.values()]
  };
}

function addTokenState(tokens, snapshot) {
  if (!snapshot?.id) return;
  tokens.set(snapshot.id, {
    conditions: new Map((snapshot.conditions ?? []).map((condition) => [
      conditionKey(condition),
      condition
    ])),
    health: normalizeHealth(snapshot.health),
    position: pickPosition(snapshot),
    snapshot
  });
}

function findTokenState(tokens, data) {
  if (data.tokenId && tokens.has(data.tokenId)) return tokens.get(data.tokenId);
  if (!data.actorId) return null;
  return [...tokens.values()].find((state) => state.snapshot.actorId === data.actorId) ?? null;
}

function mergePosition(current, next) {
  return {
    x: finiteOrFallback(next.x, current.x),
    y: finiteOrFallback(next.y, current.y),
    elevation: finiteOrFallback(next.elevation, current.elevation),
    rotation: finiteOrFallback(next.rotation, current.rotation)
  };
}

function mergeHealth(current, data) {
  return normalizeHealth({
    value: finiteOrFallback(data.after, current?.value),
    maximum: finiteOrFallback(data.maximum, current?.maximum),
    temporary: current?.temporary,
    temporaryMaximum: current?.temporaryMaximum
  });
}

function normalizeHealth(health) {
  if (!health || typeof health !== "object") return null;
  const result = {
    value: finiteOrNull(health.value),
    maximum: finiteOrNull(health.maximum ?? health.max),
    temporary: finiteOrNull(health.temporary ?? health.temp),
    temporaryMaximum: finiteOrNull(health.temporaryMaximum ?? health.tempmax)
  };
  return Object.values(result).every((value) => value === null) ? null : result;
}

function finiteOrFallback(value, fallback) {
  return finiteOrNull(value) ?? finiteOrNull(fallback);
}

function finiteOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function sampleEvenly(items, count) {
  if (count <= 0 || !items.length) return [];
  if (items.length <= count) return items;
  if (count === 1) return [items[0]];
  const selected = new Set();
  for (let index = 0; index < count; index += 1) {
    const sourceIndex = Math.round((index * (items.length - 1)) / (count - 1));
    selected.add(items[sourceIndex]);
  }
  return [...selected];
}

function eventToken(data, tokensById, tokensByActorId) {
  const tokenId = firstString(
    data.tokenId,
    data.source?.tokenId,
    data.current?.tokenId,
    data.targetTokenId
  );
  if (tokenId && tokensById.has(tokenId)) return tokensById.get(tokenId);
  const actorId = firstString(data.actorId, data.source?.actorId);
  return actorId ? tokensByActorId.get(actorId) ?? null : null;
}

function eventBadge(event) {
  const data = event?.data ?? {};
  if (event?.type === "turn-change") {
    const round = finiteOrNull(data.current?.round);
    return round === null ? null : `R${round}`;
  }
  if (event?.type === "damage") {
    const amount = eventAmount(data);
    return amount === null ? null : `−${amount}`;
  }
  if (event?.type === "healing") {
    const amount = eventAmount(data);
    return amount === null ? null : `+${amount}`;
  }
  if (event?.type === "attack-result") {
    const outcome = String(data.outcome ?? "").toLowerCase();
    if (["failure", "criticalfailure"].includes(outcome)) return "MISS";
    if (outcome === "criticalsuccess") return "CRIT";
    if (outcome === "success") return "HIT";
  }
  if (event?.type === "check-result" && isSavingThrowEvent(event)) {
    const outcome = String(data.outcome ?? "").toLowerCase();
    return ["success", "criticalsuccess"].includes(outcome) ? "SAVE OK" : "SAVE FAIL";
  }
  if (["attack-result", "check-result", "damage-roll"].includes(event?.type)) {
    const total = finiteOrNull(data.total);
    return total === null ? null : String(total);
  }
  if (event?.type === "item-use") {
    const rank = finiteOrNull(data.item?.castRank);
    return rank === null ? null : `R${rank}`;
  }
  const conditionValue = finiteOrNull(data.condition?.value);
  return conditionValue === null ? null : `×${conditionValue}`;
}

export function isSavingThrowEvent(event = {}) {
  const data = event.data ?? event;
  if (data.isSavingThrow === true) return true;
  const values = [data.checkType, ...(Array.isArray(data.traits) ? data.traits : [])];
  return values.some((value) => {
    return typeof value === "string" && /saving-throw|fortitude|reflex|will/i.test(value);
  });
}

function conditionKey(condition = {}) {
  return firstString(condition.uuid, condition.id, condition.slug, condition.name) ?? "condition";
}

function eventAmount(data) {
  const explicit = finiteOrNull(data.amount);
  if (explicit !== null) return Math.abs(explicit);
  const before = finiteOrNull(data.before);
  const after = finiteOrNull(data.after);
  return before === null || after === null ? null : Math.abs(after - before);
}

function firstString(...values) {
  return values.find((value) => typeof value === "string" && value.trim())?.trim() ?? null;
}
