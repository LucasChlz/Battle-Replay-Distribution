export const FEATURE_TIERS = Object.freeze({
  DEVELOPMENT: "development",
  FREE: "free",
  PATREON: "patreon"
});

export const FEATURES = Object.freeze({
  CORE_PLAYBACK: "core-playback",
  LIVE_SHARING: "live-sharing",
  TIMELINE_BASIC: "timeline-basic",
  TIMELINE_MARKERS: "timeline-markers",
  TIMELINE_SCRUB: "timeline-scrub",
  TIMELINE_STEP: "timeline-step"
});

export const FEATURE_CATALOG = Object.freeze({
  [FEATURES.CORE_PLAYBACK]: Object.freeze({
    id: FEATURES.CORE_PLAYBACK,
    minimumTier: FEATURE_TIERS.FREE
  }),
  [FEATURES.LIVE_SHARING]: Object.freeze({
    id: FEATURES.LIVE_SHARING,
    minimumTier: FEATURE_TIERS.FREE
  }),
  [FEATURES.TIMELINE_BASIC]: Object.freeze({
    id: FEATURES.TIMELINE_BASIC,
    minimumTier: FEATURE_TIERS.FREE
  }),
  [FEATURES.TIMELINE_MARKERS]: Object.freeze({
    id: FEATURES.TIMELINE_MARKERS,
    minimumTier: FEATURE_TIERS.FREE
  }),
  [FEATURES.TIMELINE_SCRUB]: Object.freeze({
    id: FEATURES.TIMELINE_SCRUB,
    minimumTier: FEATURE_TIERS.FREE
  }),
  [FEATURES.TIMELINE_STEP]: Object.freeze({
    id: FEATURES.TIMELINE_STEP,
    minimumTier: FEATURE_TIERS.FREE
  })
});

export class EntitlementService {
  constructor({ defaultTier = FEATURE_TIERS.FREE, provider = null } = {}) {
    this.defaultTier = normalizeTier(defaultTier);
    this.provider = provider;
    this.tier = this.defaultTier;
    this.metadata = {};
  }

  get status() {
    return Object.freeze({
      tier: this.tier,
      metadata: { ...this.metadata },
      features: Object.fromEntries(
        Object.values(FEATURES).map((featureId) => [featureId, this.can(featureId)])
      )
    });
  }

  can(featureId) {
    const feature = FEATURE_CATALOG[featureId];
    if (!feature) return false;
    if (this.tier === FEATURE_TIERS.DEVELOPMENT) return true;
    if (feature.minimumTier === FEATURE_TIERS.FREE) return true;
    return this.tier === FEATURE_TIERS.PATREON;
  }

  async refresh(context = {}) {
    if (!this.provider?.resolveEntitlement) {
      this.tier = this.defaultTier;
      this.metadata = {};
      return this.status;
    }

    try {
      const entitlement = await this.provider.resolveEntitlement(context);
      this.tier = normalizeTier(entitlement?.tier, this.defaultTier);
      this.metadata = sanitizeMetadata(entitlement?.metadata);
    } catch {
      this.tier = this.defaultTier;
      this.metadata = {};
    }
    return this.status;
  }

  async setProvider(provider, context = {}) {
    if (provider !== null && typeof provider?.resolveEntitlement !== "function") {
      throw new TypeError("Entitlement provider must expose resolveEntitlement(context).");
    }
    this.provider = provider;
    return this.refresh(context);
  }
}

function normalizeTier(value, fallback = FEATURE_TIERS.FREE) {
  return Object.values(FEATURE_TIERS).includes(value) ? value : fallback;
}

function sanitizeMetadata(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const result = {};
  for (const [key, entry] of Object.entries(value).slice(0, 20)) {
    if (["string", "number", "boolean"].includes(typeof entry)) result[key] = entry;
  }
  return result;
}
