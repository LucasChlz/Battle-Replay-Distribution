import { MODULE_ID } from "./constants.mjs";
import { log, warn } from "./utils.mjs";

export class CombatEventAdapter {
  constructor(recorder) {
    this.recorder = recorder;
    this.actorStates = new Map();
    this.conditionStates = new Map();
  }

  initialize() {
    log("Combat event adapter enabled for " + game.system.id + ".");
    this.seedActorStates();
  }

  seedActorStates() {
    this.actorStates.clear();
    this.conditionStates.clear();
    if (!this.recorder.active) return;
    const scene = game.scenes?.get(this.recorder.active.sceneId);
    for (const snapshot of this.recorder.active.tokens) {
      const actor = scene?.tokens?.get(snapshot.id)?.actor ?? game.actors.get(snapshot.actorId);
      if (actor) this.trackActor(actor);
    }
  }

  trackActor(actor) {
    if (!actor) return;
    this.actorStates.set(actor.uuid, snapshotActorState(actor));
    for (const item of actor.items?.filter(isCondition) ?? []) {
      this.conditionStates.set(item.uuid, conditionData(item));
    }
  }

  preUpdateActor(actor) {
    if (!this.recorder.isRecordingActor(actor)) return;
    if (!this.actorStates.has(actor.uuid)) {
      this.actorStates.set(actor.uuid, snapshotActorState(actor));
    }
  }

  updateActor(actor, _changed, _options, userId) {
    if (!this.recorder.isRecordingActor(actor)) return;

    const before = this.actorStates.get(actor.uuid) ?? snapshotActorState(actor);
    const after = snapshotActorState(actor);
    this.actorStates.set(actor.uuid, after);

    if (Number.isFinite(before.hp) && Number.isFinite(after.hp) && before.hp !== after.hp) {
      const delta = after.hp - before.hp;
      const type = delta < 0 ? "damage" : "healing";
      this.recorder.recordSemanticEvent(type, {
        actorId: actor.id,
        tokenId: this.recorder.getTokenForActor(actor),
        actorName: actor.name,
        amount: Math.abs(delta),
        before: before.hp,
        after: after.hp,
        maximum: after.hpMax,
        userId
      });

      if (before.hp > 0 && after.hp <= 0) {
        this.recorder.recordSemanticEvent("combatant-defeated", {
          actorId: actor.id,
          tokenId: this.recorder.getTokenForActor(actor),
          actorName: actor.name,
          reason: "hit-points"
        });
      }
    }
  }

  createItem(item, _options, userId) {
    const actor = item.parent;
    if (!actor || !this.recorder.isRecordingActor(actor) || !isCondition(item)) return;

    const condition = conditionData(item);
    this.conditionStates.set(item.uuid, condition);
    this.recorder.recordSemanticEvent("condition-added", {
      actorId: actor.id,
      tokenId: this.recorder.getTokenForActor(actor),
      actorName: actor.name,
      condition,
      userId
    });

    if (["dead", "dying", "unconscious"].includes(condition.slug)) {
      this.recorder.recordSemanticEvent("combatant-defeated", {
        actorId: actor.id,
        tokenId: this.recorder.getTokenForActor(actor),
        actorName: actor.name,
        reason: condition.slug
      });
    }
  }

  deleteItem(item, _options, userId) {
    const actor = item.parent;
    if (!actor || !this.recorder.isRecordingActor(actor) || !isCondition(item)) return;
    const condition = this.conditionStates.get(item.uuid) ?? conditionData(item);
    this.conditionStates.delete(item.uuid);
    this.recorder.recordSemanticEvent("condition-removed", {
      actorId: actor.id,
      tokenId: this.recorder.getTokenForActor(actor),
      actorName: actor.name,
      condition,
      userId
    });
  }

  preUpdateItem(item) {
    const actor = item.parent;
    if (!actor || !this.recorder.isRecordingActor(actor) || !isCondition(item)) return;
    if (!this.conditionStates.has(item.uuid)) {
      this.conditionStates.set(item.uuid, conditionData(item));
    }
  }

  updateItem(item, _changed, _options, userId) {
    const actor = item.parent;
    if (!actor || !this.recorder.isRecordingActor(actor) || !isCondition(item)) return;
    const before = this.conditionStates.get(item.uuid) ?? conditionData(item);
    const after = conditionData(item);
    this.conditionStates.set(item.uuid, after);
    if (JSON.stringify(before) === JSON.stringify(after)) return;

    this.recorder.recordSemanticEvent("condition-changed", {
      actorId: actor.id,
      tokenId: this.recorder.getTokenForActor(actor),
      actorName: actor.name,
      before,
      condition: after,
      userId
    });
  }

  createChatMessage(message) {
    if (!this.recorder.active || !this.recorder.isAuthoritativeGM()) return;
    if (game.system.id !== "pf2e") return;
    if (message.getFlag(MODULE_ID, "ignore")) return;

    const normalized = normalizePf2eChatMessage(message, this.recorder);
    if (!normalized) return;

    if (normalized.item && !this.hasRecentItemUse(normalized)) {
      this.recorder.recordSemanticEvent("item-use", {
        messageId: message.id,
        source: normalized.source,
        targets: normalized.targets,
        item: normalized.item,
        traits: normalized.traits
      });
    }

    if (normalized.kind === "attack") {
      this.recorder.recordSemanticEvent("attack-result", {
        messageId: message.id,
        source: normalized.source,
        targets: normalized.targets,
        item: normalized.item,
        outcome: normalized.outcome,
        unadjustedOutcome: normalized.unadjustedOutcome,
        total: normalized.total,
        formula: normalized.formula,
        dc: normalized.dc,
        traits: normalized.traits
      });
    } else if (normalized.kind === "damage-roll") {
      this.recorder.recordSemanticEvent("damage-roll", {
        messageId: message.id,
        source: normalized.source,
        targets: normalized.targets,
        item: normalized.item,
        outcome: normalized.outcome,
        total: normalized.total,
        formula: normalized.formula,
        traits: normalized.traits
      });
    } else if (normalized.kind === "check") {
      this.recorder.recordSemanticEvent("check-result", {
        messageId: message.id,
        source: normalized.source,
        targets: normalized.targets,
        item: normalized.item,
        checkType: normalized.checkType,
        isSavingThrow: normalized.isSavingThrow,
        outcome: normalized.outcome,
        unadjustedOutcome: normalized.unadjustedOutcome,
        total: normalized.total,
        formula: normalized.formula,
        dc: normalized.dc,
        traits: normalized.traits
      });
    }
  }

  hasRecentItemUse(normalized) {
    const events = this.recorder.active?.events ?? [];
    const last = events.findLast((event) => event.type === "item-use");
    if (!last) return false;
    const sameActor = last.data?.source?.actorId === normalized.source?.actorId;
    const sameItem = last.data?.item?.uuid && last.data.item.uuid === normalized.item?.uuid;
    return sameActor && sameItem && (Date.now() - this.recorder.active.startedAt - last.at) < 5000;
  }

  targetToken(user, token, targeted) {
    if (!this.recorder.active || !token?.document) return;
    if (token.document.parent?.id !== this.recorder.active.sceneId) return;
    const combat = game.combats.get(this.recorder.active.combatId);
    const sourceTokenId = combat?.combatant?.tokenId ?? null;
    this.recorder.recordSemanticEvent("target-change", {
      userId: user.id,
      sourceTokenId,
      targetTokenId: token.document.id,
      targeted: Boolean(targeted)
    });
  }
}

export function normalizePf2eChatMessage(message, recorder) {
  try {
    const flags = message.flags?.pf2e ?? {};
    const context = flags.context ?? {};
    const actorId = context.actor ?? message.speaker?.actor ?? null;
    const actor = actorId ? game.actors.get(actorId) : null;
    if (!actor || !recorder.isRecordingActor(actor)) return null;

    const origin = flags.origin ?? null;
    const item = resolveItem(origin?.uuid);
    const domains = Array.isArray(context.domains) ? context.domains : [];
    const traits = Array.isArray(context.traits) ? context.traits.slice(0, 30) : [];
    const contextType = String(context.type ?? "");
    const attack = contextType === "attack-roll" ||
      domains.includes("attack-roll") ||
      domains.includes("strike-attack-roll");
    const damageRoll = contextType === "damage-roll" ||
      message.rolls?.some((roll) => String(roll.constructor?.name).includes("DamageRoll"));
    const isCheck = Boolean(message.rolls?.length) && !damageRoll;
    const roll = message.rolls?.[0] ?? null;
    const targets = normalizeTargets(context, flags);
    const savingThrow = savingThrowData(context, domains, traits);

    return {
      kind: attack ? "attack" : damageRoll ? "damage-roll" : isCheck ? "check" : "item",
      source: {
        actorId: actor.id,
        actorName: actor.name,
        tokenId: context.token ?? message.speaker?.token ?? recorder.getTokenForActor(actor)
      },
      targets,
      item: origin || item ? {
        uuid: origin?.uuid ?? item?.uuid ?? null,
        id: item?.id ?? null,
        name: item?.name ?? message.item?.name ?? extractMessageTitle(message),
        type: origin?.type ?? item?.type ?? null,
        image: item?.img ?? null,
        castRank: finiteOrNull(origin?.castRank)
      } : null,
      checkType: savingThrow.type ?? (contextType || null),
      isSavingThrow: savingThrow.isSavingThrow,
      outcome: context.outcome ?? null,
      unadjustedOutcome: context.unadjustedOutcome ?? null,
      total: finiteOrNull(roll?.total),
      formula: typeof roll?.formula === "string" ? roll.formula : null,
      dc: finiteOrNull(context.dc?.value),
      traits
    };
  } catch (error) {
    warn("Could not normalize a combat ChatMessage.", error);
    return null;
  }
}

function savingThrowData(context, domains, traits) {
  const candidates = [
    context.statistic,
    context.statisticSlug,
    context.slug,
    context.identifier,
    ...domains,
    ...traits
  ].filter((entry) => typeof entry === "string").map((entry) => entry.toLowerCase());
  const save = candidates.find((entry) => ["fortitude", "reflex", "will"].includes(entry)) ?? null;
  const isSavingThrow = context.type === "saving-throw" ||
    candidates.some((entry) => entry === "saving-throw" || entry.includes("saving-throw"));
  return {
    isSavingThrow,
    type: isSavingThrow ? save ?? "saving-throw" : null
  };
}

function normalizeTargets(context, flags) {
  const target = context.target ?? flags.target ?? null;
  if (!target) return [];
  const tokenUuid = target.token ?? null;
  const token = resolveDocument(tokenUuid);
  return [{
    actorUuid: target.actor ?? null,
    tokenUuid,
    actorId: token?.actorId ?? token?.actor?.id ?? null,
    tokenId: token?.id ?? uuidTail(tokenUuid),
    name: token?.name ?? token?.actor?.name ?? null
  }];
}

function resolveItem(uuid) {
  const document = resolveDocument(uuid);
  return document?.documentName === "Item" || document?.constructor?.name?.includes("Item")
    ? document
    : null;
}

function resolveDocument(uuid) {
  if (!uuid || typeof uuid !== "string") return null;
  try {
    return fromUuidSync(uuid);
  } catch {
    return null;
  }
}

function extractMessageTitle(message) {
  const html = String(message.flavor ?? message.content ?? "");
  const element = document.createElement("div");
  element.innerHTML = html;
  return element.querySelector("h3, h4, strong")?.textContent?.trim() ||
    message.speaker?.alias ||
    null;
}

function snapshotActorState(actor) {
  return {
    hp: finiteOrNull(foundry.utils.getProperty(actor, "system.attributes.hp.value")),
    hpMax: finiteOrNull(foundry.utils.getProperty(actor, "system.attributes.hp.max"))
  };
}

function isCondition(item) {
  return item.type === "condition" || item.type === "effect";
}

function conditionData(item) {
  return {
    id: item.id,
    uuid: item.uuid,
    name: item.name,
    slug: String(item.slug ?? item.system?.slug ?? item.name ?? "")
      .trim()
      .toLowerCase()
      .replaceAll(" ", "-"),
    value: finiteOrNull(foundry.utils.getProperty(item, "system.value.value")),
    image: item.img ?? null
  };
}

function uuidTail(uuid) {
  return typeof uuid === "string" ? uuid.split(".").at(-1) : null;
}

function finiteOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}
