const RECENT_EVENT_WINDOW_MS = 15_000;

export function buildCombatAnalytics(source = {}) {
  const replay = source && typeof source === "object" ? source : {};
  const events = Array.isArray(replay.events) ? replay.events : [];
  const participants = new Map();
  const tokenKeys = new Map();
  const actorKeys = new Map();
  const actorNames = new Map();

  const addParticipant = (reference = {}, fallback = {}) => {
    const tokenId = firstString(reference.tokenId, reference.id, fallback.tokenId, fallback.id);
    const actorId = firstString(reference.actorId, fallback.actorId);
    const name = firstString(
      reference.actorName,
      reference.name,
      fallback.actorName,
      fallback.name,
      "Unknown combatant"
    );
    const knownTokenKey = tokenId ? tokenKeys.get(tokenId) : null;
    const knownActorKeys = actorId ? actorKeys.get(actorId) : null;
    const nameKey = normalizeName(name);
    const knownNameKey = actorNames.get(nameKey);
    const key = knownTokenKey ??
      (knownActorKeys?.size === 1 ? [...knownActorKeys][0] : null) ??
      knownNameKey ??
      (tokenId ? `token:${tokenId}` : actorId ? `actor:${actorId}` : `name:${nameKey}`);

    if (!participants.has(key)) {
      participants.set(key, createParticipant({
        actorId,
        disposition: finiteOrNull(reference.disposition ?? fallback.disposition),
        id: key,
        image: tokenImage(reference) ?? tokenImage(fallback),
        name,
        tokenId
      }));
    } else {
      const participant = participants.get(key);
      participant.name = participant.name === "Unknown combatant" ? name : participant.name;
      participant.image ??= tokenImage(reference) ?? tokenImage(fallback);
      participant.actorId ??= actorId;
      participant.tokenId ??= tokenId;
      participant.disposition ??= finiteOrNull(reference.disposition ?? fallback.disposition);
    }

    if (tokenId) tokenKeys.set(tokenId, key);
    if (actorId) {
      if (!actorKeys.has(actorId)) actorKeys.set(actorId, new Set());
      actorKeys.get(actorId).add(key);
    }
    if (nameKey) actorNames.set(nameKey, key);
    return key;
  };

  for (const token of replay.tokens ?? []) addParticipant(token);
  for (const event of events) {
    const data = event?.data ?? {};
    if (data.token) addParticipant(data.token);
    if (data.snapshot) addParticipant(data.snapshot);
    if (data.source) addParticipant(data.source);
    for (const target of data.targets ?? []) addParticipant(target);
    if (data.actorId || data.tokenId || data.actorName) addParticipant(data);
  }

  const resolve = (reference) => {
    if (!reference || typeof reference !== "object") return null;
    const tokenId = firstString(reference.tokenId, reference.id);
    if (tokenId && tokenKeys.has(tokenId)) return tokenKeys.get(tokenId);
    const actorId = firstString(reference.actorId);
    const keys = actorId ? actorKeys.get(actorId) : null;
    if (keys?.size === 1) return [...keys][0];
    const name = firstString(reference.actorName, reference.name);
    if (name && actorNames.has(normalizeName(name))) return actorNames.get(normalizeName(name));
    return addParticipant(reference);
  };

  let currentRound = 1;
  let activeTurnKey = null;
  let maximumRound = finiteOrNull(replay.metadata?.rounds) ?? 0;
  const recentDamageRolls = [];
  const recentItems = [];
  const lastDamageByTarget = new Map();
  const downParticipants = new Set();
  const creditedDefeats = new Set();
  let totalDamage = 0;
  let totalHealing = 0;
  let totalAttacks = 0;
  let totalHits = 0;
  let totalCriticals = 0;

  for (const event of events) {
    const data = event?.data ?? {};
    const at = finiteOrNull(event.at) ?? 0;
    pruneRecent(recentDamageRolls, at);
    pruneRecent(recentItems, at);

    if (event.type === "turn-change") {
      currentRound = finiteOrNull(data.current?.round) ?? currentRound;
      maximumRound = Math.max(maximumRound, currentRound);
      activeTurnKey = resolve(data.current);
      if (activeTurnKey) participants.get(activeTurnKey).turnStarts.push(at);
      continue;
    }

    if (event.type === "round-complete") {
      maximumRound = Math.max(maximumRound, finiteOrNull(data.round) ?? currentRound);
      continue;
    }

    if (event.type === "item-use") {
      const sourceKey = resolve(data.source) ?? activeTurnKey;
      const targetKeys = resolveTargets(data.targets, resolve);
      if (sourceKey) {
        const participant = participants.get(sourceKey);
        participant.actions += 1;
        incrementRound(participant.actionRounds, currentRound, 1);
        if (isSpell(data.item)) participant.spellsUsed += 1;
        recentItems.push({ at, sourceKey, targetKeys });
      }
      continue;
    }

    if (event.type === "attack-result") {
      const sourceKey = resolve(data.source) ?? activeTurnKey;
      if (!sourceKey) continue;
      const participant = participants.get(sourceKey);
      const outcome = normalizeOutcome(data.outcome);
      participant.attacks += 1;
      totalAttacks += 1;
      if (isSuccessful(outcome)) {
        participant.hits += 1;
        totalHits += 1;
      }
      if (outcome === "criticalsuccess") {
        participant.criticals += 1;
        totalCriticals += 1;
      }
      if (outcome === "criticalfailure") participant.criticalFailures += 1;
      continue;
    }

    if (event.type === "check-result") {
      const sourceKey = resolve(data.source) ?? activeTurnKey;
      if (!sourceKey || !isSavingThrow(data.checkType)) continue;
      if (isSuccessful(normalizeOutcome(data.outcome))) {
        participants.get(sourceKey).successfulSaves += 1;
      }
      continue;
    }

    if (event.type === "damage-roll") {
      const sourceKey = resolve(data.source) ?? activeTurnKey;
      if (sourceKey) {
        recentDamageRolls.push({
          at,
          sourceKey,
          targetKeys: resolveTargets(data.targets, resolve)
        });
      }
      continue;
    }

    if (event.type === "damage") {
      const targetKey = resolve(data);
      const amount = eventAmount(data);
      if (!targetKey || amount === null) continue;
      const explicitSourceKey = resolve(data.source);
      const sourceKey = explicitSourceKey ?? claimRecent(recentDamageRolls, targetKey, at) ?? activeTurnKey;
      const target = participants.get(targetKey);
      target.damageReceived += amount;
      totalDamage += amount;
      if (sourceKey) {
        const source = participants.get(sourceKey);
        source.damageCaused += amount;
        source.maxDamage = Math.max(source.maxDamage, amount);
        incrementRound(source.damageRounds, currentRound, amount);
        lastDamageByTarget.set(targetKey, { at, sourceKey });
      }
      const before = finiteOrNull(data.before);
      const after = finiteOrNull(data.after);
      if (after !== null && after <= 0 && (before === null || before > 0) && !downParticipants.has(targetKey)) {
        target.zeroHp += 1;
        downParticipants.add(targetKey);
      }
      continue;
    }

    if (event.type === "healing") {
      const targetKey = resolve(data);
      const amount = eventAmount(data);
      if (!targetKey || amount === null) continue;
      const explicitSourceKey = resolve(data.source);
      const sourceKey = explicitSourceKey ?? claimRecent(recentItems, targetKey, at) ?? activeTurnKey;
      const target = participants.get(targetKey);
      target.healingReceived += amount;
      totalHealing += amount;
      if (sourceKey) {
        const source = participants.get(sourceKey);
        source.healingDone += amount;
        source.maxHealing = Math.max(source.maxHealing, amount);
      }
      const after = finiteOrNull(data.after);
      if (after !== null && after > 0) {
        downParticipants.delete(targetKey);
        creditedDefeats.delete(targetKey);
      }
      continue;
    }

    if (event.type === "condition-added") {
      const targetKey = resolve(data);
      if (!targetKey) continue;
      participants.get(targetKey).conditionsReceived += 1;
      const sourceKey = resolve(data.source) ?? claimRecent(recentItems, targetKey, at) ?? activeTurnKey;
      if (sourceKey) participants.get(sourceKey).conditionsApplied += 1;
      continue;
    }

    if (event.type === "combatant-defeated") {
      const targetKey = resolve(data);
      if (!targetKey || creditedDefeats.has(targetKey)) continue;
      const recentDamage = lastDamageByTarget.get(targetKey);
      const sourceKey = resolve(data.source) ?? (
        recentDamage && at - recentDamage.at <= RECENT_EVENT_WINDOW_MS
          ? recentDamage.sourceKey
          : activeTurnKey
      );
      if (sourceKey && sourceKey !== targetKey) participants.get(sourceKey).defeats += 1;
      creditedDefeats.add(targetKey);
    }
  }

  const rounds = Math.max(1, maximumRound || inferRounds(events));
  const rows = [...participants.values()].map((participant) => finalizeParticipant(participant, rounds));
  rows.sort((left, right) => right.damageCaused - left.damageCaused || left.name.localeCompare(right.name));

  return {
    generatedAt: Date.now(),
    replay: {
      duration: finiteOrNull(replay.metadata?.duration) ?? Math.max(0, (
        finiteOrNull(replay.endedAt) ?? finiteOrNull(replay.startedAt) ?? 0
      ) - (finiteOrNull(replay.startedAt) ?? 0)),
      id: replay.id ?? null,
      sceneName: replay.sceneName ?? "",
      startedAt: finiteOrNull(replay.startedAt),
      title: replay.title ?? ""
    },
    rounds,
    participants: rows,
    totals: {
      accuracy: percentage(totalHits, totalAttacks),
      attacks: totalAttacks,
      criticals: totalCriticals,
      damage: totalDamage,
      healing: totalHealing,
      hits: totalHits
    }
  };
}

function createParticipant({ actorId, disposition, id, image, name, tokenId }) {
  return {
    actionRounds: new Map(),
    actions: 0,
    actorId,
    attacks: 0,
    conditionsApplied: 0,
    conditionsReceived: 0,
    criticalFailures: 0,
    criticals: 0,
    damageCaused: 0,
    damageReceived: 0,
    damageRounds: new Map(),
    defeats: 0,
    disposition,
    healingDone: 0,
    healingReceived: 0,
    hits: 0,
    id,
    image,
    maxDamage: 0,
    maxHealing: 0,
    name,
    spellsUsed: 0,
    successfulSaves: 0,
    tokenId,
    turnStarts: [],
    zeroHp: 0
  };
}

function finalizeParticipant(participant, rounds) {
  const intervals = participant.turnStarts.slice(1).map((at, index) => at - participant.turnStarts[index])
    .filter((value) => Number.isFinite(value) && value >= 0);
  const streak = longestDamageStreak(participant.damageRounds, rounds);
  const { actionRounds: _actionRounds, damageRounds: _damageRounds, turnStarts: _turnStarts, ...publicData } = participant;
  return {
    ...publicData,
    accuracy: percentage(participant.hits, participant.attacks),
    actionsPerRound: roundTo(participant.actions / rounds, 1),
    averageTurnInterval: intervals.length ? Math.round(sum(intervals) / intervals.length) : null,
    damageStreak: streak
  };
}

function longestDamageStreak(damageRounds, rounds) {
  let currentDamage = 0;
  let currentRounds = 0;
  let bestDamage = 0;
  let bestRounds = 0;
  for (let round = 1; round <= rounds; round += 1) {
    const damage = damageRounds.get(round) ?? 0;
    if (damage > 0) {
      currentDamage += damage;
      currentRounds += 1;
      if (currentRounds > bestRounds || (currentRounds === bestRounds && currentDamage > bestDamage)) {
        bestDamage = currentDamage;
        bestRounds = currentRounds;
      }
    } else {
      currentDamage = 0;
      currentRounds = 0;
    }
  }
  return { damage: bestDamage, rounds: bestRounds };
}

function claimRecent(entries, targetKey, at) {
  for (let index = entries.length - 1; index >= 0; index -= 1) {
    const entry = entries[index];
    if (at - entry.at > RECENT_EVENT_WINDOW_MS) continue;
    if (entry.targetKeys.size && !entry.targetKeys.has(targetKey)) continue;
    if (entry.targetKeys.size) entry.targetKeys.delete(targetKey);
    if (!entry.targetKeys.size) entries.splice(index, 1);
    return entry.sourceKey;
  }
  return null;
}

function pruneRecent(entries, at) {
  while (entries.length && at - entries[0].at > RECENT_EVENT_WINDOW_MS) entries.shift();
}

function resolveTargets(targets, resolve) {
  return new Set((Array.isArray(targets) ? targets : []).map(resolve).filter(Boolean));
}

function incrementRound(map, round, amount) {
  map.set(round, (map.get(round) ?? 0) + amount);
}

function eventAmount(data) {
  const explicit = finiteOrNull(data.amount);
  if (explicit !== null) return Math.abs(explicit);
  const before = finiteOrNull(data.before);
  const after = finiteOrNull(data.after);
  return before === null || after === null ? null : Math.abs(after - before);
}

function inferRounds(events) {
  return events.reduce((maximum, event) => {
    const round = finiteOrNull(event?.data?.current?.round ?? event?.data?.round);
    return round === null ? maximum : Math.max(maximum, round);
  }, 1);
}

function isSpell(item) {
  return item?.type === "spell" || finiteOrNull(item?.castRank) !== null;
}

function isSavingThrow(checkType) {
  return /saving|save|fortitude|reflex|will/i.test(String(checkType ?? ""));
}

function isSuccessful(outcome) {
  return outcome === "success" || outcome === "criticalsuccess";
}

function normalizeOutcome(value) {
  return String(value ?? "").toLowerCase().replace(/[^a-z]/g, "");
}

function percentage(value, total) {
  return total > 0 ? roundTo((value / total) * 100, 1) : 0;
}

function tokenImage(reference) {
  if (!reference || typeof reference !== "object") return null;
  if (typeof reference.image === "string") return reference.image;
  if (typeof reference.actorImage === "string") return reference.actorImage;
  if (typeof reference.appearance?.texture === "string") return reference.appearance.texture;
  if (typeof reference.texture === "string") return reference.texture;
  return typeof reference.texture?.src === "string" ? reference.texture.src : null;
}

function normalizeName(value) {
  return String(value ?? "").trim().toLocaleLowerCase();
}

function firstString(...values) {
  return values.find((value) => typeof value === "string" && value.trim())?.trim() ?? null;
}

function finiteOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function roundTo(value, digits) {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function sum(values) {
  return values.reduce((total, value) => total + value, 0);
}
