import {
  CINEMATIC_PRESETS,
  CREATOR_FORMATS,
  DIALOG_ID,
  LIBRARY_THEMES,
  LIMITS,
  MODULE_ID,
  RECORDING_MODES,
  SETTINGS,
  TOOL_ID
} from "./constants.mjs";
import { buildCombatAnalytics } from "./analytics.mjs";
import { LIVE_REPLAY_VISIBILITY } from "./live-replay.mjs";
import {
  escapeHtml,
  formatBytes,
  formatDuration,
  localize,
  slugifyFilename,
  warn
} from "./utils.mjs";

export function attachReplayControl(controls, openLibrary) {
  if (!game.user?.isGM) return;

  const control = controls?.tokens ??
    Object.values(controls ?? {}).find((entry) => entry?.tools);

  if (!control?.tools || control.tools[TOOL_ID]) return;

  control.tools[TOOL_ID] = {
    button: true,
    icon: "fa-solid fa-forward-fast",
    name: TOOL_ID,
    onChange: () => void openLibrary(),
    order: Object.keys(control.tools).length + 100,
    title: localize("BATTLE_REPLAY.controls.open"),
    visible: true
  };
}

export async function openReplayLibrary({ storage, recorder, playback, liveReplay }) {
  const existing = foundry.applications.instances.get(DIALOG_ID);
  if (existing) {
    await existing.bringToFront();
    return existing;
  }

  const replays = storage.getReplays();
  const activeRecording = recorder.active ?? storage.getActiveRecording();
  const content = buildLibraryContent(
    replays,
    activeRecording,
    storage.getStorageStats(),
    Boolean(recorder.active)
  );

  const dialog = new foundry.applications.api.DialogV2({
    id: DIALOG_ID,
    window: {
      title: localize("BATTLE_REPLAY.library.title")
    },
    content,
    buttons: [
      {
        action: "play",
        icon: "fa-solid fa-play",
        label: localize("BATTLE_REPLAY.library.play"),
        default: true,
        callback: async (_event, button) => {
          const replay = getSelectedReplay(button.form, storage);
          if (!replay) {
            ui.notifications.warn(localize("BATTLE_REPLAY.notifications.selectReplay"));
            return false;
          }
          void playback.play(replay, { interactive: true });
          return "play";
        }
      },
      {
        action: "close",
        icon: "fa-solid fa-xmark",
        label: localize("BATTLE_REPLAY.library.close")
      }
    ]
  });

  await dialog.render(true);
  attachLibraryListeners(dialog, { storage, recorder, playback, liveReplay });
  return dialog;
}

function attachLibraryListeners(dialog, dependencies) {
  const { storage, recorder, playback, liveReplay } = dependencies;
  const root = dialog.element;
  const form = getLibraryForm(dialog);
  const mode = root.querySelector("[name='recordingMode']");
  const speed = root.querySelector("[name='playbackSpeed']");
  const search = root.querySelector("[name='search']");
  const scene = root.querySelector("[name='sceneFilter']");
  const system = root.querySelector("[name='systemFilter']");
  const date = root.querySelector("[name='dateFilter']");
  const favorites = root.querySelector("[name='favoritesOnly']");
  const theme = root.querySelector("[name='libraryTheme']");
  const directorEnabled = root.querySelector("[name='cinematicEnabled']");
  const director = root.querySelector("[name='cinematicPreset']");
  const directorPresetGroup = root.querySelector("[data-role='director-preset-group']");
  const creatorFormat = root.querySelector("[name='creatorFormat']");
  const creatorFormatGroup = root.querySelector("[data-role='creator-format-group']");

  applyLibraryTheme(root, theme?.value);
  updateDirectorVisibility();

  for (const image of root.querySelectorAll(".battle-replay-avatar img")) {
    const showFallback = () => image.closest(".battle-replay-avatar")?.classList.remove("has-image");
    image.addEventListener("error", showFallback, { once: true });
    if (image.complete && !image.naturalWidth) showFallback();
  }

  mode?.addEventListener("change", async (event) => {
    const automatic = event.currentTarget.value === RECORDING_MODES.AUTOMATIC;
    await game.settings.set(MODULE_ID, SETTINGS.AUTO_RECORD, automatic);
    ui.notifications.info(localize("BATTLE_REPLAY.notifications.recordingModeChanged", {
      mode: localize(automatic
        ? "BATTLE_REPLAY.library.automatic"
        : "BATTLE_REPLAY.library.manual")
    }));
  });

  speed?.addEventListener("change", async (event) => {
    await game.settings.set(MODULE_ID, SETTINGS.PLAYBACK_SPEED, Number(event.currentTarget.value));
  });

  theme?.addEventListener("change", async (event) => {
    const value = event.currentTarget.value;
    applyLibraryTheme(root, value);
    await game.settings.set(MODULE_ID, SETTINGS.LIBRARY_THEME, value);
  });

  director?.addEventListener("change", async (event) => {
    updateCreatorFormatVisibility();
    await game.settings.set(MODULE_ID, SETTINGS.CINEMATIC_PRESET, event.currentTarget.value);
  });

  directorEnabled?.addEventListener("change", async (event) => {
    updateDirectorVisibility();
    if (event.currentTarget.checked && director?.value) {
      await game.settings.set(MODULE_ID, SETTINGS.CINEMATIC_PRESET, director.value);
    }
    await game.settings.set(MODULE_ID, SETTINGS.CINEMATIC_ENABLED, event.currentTarget.checked);
  });

  creatorFormat?.addEventListener("change", async (event) => {
    await game.settings.set(MODULE_ID, SETTINGS.CREATOR_FORMAT, event.currentTarget.value);
  });

  function updateCreatorFormatVisibility() {
    const visible = directorEnabled?.checked && director?.value === CINEMATIC_PRESETS.CREATOR;
    if (creatorFormatGroup) creatorFormatGroup.hidden = !visible;
    if (creatorFormat) creatorFormat.disabled = !visible;
  }

  function updateDirectorVisibility() {
    const enabled = Boolean(directorEnabled?.checked);
    if (directorPresetGroup) directorPresetGroup.hidden = !enabled;
    if (director) director.disabled = !enabled;
    updateCreatorFormatVisibility();
  }

  const applyFilters = () => {
    const query = String(search?.value ?? "").trim().toLocaleLowerCase();
    for (const row of root.querySelectorAll(".battle-replay-row")) {
      const visible = (!query || row.dataset.search.includes(query)) &&
        (!scene?.value || row.dataset.scene === scene.value) &&
        (!system?.value || row.dataset.system === system.value) &&
        (!date?.value || Number(row.dataset.started) >= (
          Date.now() - (Number(date.value) * 24 * 60 * 60 * 1000)
        )) &&
        (!favorites?.checked || row.dataset.favorite === "true");
      row.hidden = !visible;
    }
    updateVisibleCount(root);
  };

  search?.addEventListener("input", applyFilters);
  scene?.addEventListener("change", applyFilters);
  system?.addEventListener("change", applyFilters);
  date?.addEventListener("change", applyFilters);
  favorites?.addEventListener("change", applyFilters);

  root.addEventListener("click", async (event) => {
    const target = event.target.closest("[data-action]");
    if (!target) return;
    event.preventDefault();

    const action = target.dataset.action;
    try {
      if (action === "cancel-recording") {
        const confirmed = await confirmAction(
          "BATTLE_REPLAY.library.cancelRecordingTitle",
          "BATTLE_REPLAY.library.cancelRecordingConfirm",
          "BATTLE_REPLAY.library.cancelRecording"
        );
        if (confirmed) {
          await recorder.cancel();
          await refreshLibrary(dialog, dependencies);
        }
      } else if (action === "rename") {
        const replay = getSelectedReplay(form, storage);
        if (replay && await editReplayMetadata(replay, storage)) {
          await refreshLibrary(dialog, dependencies);
        }
      } else if (action === "favorite") {
        const replay = getSelectedReplay(form, storage);
        if (replay) {
          await storage.updateReplay(replay.id, { favorite: !replay.favorite });
          await refreshLibrary(dialog, dependencies);
        }
      } else if (action === "export") {
        exportSelectedReplays(form, storage);
      } else if (action === "import") {
        root.querySelector("[name='importFile']")?.click();
      } else if (action === "delete") {
        const replayIds = getMarkedReplayIds(form);
        if (!replayIds.length) {
          ui.notifications.warn(localize("BATTLE_REPLAY.notifications.selectReplay"));
          return;
        }
        const confirmed = await confirmAction(
          "BATTLE_REPLAY.library.deleteTitle",
          "BATTLE_REPLAY.library.deleteManyConfirm",
          "BATTLE_REPLAY.library.delete",
          { count: replayIds.length }
        );
        if (confirmed) {
          await storage.deleteReplays(replayIds);
          ui.notifications.info(localize("BATTLE_REPLAY.notifications.replayDeleted"));
          await refreshLibrary(dialog, dependencies);
        }
      } else if (action === "play-row") {
        const replay = storage.getReplay(target.dataset.replayId);
        if (replay) {
          await dialog.close();
          void playback.play(replay, { interactive: true });
        }
      } else if (action === "analytics") {
        const replay = getSelectedReplay(form, storage);
        if (!replay) {
          ui.notifications.warn(localize("BATTLE_REPLAY.notifications.selectReplay"));
          return;
        }
        await openCombatAnalytics(replay);
      } else if (action === "live") {
        const replay = getSelectedReplay(form, storage);
        if (!replay) {
          ui.notifications.warn(localize("BATTLE_REPLAY.notifications.selectReplay"));
          return;
        }
        const visibilityMode = await chooseLiveVisibilityMode();
        if (!visibilityMode) return;
        await dialog.close();
        liveReplay?.start(replay, { visibilityMode });
      }
    } catch (error) {
      warn("Library action failed.", error);
      ui.notifications.error(localize("BATTLE_REPLAY.notifications.libraryActionFailed"));
    }
  });

  root.querySelector("[name='importFile']")?.addEventListener("change", async (event) => {
    const files = Array.from(event.currentTarget.files ?? []);
    if (!files.length) return;
    let imported = 0;

    try {
      for (const file of files) {
        if (file.size > LIMITS.MAX_IMPORT_BYTES) {
          ui.notifications.warn(localize("BATTLE_REPLAY.notifications.importTooLarge"));
          continue;
        }
        const payload = JSON.parse(await file.text());
        const sources = Array.isArray(payload?.replays) ? payload.replays : [payload];
        for (const source of sources) {
          const result = await storage.importReplay(source);
          if (result.valid) imported += 1;
        }
      }

      if (imported) {
        ui.notifications.info(localize("BATTLE_REPLAY.notifications.imported", { count: imported }));
        await refreshLibrary(dialog, dependencies);
      } else {
        ui.notifications.warn(localize("BATTLE_REPLAY.notifications.importInvalid"));
      }
    } catch (error) {
      warn("Replay import failed.", error);
      ui.notifications.error(localize("BATTLE_REPLAY.notifications.importInvalid"));
    }
  });
}

export async function chooseLiveVisibilityMode() {
  return foundry.applications.api.DialogV2.prompt({
    window: { title: localize("BATTLE_REPLAY.library.liveVisibilityTitle") },
    content: [
      '<div class="battle-replay-visibility-choice">',
      '<p>', localize("BATTLE_REPLAY.library.liveVisibilityHint"), '</p>',
      '<label><input type="radio" name="visibilityMode" value="',
      LIVE_REPLAY_VISIBILITY.PLAYERS,
      '" checked><span><strong><i class="fa-solid fa-user-shield"></i> ',
      localize("BATTLE_REPLAY.library.liveVisibilityPlayers"),
      '</strong><small>', localize("BATTLE_REPLAY.library.liveVisibilityPlayersHint"),
      '</small></span></label>',
      '<label><input type="radio" name="visibilityMode" value="',
      LIVE_REPLAY_VISIBILITY.REVEAL,
      '"><span><strong><i class="fa-solid fa-eye"></i> ',
      localize("BATTLE_REPLAY.library.liveVisibilityReveal"),
      '</strong><small>', localize("BATTLE_REPLAY.library.liveVisibilityRevealHint"),
      '</small></span></label></div>'
    ].join(""),
    rejectClose: false,
    ok: {
      label: localize("BATTLE_REPLAY.library.startLiveReplay"),
      callback: (_event, button) => {
        return button.form?.querySelector?.("[name='visibilityMode']:checked")?.value ??
          LIVE_REPLAY_VISIBILITY.PLAYERS;
      }
    }
  });
}

export function getLibraryForm(dialog) {
  return dialog?.element?.querySelector?.("form") ?? dialog?.form ?? null;
}

export function buildLibraryContent(replays, activeRecording, stats, canCancel) {
  const automatic = Boolean(game.settings.get(MODULE_ID, SETTINGS.AUTO_RECORD));
  const speed = Number(game.settings.get(MODULE_ID, SETTINGS.PLAYBACK_SPEED)) || 2;
  const storedTheme = String(game.settings.get(MODULE_ID, SETTINGS.LIBRARY_THEME) ?? "");
  const theme = Object.values(LIBRARY_THEMES).includes(storedTheme)
    ? storedTheme
    : LIBRARY_THEMES.DARK;
  const storedDirector = String(game.settings.get(MODULE_ID, SETTINGS.CINEMATIC_PRESET) ?? "");
  const director = Object.values(CINEMATIC_PRESETS).includes(storedDirector) &&
      storedDirector !== CINEMATIC_PRESETS.OFF
    ? storedDirector
    : CINEMATIC_PRESETS.CINEMATIC;
  const directorEnabled = Boolean(game.settings.get(MODULE_ID, SETTINGS.CINEMATIC_ENABLED)) &&
    storedDirector !== CINEMATIC_PRESETS.OFF;
  const storedCreatorFormat = String(game.settings.get(MODULE_ID, SETTINGS.CREATOR_FORMAT) ?? "");
  const creatorFormat = Object.values(CREATOR_FORMATS).includes(storedCreatorFormat)
    ? storedCreatorFormat
    : CREATOR_FORMATS.AUTO;
  const modeOptions = [
    option(RECORDING_MODES.AUTOMATIC, "BATTLE_REPLAY.library.automatic", automatic),
    option(RECORDING_MODES.MANUAL, "BATTLE_REPLAY.library.manual", !automatic)
  ].join("");
  const speedOptions = [1, 2, 4, 8]
    .map((value) => '<option value="' + value + '"' + (speed === value ? " selected" : "") +
      ">" + value + "×</option>")
    .join("");
  const themeOptions = [
    option(LIBRARY_THEMES.DARK, "BATTLE_REPLAY.library.themeDark", theme === LIBRARY_THEMES.DARK),
    option(LIBRARY_THEMES.LIGHT, "BATTLE_REPLAY.library.themeLight", theme === LIBRARY_THEMES.LIGHT),
    option(LIBRARY_THEMES.AUTO, "BATTLE_REPLAY.library.themeAuto", theme === LIBRARY_THEMES.AUTO)
  ].join("");
  const directorOptions = [
    option(CINEMATIC_PRESETS.TACTICAL, "BATTLE_REPLAY.library.directorTactical", director === CINEMATIC_PRESETS.TACTICAL),
    option(CINEMATIC_PRESETS.CINEMATIC, "BATTLE_REPLAY.library.directorCinematic", director === CINEMATIC_PRESETS.CINEMATIC),
    option(CINEMATIC_PRESETS.CREATOR, "BATTLE_REPLAY.library.directorCreator", director === CINEMATIC_PRESETS.CREATOR)
  ].join("");
  const creatorFormatOptions = [
    option(CREATOR_FORMATS.AUTO, "BATTLE_REPLAY.library.creatorFormatAuto", creatorFormat === CREATOR_FORMATS.AUTO),
    option(CREATOR_FORMATS.LANDSCAPE, "BATTLE_REPLAY.library.creatorFormatLandscape", creatorFormat === CREATOR_FORMATS.LANDSCAPE),
    option(CREATOR_FORMATS.VERTICAL, "BATTLE_REPLAY.library.creatorFormatVertical", creatorFormat === CREATOR_FORMATS.VERTICAL)
  ].join("");

  const status = activeRecording
    ? [
        '<section class="battle-replay-recording">',
        '<span><i class="fa-solid fa-circle"></i> ',
        localize("BATTLE_REPLAY.library.recording", {
          title: escapeHtml(activeRecording.title),
          scene: escapeHtml(activeRecording.sceneName)
        }),
        '</span>',
        canCancel ? '<button type="button" data-action="cancel-recording">' : "",
        canCancel ? '<i class="fa-solid fa-ban"></i> ' : "",
        canCancel ? localize("BATTLE_REPLAY.library.cancelRecording") : "",
        canCancel ? '</button>' : "",
        '</section>'
      ].join("")
    : [
        '<section class="battle-replay-recording is-idle">',
        '<span><i class="fa-regular fa-circle-check"></i>',
        localize("BATTLE_REPLAY.library.notRecording"),
        '</span></section>'
      ].join("");

  const scenes = uniqueOptions(replays, "sceneId", "sceneName");
  const systems = uniqueOptions(
    replays,
    (replay) => replay.system?.id,
    (replay) => replay.system?.id
  );
  const rows = replays.length
    ? replays.map((replay, index) => replayRow(replay, index === 0)).join("")
    : [
        '<div class="battle-replay-empty">',
        '<i class="fa-solid fa-forward-fast"></i>',
        '<p>',
        localize("BATTLE_REPLAY.library.empty"),
        '</p>',
        '</div>'
      ].join("");

  return [
    '<div class="battle-replay-library">',
    '<header class="battle-replay-library-hero">',
    '<span class="battle-replay-brand-mark" aria-hidden="true"><i class="fa-solid fa-forward-fast"></i></span>',
    '<span class="battle-replay-library-heading"><strong>',
    localize("BATTLE_REPLAY.library.heroTitle"),
    '</strong><span>',
    localize("BATTLE_REPLAY.library.heroSubtitle"),
    '</span></span>',
    '<span class="battle-replay-library-summary"><strong>',
    String(Number(stats.count) || 0),
    '</strong><span>',
    localize("BATTLE_REPLAY.library.savedReplays"),
    '</span><small>',
    escapeHtml(formatBytes(stats.bytes)),
    '</small></span>',
    '</header>',
    status,
    '<section class="battle-replay-library-panel battle-replay-preferences-panel">',
    '<header class="battle-replay-section-heading"><i class="fa-solid fa-sliders"></i><span><strong>',
    localize("BATTLE_REPLAY.library.settingsTitle"),
    '</strong><small>',
    localize("BATTLE_REPLAY.library.settingsSubtitle"),
    '</small></span></header>',
    '<div class="battle-replay-preferences">',
    '<div class="form-group"><label for="battle-replay-mode">',
    localize("BATTLE_REPLAY.library.recordingMode"),
    '</label><select id="battle-replay-mode" name="recordingMode">',
    modeOptions,
    '</select><p class="hint">',
    localize("BATTLE_REPLAY.library.recordingModeHint"),
    '</p></div>',
    '<div class="form-group"><label for="battle-replay-speed">',
    localize("BATTLE_REPLAY.library.speed"),
    '</label><select id="battle-replay-speed" name="playbackSpeed">',
    speedOptions,
    '</select></div>',
    '<div class="form-group"><label for="battle-replay-theme">',
    localize("BATTLE_REPLAY.library.theme"),
    '</label><select id="battle-replay-theme" name="libraryTheme">',
    themeOptions,
    '</select></div>',
    '<div class="form-group battle-replay-director-toggle"><label class="battle-replay-switch" for="battle-replay-director-enabled">',
    '<input id="battle-replay-director-enabled" name="cinematicEnabled" type="checkbox"',
    directorEnabled ? ' checked' : '',
    '><span class="battle-replay-switch-track" aria-hidden="true"></span><span>',
    localize("BATTLE_REPLAY.library.directorEnabled"),
    '</span></label><p class="hint">',
    localize("BATTLE_REPLAY.library.directorEnabledHint"),
    '</p></div>',
    '<div class="form-group" data-role="director-preset-group"',
    directorEnabled ? '' : ' hidden',
    '><label for="battle-replay-director">',
    localize("BATTLE_REPLAY.library.directorPreset"),
    '</label><select id="battle-replay-director" name="cinematicPreset">',
    directorOptions,
    '</select><p class="hint">',
    localize("BATTLE_REPLAY.library.directorPresetHint"),
    '</p></div>',
    '<div class="form-group" data-role="creator-format-group"><label for="battle-replay-creator-format">',
    localize("BATTLE_REPLAY.library.creatorFormat"),
    '</label><select id="battle-replay-creator-format" name="creatorFormat">',
    creatorFormatOptions,
    '</select><p class="hint">',
    localize("BATTLE_REPLAY.library.creatorFormatHint"),
    '</p></div>',
    '</div>',
    '</section>',
    '<section class="battle-replay-library-panel battle-replay-browser-panel">',
    '<header class="battle-replay-section-heading battle-replay-browser-heading"><i class="fa-solid fa-layer-group"></i><span><strong>',
    localize("BATTLE_REPLAY.library.recordedCombats"),
    '</strong><small data-role="visible-count">',
    localize("BATTLE_REPLAY.library.visibleCount", {
      visible: replays.length,
      total: replays.length
    }),
    '</small></span></header>',
    '<section class="battle-replay-filters">',
    '<label class="battle-replay-search"><i class="fa-solid fa-magnifying-glass"></i><input name="search" type="search" placeholder="',
    escapeHtml(localize("BATTLE_REPLAY.library.search")),
    '"></label>',
    '<select name="sceneFilter"><option value="">',
    localize("BATTLE_REPLAY.library.allScenes"),
    '</option>',
    scenes,
    '</select>',
    '<select name="systemFilter"><option value="">',
    localize("BATTLE_REPLAY.library.allSystems"),
    '</option>',
    systems,
    '</select>',
    '<select name="dateFilter"><option value="">',
    localize("BATTLE_REPLAY.library.allDates"),
    '</option><option value="7">',
    localize("BATTLE_REPLAY.library.lastSevenDays"),
    '</option><option value="30">',
    localize("BATTLE_REPLAY.library.lastThirtyDays"),
    '</option><option value="365">',
    localize("BATTLE_REPLAY.library.lastYear"),
    '</option></select>',
    '<label class="battle-replay-favorite-filter"><input name="favoritesOnly" type="checkbox"> ',
    '<i class="fa-solid fa-star"></i><span>',
    localize("BATTLE_REPLAY.library.favoritesOnly"),
    '</span></label>',
    '</section>',
    '<section class="battle-replay-list" aria-label="',
    escapeHtml(localize("BATTLE_REPLAY.library.recordedCombats")),
    '">',
    rows,
    '</section>',
    '</section>',
    '<section class="battle-replay-actions">',
    actionButton("analytics", "fa-chart-column", "BATTLE_REPLAY.library.analytics"),
    actionButton("live", "fa-tower-broadcast", "BATTLE_REPLAY.library.playLive"),
    actionButton("rename", "fa-pen", "BATTLE_REPLAY.library.rename"),
    actionButton("favorite", "fa-star", "BATTLE_REPLAY.library.favorite"),
    actionButton("export", "fa-file-export", "BATTLE_REPLAY.library.export"),
    actionButton("import", "fa-file-import", "BATTLE_REPLAY.library.import"),
    actionButton("delete", "fa-trash", "BATTLE_REPLAY.library.delete"),
    '<input name="importFile" type="file" accept="application/json,.json" multiple hidden>',
    '</section>',
    '<footer class="battle-replay-library-note"><i class="fa-solid fa-circle-info"></i><span>',
    localize("BATTLE_REPLAY.library.sceneNotice"),
    '</span></footer>',
    '</div>'
  ].join("");
}

export async function openCombatAnalytics(replay) {
  const dialogId = "battle-replay-analytics-dialog";
  const existing = foundry.applications.instances.get(dialogId);
  if (existing) {
    await existing.close();
  }

  const report = buildCombatAnalytics(replay);
  const dialog = new foundry.applications.api.DialogV2({
    id: dialogId,
    window: {
      title: localize("BATTLE_REPLAY.analytics.title", { title: replay.title })
    },
    content: buildAnalyticsContent(report),
    buttons: [{
      action: "close",
      icon: "fa-solid fa-xmark",
      label: localize("BATTLE_REPLAY.analytics.close")
    }]
  });

  await dialog.render(true);
  const storedTheme = String(game.settings.get(MODULE_ID, SETTINGS.LIBRARY_THEME) ?? "");
  applyLibraryTheme(dialog.element, storedTheme);
  for (const image of dialog.element.querySelectorAll(".battle-replay-analytics-avatar img")) {
    const showFallback = () => image.closest(".battle-replay-analytics-avatar")?.classList.remove("has-image");
    image.addEventListener("error", showFallback, { once: true });
    if (image.complete && !image.naturalWidth) showFallback();
  }
  return dialog;
}

export function buildAnalyticsContent(report) {
  const participants = report?.participants ?? [];
  const totals = report?.totals ?? {};
  const replay = report?.replay ?? {};
  const started = replay.startedAt ? new Date(replay.startedAt).toLocaleString() : "—";
  const totalCriticalFailures = participants.reduce((total, row) => total + row.criticalFailures, 0);
  const totalSpells = participants.reduce((total, row) => total + row.spellsUsed, 0);
  const totalDefeats = participants.reduce((total, row) => total + row.defeats, 0);

  const participantRows = participants.length
    ? participants.map(analyticsParticipantRow).join("")
    : '<tr class="battle-replay-analytics-empty"><td colspan="20"><i class="fa-solid fa-chart-simple"></i><span>' +
      escapeHtml(localize("BATTLE_REPLAY.analytics.empty")) + "</span></td></tr>";

  return [
    '<div class="battle-replay-analytics">',
    '<header class="battle-replay-analytics-hero">',
    '<span class="battle-replay-analytics-brand"><i class="fa-solid fa-chart-column"></i></span>',
    '<span class="battle-replay-analytics-heading"><strong>',
    escapeHtml(replay.title || localize("BATTLE_REPLAY.analytics.combat")),
    '</strong><span><i class="fa-solid fa-map"></i> ',
    escapeHtml(replay.sceneName || "—"),
    '<span aria-hidden="true">·</span><i class="fa-regular fa-calendar"></i> ',
    escapeHtml(started),
    '</span></span>',
    '<span class="battle-replay-analytics-summary"><strong>',
    String(participants.length),
    '</strong><span>',
    escapeHtml(localize("BATTLE_REPLAY.analytics.combatants")),
    '</span><small>',
    escapeHtml(formatDuration(replay.duration ?? 0)),
    ' · ',
    String(report.rounds ?? 0),
    ' ',
    escapeHtml(localize("BATTLE_REPLAY.analytics.rounds")),
    '</small></span>',
    '</header>',
    '<section class="battle-replay-analytics-kpis">',
    analyticsKpi("fa-burst", "damage", totals.damage, "BATTLE_REPLAY.analytics.totalDamage"),
    analyticsKpi("fa-heart-circle-plus", "healing", totals.healing, "BATTLE_REPLAY.analytics.totalHealing"),
    analyticsKpi("fa-crosshairs", "attacks", totals.attacks, "BATTLE_REPLAY.analytics.attacks"),
    analyticsKpi("fa-bullseye", "accuracy", formatPercent(totals.accuracy), "BATTLE_REPLAY.analytics.overallAccuracy"),
    analyticsKpi("fa-star", "criticals", totals.criticals, "BATTLE_REPLAY.analytics.criticals"),
    analyticsKpi("fa-skull-crossbones", "defeats", totalDefeats, "BATTLE_REPLAY.analytics.defeats"),
    '</section>',
    '<section class="battle-replay-analytics-leaderboards">',
    analyticsLeaderboard(
      "fa-burst",
      "BATTLE_REPLAY.analytics.damageCaused",
      participants,
      (row) => row.damageCaused,
      (value) => formatNumber(value),
      "damage"
    ),
    analyticsLeaderboard(
      "fa-bullseye",
      "BATTLE_REPLAY.analytics.accuracy",
      participants.filter((row) => row.attacks > 0),
      (row) => row.accuracy,
      formatPercent,
      "accuracy"
    ),
    analyticsLeaderboard(
      "fa-star",
      "BATTLE_REPLAY.analytics.criticals",
      participants,
      (row) => row.criticals,
      (value) => formatNumber(value),
      "criticals"
    ),
    '</section>',
    '<section class="battle-replay-analytics-panel">',
    '<header class="battle-replay-analytics-section-heading"><span><i class="fa-solid fa-users-viewfinder"></i></span><div><strong>',
    escapeHtml(localize("BATTLE_REPLAY.analytics.participantDetails")),
    '</strong><small>',
    escapeHtml(localize("BATTLE_REPLAY.analytics.participantDetailsHint", {
      criticalFailures: totalCriticalFailures,
      spells: totalSpells
    })),
    '</small></div></header>',
    '<div class="battle-replay-analytics-table-wrap"><table class="battle-replay-analytics-table">',
    '<thead><tr>',
    analyticsHeader("participant", "BATTLE_REPLAY.analytics.participant"),
    analyticsHeader("damage-out", "BATTLE_REPLAY.analytics.damageCaused"),
    analyticsHeader("damage-in", "BATTLE_REPLAY.analytics.damageReceived"),
    analyticsHeader("healing-out", "BATTLE_REPLAY.analytics.healingDone"),
    analyticsHeader("healing-in", "BATTLE_REPLAY.analytics.healingReceived"),
    analyticsHeader("attacks", "BATTLE_REPLAY.analytics.attacks"),
    analyticsHeader("accuracy", "BATTLE_REPLAY.analytics.accuracy"),
    analyticsHeader("criticals", "BATTLE_REPLAY.analytics.criticals"),
    analyticsHeader("critical-failures", "BATTLE_REPLAY.analytics.criticalFailures"),
    analyticsHeader("saves", "BATTLE_REPLAY.analytics.successfulSaves"),
    analyticsHeader("spells", "BATTLE_REPLAY.analytics.spellsUsed"),
    analyticsHeader("conditions-out", "BATTLE_REPLAY.analytics.conditionsApplied"),
    analyticsHeader("conditions-in", "BATTLE_REPLAY.analytics.conditionsReceived"),
    analyticsHeader("defeats", "BATTLE_REPLAY.analytics.defeats"),
    analyticsHeader("zero-hp", "BATTLE_REPLAY.analytics.zeroHp"),
    analyticsHeader("max-damage", "BATTLE_REPLAY.analytics.maxDamage"),
    analyticsHeader("max-healing", "BATTLE_REPLAY.analytics.maxHealing"),
    analyticsHeader("streak", "BATTLE_REPLAY.analytics.damageStreak"),
    analyticsHeader("turn-interval", "BATTLE_REPLAY.analytics.averageTurnInterval"),
    analyticsHeader("actions-round", "BATTLE_REPLAY.analytics.actionsPerRound"),
    '</tr></thead><tbody>',
    participantRows,
    '</tbody></table></div>',
    '</section>',
    '<footer class="battle-replay-analytics-note"><i class="fa-solid fa-circle-info"></i><span>',
    escapeHtml(localize("BATTLE_REPLAY.analytics.derivedNotice")),
    '</span></footer>',
    '</div>'
  ].join("");
}

function analyticsKpi(icon, tone, value, key) {
  return [
    '<article class="battle-replay-analytics-kpi tone-', tone, '"><i class="fa-solid ', icon,
    '"></i><span><strong>', escapeHtml(String(value ?? 0)), '</strong><small>',
    escapeHtml(localize(key)), '</small></span></article>'
  ].join("");
}

function analyticsLeaderboard(icon, key, participants, valueSource, formatter, tone) {
  const rows = participants.slice().sort((left, right) => {
    return valueSource(right) - valueSource(left) || left.name.localeCompare(right.name);
  }).slice(0, 5);
  const maximum = Math.max(1, ...rows.map(valueSource));
  const content = rows.length ? rows.map((row) => {
    const value = valueSource(row);
    const width = Math.max(value > 0 ? 4 : 0, Math.min(100, (value / maximum) * 100));
    return [
      '<li><span class="battle-replay-analytics-rank-avatar', row.image ? ' has-image' : '', '">',
      '<i class="fa-solid fa-user-shield"></i>',
      row.image ? '<img src="' + escapeHtml(row.image) + '" alt="">' : '',
      '</span><span class="battle-replay-analytics-rank-copy"><span><strong>',
      escapeHtml(row.name), '</strong><b>', escapeHtml(formatter(value)),
      '</b></span><span class="battle-replay-analytics-bar"><i style="width:',
      width.toFixed(1), '%"></i></span></span></li>'
    ].join("");
  }).join("") : '<li class="is-empty">' + escapeHtml(localize("BATTLE_REPLAY.analytics.noData")) + '</li>';
  return [
    '<article class="battle-replay-analytics-leaderboard tone-', tone,
    '"><header><i class="fa-solid ', icon, '"></i><strong>', escapeHtml(localize(key)),
    '</strong></header><ol>', content, '</ol></article>'
  ].join("");
}

function analyticsParticipantRow(row) {
  const streak = row.damageStreak?.rounds
    ? localize("BATTLE_REPLAY.analytics.streakValue", {
      damage: formatNumber(row.damageStreak.damage),
      rounds: row.damageStreak.rounds
    })
    : "—";
  return [
    '<tr><th scope="row"><span class="battle-replay-analytics-combatant">',
    '<span class="battle-replay-analytics-avatar', row.image ? ' has-image' : '', '">',
    '<i class="fa-solid fa-user-shield"></i>',
    row.image ? '<img src="' + escapeHtml(row.image) + '" alt="">' : '',
    '</span><span><strong>', escapeHtml(row.name), '</strong><small>',
    escapeHtml(teamLabel(row.disposition)), '</small></span></span></th>',
    analyticsCell(row.damageCaused, "is-damage"),
    analyticsCell(row.damageReceived),
    analyticsCell(row.healingDone, "is-healing"),
    analyticsCell(row.healingReceived),
    analyticsCell(row.attacks),
    analyticsCell(formatPercent(row.accuracy)),
    analyticsCell(row.criticals, "is-critical"),
    analyticsCell(row.criticalFailures),
    analyticsCell(row.successfulSaves),
    analyticsCell(row.spellsUsed),
    analyticsCell(row.conditionsApplied),
    analyticsCell(row.conditionsReceived),
    analyticsCell(row.defeats),
    analyticsCell(row.zeroHp),
    analyticsCell(row.maxDamage),
    analyticsCell(row.maxHealing),
    analyticsCell(streak),
    analyticsCell(row.averageTurnInterval === null ? "—" : formatDuration(row.averageTurnInterval)),
    analyticsCell(formatDecimal(row.actionsPerRound)),
    '</tr>'
  ].join("");
}

function analyticsHeader(className, key) {
  return '<th class="metric-' + className + '" title="' + escapeHtml(localize(key)) + '">' +
    escapeHtml(localize(key)) + '</th>';
}

function analyticsCell(value, className = "") {
  return '<td' + (className ? ' class="' + className + '"' : '') + '>' +
    escapeHtml(formatNumber(value)) + '</td>';
}

function teamLabel(disposition) {
  if (Number(disposition) > 0) return localize("BATTLE_REPLAY.analytics.ally");
  if (Number(disposition) < 0) return localize("BATTLE_REPLAY.analytics.enemy");
  return localize("BATTLE_REPLAY.analytics.neutral");
}

function formatPercent(value) {
  return formatDecimal(value) + "%";
}

function formatDecimal(value) {
  const number = Number(value) || 0;
  return Number.isInteger(number) ? String(number) : number.toLocaleString(undefined, {
    maximumFractionDigits: 1,
    minimumFractionDigits: 1
  });
}

function formatNumber(value) {
  return typeof value === "number" ? value.toLocaleString() : String(value ?? "—");
}

function applyLibraryTheme(root, choice) {
  const normalized = Object.values(LIBRARY_THEMES).includes(choice)
    ? choice
    : LIBRARY_THEMES.DARK;
  const resolved = normalized === LIBRARY_THEMES.AUTO &&
    globalThis.matchMedia?.("(prefers-color-scheme: light)")?.matches
    ? LIBRARY_THEMES.LIGHT
    : normalized === LIBRARY_THEMES.AUTO
      ? LIBRARY_THEMES.DARK
      : normalized;
  root.dataset.libraryTheme = resolved;
  root.dataset.libraryThemeChoice = normalized;
}

function replayRow(replay, checked) {
  const duration = formatDuration(replay.metadata?.duration ??
    ((replay.endedAt ?? replay.startedAt) - replay.startedAt));
  const eventCount = replay.metadata?.eventCount ?? replay.events?.length ?? 0;
  const rounds = replay.metadata?.rounds ?? 0;
  const actions = replay.metadata?.actionCount ?? 0;
  const date = new Date(Number(replay.startedAt)).toLocaleString();
  const participants = replay.metadata?.participants?.join(", ") || "—";
  const tags = (replay.tags ?? []).map((tag) => {
    return '<span class="battle-replay-tag">' + escapeHtml(tag) + "</span>";
  }).join("");
  const portraits = replayPortraits(replay);
  const searchText = [
    replay.title,
    replay.sceneName,
    replay.system?.id,
    date,
    participants,
    ...(replay.tags ?? [])
  ].join(" ").toLocaleLowerCase();

  return [
    '<article class="battle-replay-row" data-search="',
    escapeHtml(searchText),
    '" data-scene="',
    escapeHtml(replay.sceneId),
    '" data-system="',
    escapeHtml(replay.system?.id ?? ""),
    '" data-started="',
    String(Number(replay.startedAt)),
    '" data-favorite="',
    String(Boolean(replay.favorite)),
    '">',
    '<label class="battle-replay-row-select">',
    '<input type="radio" name="replayId" value="',
    escapeHtml(replay.id),
    '"',
    checked ? " checked" : "",
    '>',
    '<span class="battle-replay-radio-indicator" aria-hidden="true"></span>',
    '<span class="battle-replay-avatars" aria-hidden="true">',
    portraits,
    '</span>',
    '<span class="battle-replay-row-main"><span class="battle-replay-row-title"><strong>',
    escapeHtml(replay.title),
    '</strong>',
    replay.favorite ? '<i class="fa-solid fa-star" title="Favorite"></i>' : "",
    '</span><span class="battle-replay-row-context"><i class="fa-solid fa-map"></i>',
    escapeHtml(replay.sceneName),
    '<span aria-hidden="true">·</span><i class="fa-regular fa-calendar"></i>',
    escapeHtml(date),
    '</span><span class="battle-replay-row-participants"><i class="fa-solid fa-users"></i>',
    escapeHtml(participants),
    '</span><span class="battle-replay-stats">',
    replayStat("fa-regular fa-clock", duration),
    replayStat("fa-solid fa-bolt", eventCount + " " + localize("BATTLE_REPLAY.library.events")),
    replayStat("fa-solid fa-rotate", rounds + " " + localize("BATTLE_REPLAY.library.rounds")),
    replayStat("fa-solid fa-wand-magic-sparkles", actions + " " + localize("BATTLE_REPLAY.library.actions")),
    replayStat("fa-solid fa-dice-d20", escapeHtml(replay.system?.id ?? "unknown")),
    '</span><span class="battle-replay-tags">',
    tags,
    '</span></span></label>',
    '<label class="battle-replay-mark" title="',
    escapeHtml(localize("BATTLE_REPLAY.library.markForBulk")),
    '"><input type="checkbox" name="replayIds" value="',
    escapeHtml(replay.id),
    '"><span><i class="fa-solid fa-check"></i></span></label>',
    '<button class="battle-replay-row-play" type="button" data-action="play-row" data-replay-id="',
    escapeHtml(replay.id),
    '" aria-label="',
    escapeHtml(localize("BATTLE_REPLAY.library.play")),
    '" title="',
    escapeHtml(localize("BATTLE_REPLAY.library.play")),
    '"><i class="fa-solid fa-play"></i></button>',
    '</article>'
  ].join("");
}

function replayPortraits(replay) {
  const tokens = [];
  const seen = new Set();

  for (const token of replay.tokens ?? []) {
    const identity = token.actorId ?? token.id ?? token.name;
    if (!identity || seen.has(identity)) continue;
    seen.add(identity);
    tokens.push(token);
  }

  const portraits = tokens.slice(0, 3).map((token) => {
    const source = token.appearance?.texture ??
      (typeof token.texture === "string" ? token.texture : token.texture?.src);
    return [
      '<span class="battle-replay-avatar',
      source ? ' has-image' : '',
      '" title="',
      escapeHtml(token.name ?? "Token"),
      '"><i class="fa-solid fa-user-shield"></i>',
      source ? '<img src="' + escapeHtml(source) + '" alt="">' : '',
      '</span>'
    ].join("");
  });

  if (!portraits.length) {
    portraits.push('<span class="battle-replay-avatar"><i class="fa-solid fa-shield-halved"></i></span>');
  }

  if (tokens.length > 3) {
    portraits.push('<span class="battle-replay-avatar battle-replay-avatar-more">+' +
      String(tokens.length - 3) + '</span>');
  }

  return portraits.join("");
}

function replayStat(icon, value) {
  return '<span class="battle-replay-stat"><i class="' + icon + '"></i>' + value + '</span>';
}

function option(value, key, selected) {
  return '<option value="' + value + '"' + (selected ? " selected" : "") +
    ">" + localize(key) + "</option>";
}

function uniqueOptions(replays, valueSource, labelSource) {
  const values = new Map();
  for (const replay of replays) {
    const value = typeof valueSource === "function" ? valueSource(replay) : replay[valueSource];
    const label = typeof labelSource === "function" ? labelSource(replay) : replay[labelSource];
    if (value && label) values.set(String(value), String(label));
  }
  return [...values.entries()]
    .sort((left, right) => left[1].localeCompare(right[1]))
    .map(([value, label]) => {
      return '<option value="' + escapeHtml(value) + '">' + escapeHtml(label) + "</option>";
    })
    .join("");
}

function actionButton(action, icon, key) {
  return [
    '<button type="button" data-action="',
    action,
    '"><i class="fa-solid ',
    icon,
    '"></i> ',
    localize(key),
    '</button>'
  ].join("");
}

export function getSelectedReplay(form, storage) {
  const replayId = form?.querySelector?.("[name='replayId']:checked")?.value;
  return replayId ? storage.getReplay(replayId) : null;
}

export function getMarkedReplayIds(form) {
  const marked = Array.from(form?.querySelectorAll("[name='replayIds']:checked") ?? [])
    .map((input) => input.value);
  if (marked.length) return marked;
  const selected = form?.querySelector?.("[name='replayId']:checked")?.value;
  return selected ? [selected] : [];
}

async function editReplayMetadata(replay, storage) {
  const content = [
    '<div class="battle-replay-edit-form">',
    '<div class="form-group"><label>',
    localize("BATTLE_REPLAY.library.name"),
    '</label><input name="title" type="text" maxlength="120" value="',
    escapeHtml(replay.title),
    '" required></div>',
    '<div class="form-group"><label>',
    localize("BATTLE_REPLAY.library.tags"),
    '</label><input name="tags" type="text" value="',
    escapeHtml((replay.tags ?? []).join(", ")),
    '"><p class="hint">',
    localize("BATTLE_REPLAY.library.tagsHint"),
    '</p></div></div>'
  ].join("");

  const result = await foundry.applications.api.DialogV2.prompt({
    window: { title: localize("BATTLE_REPLAY.library.renameTitle") },
    content,
    rejectClose: false,
    ok: {
      label: localize("BATTLE_REPLAY.library.save"),
      callback: (_event, button) => {
        const title = String(
          button.form?.querySelector?.("[name='title']")?.value ?? ""
        ).trim();
        if (!title) {
          ui.notifications.warn(localize("BATTLE_REPLAY.notifications.nameRequired"));
          return false;
        }
        const tags = String(
          button.form?.querySelector?.("[name='tags']")?.value ?? ""
        )
          .split(",")
          .map((tag) => tag.trim())
          .filter(Boolean);
        return { title, tags };
      }
    }
  });

  if (!result || typeof result !== "object") return false;
  await storage.updateReplay(replay.id, result);
  ui.notifications.info(localize("BATTLE_REPLAY.notifications.replayUpdated"));
  return true;
}

function exportSelectedReplays(form, storage) {
  const ids = getMarkedReplayIds(form);
  if (!ids.length) {
    ui.notifications.warn(localize("BATTLE_REPLAY.notifications.selectReplay"));
    return;
  }
  const replays = ids.map((id) => storage.getReplay(id)).filter(Boolean);
  const payload = replays.length === 1
    ? replays[0]
    : { format: "battle-replay-bundle", version: 1, replays };
  const filename = replays.length === 1
    ? slugifyFilename(replays[0].title) + ".battle-replay.json"
    : "battle-replay-bundle.json";
  downloadJson(payload, filename);
  ui.notifications.info(localize("BATTLE_REPLAY.notifications.exported", {
    count: replays.length
  }));
}

function downloadJson(payload, filename) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function confirmAction(titleKey, contentKey, yesKey, data = {}) {
  return foundry.applications.api.DialogV2.confirm({
    window: { title: localize(titleKey) },
    content: "<p>" + localize(contentKey, data) + "</p>",
    yes: { label: localize(yesKey) },
    no: { label: localize("BATTLE_REPLAY.library.cancel") },
    rejectClose: false
  });
}

async function refreshLibrary(dialog, dependencies) {
  await dialog.close();
  return openReplayLibrary(dependencies);
}

function updateVisibleCount(root) {
  const rows = Array.from(root.querySelectorAll(".battle-replay-row"));
  const visible = rows.filter((row) => !row.hidden).length;
  const label = root.querySelector("[data-role='visible-count']");
  if (label) {
    label.textContent = localize("BATTLE_REPLAY.library.visibleCount", {
      visible,
      total: rows.length
    });
  }
}
