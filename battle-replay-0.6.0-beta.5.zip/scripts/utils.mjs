import { MODULE_ID } from "./constants.mjs";

export function localize(key, data = undefined) {
  if (data) return game.i18n.format(key, data);
  return game.i18n.localize(key);
}

export function log(...args) {
  console.log(`${MODULE_ID} |`, ...args);
}

export function warn(...args) {
  console.warn(`${MODULE_ID} |`, ...args);
}

export function safeParseJson(value, fallback) {
  if (!value) return fallback;

  try {
    return JSON.parse(value);
  } catch (error) {
    warn("Could not parse stored JSON.", error);
    return fallback;
  }
}

export function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function formatDuration(milliseconds) {
  const seconds = Math.max(0, Math.round(Number(milliseconds ?? 0) / 1000));
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${String(remainingSeconds).padStart(2, "0")}`;
}

export function formatBytes(bytes) {
  const value = Math.max(0, Number(bytes) || 0);
  if (value < 1024) return Math.round(value) + " B";
  if (value < 1024 * 1024) return (value / 1024).toFixed(1) + " KB";
  return (value / (1024 * 1024)).toFixed(1) + " MB";
}

export function slugifyFilename(value) {
  const slug = String(value ?? "battle-replay")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
  return slug || "battle-replay";
}

export function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}

export function createId() {
  return foundry.utils.randomID();
}

export function pickPosition(value = {}) {
  return {
    x: finiteOrNull(value.x),
    y: finiteOrNull(value.y),
    elevation: finiteOrNull(value.elevation),
    rotation: finiteOrNull(value.rotation)
  };
}

export function positionsEqual(left, right) {
  return left?.x === right?.x &&
    left?.y === right?.y &&
    left?.elevation === right?.elevation &&
    left?.rotation === right?.rotation;
}

export function sleep(milliseconds, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(createAbortError());
      return;
    }

    const timeoutId = window.setTimeout(resolve, milliseconds);
    signal?.addEventListener("abort", () => {
      window.clearTimeout(timeoutId);
      reject(createAbortError());
    }, { once: true });
  });
}

export function isAbortError(error) {
  return error?.name === "AbortError";
}

function finiteOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function createAbortError() {
  return new DOMException("Playback aborted", "AbortError");
}
