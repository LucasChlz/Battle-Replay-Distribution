import {
  CINEMATIC_PRESETS,
  CREATOR_FORMATS,
  MODULE_ID,
  SETTINGS
} from "./constants.mjs";
import {
  CinematicDirector
} from "./cinematic-director.mjs";
import { FEATURES } from "./entitlements.mjs";
import { playSequencerVisualEffect } from "./sequencer-effects.mjs";
import {
  buildVisualTimelineItems,
  clampTimelineIndex,
  computeReplayState
} from "./timeline.mjs";
import {
  clamp,
  escapeHtml,
  formatDuration,
  isAbortError,
  localize,
  pickPosition,
  sleep,
  warn
} from "./utils.mjs";

export class PlaybackEngine {
  constructor({ entitlements = null } = {}) {
    this.entitlements = entitlements ?? {
      can: () => true,
      status: { tier: "development" }
    };
    this.abortController = null;
    this.operationController = null;
    this.container = null;
    this.ghosts = new Map();
    this.statusElement = null;
    this.playingReplayId = null;
    this.currentReplay = null;
    this.currentIndex = 0;
    this.speed = 2;
    this.paused = false;
    this.completed = false;
    this.interactive = false;
    this.liveRole = null;
    this.readOnly = false;
    this.revealSecrets = true;
    this.stateListener = null;
    this.seekRequestedIndex = null;
    this.controlWaiters = new Set();
    this.director = new CinematicDirector();
    this.originalCamera = null;
    this.directorOverlay = null;
    this.nativeTokenLayerState = null;
    this.transientIndicators = new Set();
  }

  get isPlaying() {
    return Boolean(this.abortController);
  }

  get status() {
    return Object.freeze({
      active: this.isPlaying,
      completed: this.completed,
      eventIndex: this.currentIndex,
      eventTotal: this.currentReplay?.events?.length ?? 0,
      interactive: this.interactive,
      liveRole: this.liveRole,
      paused: this.paused,
      readOnly: this.readOnly,
      revealSecrets: this.revealSecrets,
      replayId: this.playingReplayId,
      speed: this.speed,
      cinematicEnabled: this.director.enabled,
      cinematicPreset: this.director.preset,
      creatorFormat: this.director.creatorFormat
    });
  }

  async play(replay, options = {}) {
    if (!game.user?.isGM && !options.allowPlayer) return;
    if (!replay) return;

    if (!canvas.ready || canvas.scene?.id !== replay.sceneId) {
      ui.notifications.warn(localize("BATTLE_REPLAY.notifications.wrongScene", {
        scene: replay.sceneName
      }));
      return;
    }

    this.stop();
    if (!this.entitlements.can(FEATURES.CORE_PLAYBACK)) return;

    const controller = new AbortController();
    this.abortController = controller;
    this.playingReplayId = replay.id;
    this.currentReplay = {
      ...replay,
      events: [...(replay.events ?? [])]
        .sort((left, right) => Number(left.sequence) - Number(right.sequence))
    };
    this.currentIndex = 0;
    this.paused = Boolean(options.startPaused);
    this.completed = false;
    this.interactive = Boolean(options.interactive);
    this.liveRole = options.liveRole ?? null;
    this.readOnly = Boolean(options.readOnly);
    this.revealSecrets = options.revealSecrets ?? Boolean(game.user?.isGM);
    this.stateListener = typeof options.onStateChange === "function"
      ? options.onStateChange
      : null;
    this.seekRequestedIndex = null;
    const signal = controller.signal;
    this.speed = Number(options.speed ?? game.settings.get(MODULE_ID, SETTINGS.PLAYBACK_SPEED)) || 2;
    this.director.configure({
      enabled: options.cinematicEnabled ?? game.settings.get(MODULE_ID, SETTINGS.CINEMATIC_ENABLED),
      preset: options.cinematicPreset ?? game.settings.get(MODULE_ID, SETTINGS.CINEMATIC_PRESET),
      creatorFormat: options.creatorFormat ?? game.settings.get(MODULE_ID, SETTINGS.CREATOR_FORMAT)
    });

    try {
      await this.createVisualLayer(this.currentReplay, signal);
      this.updateStatus(localize("BATTLE_REPLAY.playback.starting"));
      this.updateTimeline();
      Hooks.callAll(`${MODULE_ID}:playbackStarted`, this.currentReplay);
      this.notifyState("started");
      await this.runPlayback(controller);
    } catch (error) {
      if (!isAbortError(error)) {
        warn("Playback failed.", error);
        ui.notifications.error(localize("BATTLE_REPLAY.notifications.playbackFailed"));
      }
    } finally {
      if (this.abortController === controller) {
        this.notifyState("ended", { active: false });
        this.destroyVisualLayer();
        this.abortController = null;
        this.playingReplayId = null;
        this.currentReplay = null;
        this.operationController = null;
        this.liveRole = null;
        this.readOnly = false;
        this.revealSecrets = true;
        this.stateListener = null;
      }
      Hooks.callAll(`${MODULE_ID}:playbackStopped`, replay.id);
    }
  }

  stop() {
    const wasPlaying = this.isPlaying;
    if (wasPlaying) this.notifyState("stopped", { active: false });
    this.operationController?.abort();
    this.abortController?.abort();
    this.abortController = null;
    this.operationController = null;
    this.playingReplayId = null;
    this.currentReplay = null;
    this.liveRole = null;
    this.readOnly = false;
    this.revealSecrets = true;
    this.stateListener = null;
    this.seekRequestedIndex = null;
    this.paused = false;
    this.completed = false;
    this.wakeControlWaiters();
    this.destroyVisualLayer();
  }

  pause() {
    if (!this.isPlaying || this.paused || this.readOnly) return false;
    this.paused = true;
    this.operationController?.abort();
    this.updateTimeline();
    this.wakeControlWaiters();
    this.notifyState("pause");
    return true;
  }

  resume() {
    if (!this.isPlaying || this.readOnly) return false;
    if (this.completed || this.currentIndex >= (this.currentReplay?.events?.length ?? 0)) {
      this.requestSeek(0);
      this.completed = false;
    }
    this.paused = false;
    this.updateTimeline();
    this.wakeControlWaiters();
    this.notifyState("resume");
    return true;
  }

  togglePause() {
    return this.paused ? this.resume() : this.pause();
  }

  seek(index) {
    if (!this.isPlaying || this.readOnly || !this.entitlements.can(FEATURES.TIMELINE_SCRUB)) {
      if (this.isPlaying) this.notifyLockedFeature();
      return false;
    }
    this.requestSeek(index);
    return true;
  }

  step(delta) {
    if (!this.isPlaying || this.readOnly || !this.entitlements.can(FEATURES.TIMELINE_STEP)) {
      if (this.isPlaying) this.notifyLockedFeature();
      return false;
    }
    if (!this.paused) this.pause();
    this.requestSeek(this.currentIndex + Math.sign(Number(delta) || 0));
    return true;
  }

  requestSeek(index) {
    if (!this.currentReplay) return;
    this.seekRequestedIndex = clampTimelineIndex(index, this.currentReplay);
    this.operationController?.abort();
    this.wakeControlWaiters();
    this.notifyState("seek", { eventIndex: this.seekRequestedIndex });
  }

  synchronize(state = {}, { force = false } = {}) {
    if (!this.isPlaying || !this.readOnly || !this.currentReplay) return false;
    const target = clampTimelineIndex(state.eventIndex, this.currentReplay);
    const shouldSeek = force || Math.abs(target - this.currentIndex) > 1;
    if (Number.isFinite(Number(state.speed)) && Number(state.speed) > 0) {
      this.speed = Number(state.speed);
    }
    if (shouldSeek && target !== this.currentIndex) {
      this.seekRequestedIndex = target;
      this.operationController?.abort();
    }
    this.completed = Boolean(state.completed);
    const paused = Boolean(state.paused || state.completed);
    if (paused && !this.paused) this.operationController?.abort();
    this.paused = paused;
    this.updateTimeline();
    this.wakeControlWaiters();
    return true;
  }

  async runPlayback(controller) {
    const signal = controller.signal;
    while (!signal.aborted) {
      if (this.seekRequestedIndex !== null) {
        const target = this.seekRequestedIndex;
        this.seekRequestedIndex = null;
        await this.rebuildToIndex(target, signal);
        continue;
      }

      const events = this.currentReplay?.events ?? [];
      if (this.currentIndex >= events.length) {
        this.completed = true;
        this.updateStatus(localize("BATTLE_REPLAY.playback.finished"));
        this.updateTimeline();
        if (!this.interactive) {
          await sleep(900, signal);
          return;
        }
        this.paused = true;
        this.updateTimeline();
        await this.waitForControl(signal);
        continue;
      }

      await this.waitUntilResumed(signal);
      if (this.seekRequestedIndex !== null || signal.aborted) continue;

      const eventIndex = this.currentIndex;
      const operation = new AbortController();
      const abortOperation = () => operation.abort();
      signal.addEventListener("abort", abortOperation, { once: true });
      this.operationController = operation;
      try {
        await this.playEvent(events[eventIndex], this.currentReplay, this.speed, operation.signal);
        if (!operation.signal.aborted && this.currentIndex === eventIndex) {
          this.currentIndex += 1;
          this.completed = false;
          this.updateTimeline();
          this.notifyState("progress");
        }
      } catch (error) {
        if (!isAbortError(error)) throw error;
        if (signal.aborted) return;
      } finally {
        signal.removeEventListener("abort", abortOperation);
        if (this.operationController === operation) this.operationController = null;
      }
    }
  }

  async waitUntilResumed(signal) {
    while (this.paused && this.seekRequestedIndex === null && !signal.aborted) {
      await this.waitForControl(signal);
    }
  }

  waitForControl(signal) {
    return new Promise((resolve, reject) => {
      if (signal.aborted) {
        reject(new DOMException("Playback aborted", "AbortError"));
        return;
      }
      const wake = () => {
        signal.removeEventListener("abort", abort);
        this.controlWaiters.delete(wake);
        resolve();
      };
      const abort = () => {
        this.controlWaiters.delete(wake);
        reject(new DOMException("Playback aborted", "AbortError"));
      };
      this.controlWaiters.add(wake);
      signal.addEventListener("abort", abort, { once: true });
    });
  }

  wakeControlWaiters() {
    for (const wake of [...this.controlWaiters]) wake();
  }

  async rebuildToIndex(index, signal) {
    if (!this.currentReplay || signal.aborted) return;
    const state = computeReplayState(this.currentReplay, index);
    this.resetGhosts();
    this.currentIndex = state.index;
    this.completed = this.currentIndex >= this.currentReplay.events.length;

    for (const tokenState of state.tokens) {
      if (signal.aborted) return;
      const snapshot = {
        ...tokenState.snapshot,
        ...tokenState.position,
        health: tokenState.health ?? tokenState.snapshot.health,
        conditions: [...tokenState.conditions.values()]
      };
      await this.addGhost(snapshot, this.currentReplay, signal, tokenState.health ?? undefined);
    }

    if (state.currentEvent) {
      this.displayEventSummary(state.currentEvent, this.currentReplay);
    } else {
      this.updateStatus(localize("BATTLE_REPLAY.playback.starting"));
    }
    this.updateTimeline();
    Hooks.callAll(`${MODULE_ID}:playbackSeeked`, this.currentReplay, this.currentIndex);
    this.notifyState("position");
  }

  notifyState(reason, overrides = {}) {
    if (!this.stateListener) return;
    try {
      this.stateListener({ ...this.status, reason, ...overrides });
    } catch (error) {
      warn("Playback state listener failed.", error);
    }
  }

  notifyLockedFeature() {
    ui.notifications.info(localize("BATTLE_REPLAY.notifications.patreonFeature"));
  }

  async playEvent(event, replay, speed, signal) {
    this.enforceNativeTokensHidden();
    const cue = await this.directEvent(event, speed, signal);
    const directedSpeed = speed * Math.max(0.2, Number(cue?.playbackRate) || 1);
    switch (event.type) {
      case "combat-start":
        this.updateStatus(localize("BATTLE_REPLAY.playback.combatStarted"));
        await sleep(500 / directedSpeed, signal);
        break;

      case "turn-change":
        this.showTurn(event.data?.current, replay);
        await sleep(450 / directedSpeed, signal);
        break;

      case "token-move":
        this.showMovement(event.data, replay);
        await this.playMovement(event.data, directedSpeed, signal);
        break;

      case "combatant-added":
        await this.addGhost(event.data?.token, replay, signal);
        this.updateStatus(localize("BATTLE_REPLAY.playback.combatantAdded", {
          actor: event.data?.token?.name ?? localize("BATTLE_REPLAY.playback.unknownCombatant")
        }));
        await sleep(350 / directedSpeed, signal);
        break;

      case "combatant-removed":
      case "token-deleted":
        this.removeGhost(event.data?.tokenId);
        await sleep(250 / directedSpeed, signal);
        break;

      case "token-created":
        this.removeGhost(event.data?.replacesTokenId);
        await this.addGhost(event.data?.token, replay, signal);
        await sleep(250 / directedSpeed, signal);
        break;

      case "item-use":
        this.showItemUse(event.data);
        await sleep(650 / directedSpeed, signal);
        break;

      case "attack-result":
        await this.showAttackEvent(event.data, directedSpeed, signal);
        break;

      case "damage-roll":
        this.showDamageRoll(event.data);
        await sleep(600 / directedSpeed, signal);
        break;

      case "damage":
      case "healing":
        this.showHealthChange(event.type, event.data);
        await sleep(650 / directedSpeed, signal);
        break;

      case "condition-added":
      case "condition-changed":
      case "condition-removed":
        this.showCondition(event.type, event.data);
        await sleep(550 / directedSpeed, signal);
        break;

      case "combatant-defeated":
        this.updateStatus(localize("BATTLE_REPLAY.playback.defeated", {
          actor: event.data?.actorName ?? localize("BATTLE_REPLAY.playback.unknownCombatant")
        }));
        await sleep(800 / directedSpeed, signal);
        break;

      case "check-result":
        await this.showCheckEvent(event.data, directedSpeed, signal);
        break;

      case "template-created":
        this.updateStatus(localize("BATTLE_REPLAY.playback.template"));
        await sleep(350 / directedSpeed, signal);
        break;

      case "visual-effect": {
        this.updateStatus(localize("BATTLE_REPLAY.playback.visualEffect", {
          effect: event.data?.name ?? event.data?.file?.split(/[\\/]/).at(-1) ?? "VFX"
        }));
        const result = await playSequencerVisualEffect(event.data, { speed: directedSpeed, signal });
        if (!result.played) {
          this.updateStatus(localize("BATTLE_REPLAY.playback.visualEffectUnavailable"));
          await sleep(350 / directedSpeed, signal);
        }
        break;
      }

      case "combat-end":
        this.updateStatus(localize("BATTLE_REPLAY.playback.combatEnded"));
        await sleep(500 / directedSpeed, signal);
        break;

      default:
        break;
    }
    await this.finishDirection(cue, speed, signal);
  }

  async directEvent(event, speed, signal) {
    const cue = this.director.plan(event);
    if (!cue || signal.aborted) return cue;
    const points = this.resolveCuePoints(cue);
    if (points.length) await this.animateCamera(cue, points, speed, signal);
    this.showDirectorCue(cue);
    return cue;
  }

  async finishDirection(cue, speed, signal) {
    if (!cue || signal.aborted) return;
    if (cue.shake > 0) await this.playScreenShake(cue.shake, speed, signal);
    if (cue.fade) await this.playDramaticFade(speed, signal);
    if (cue.holdMs > 0) await sleep(cue.holdMs / speed, signal);
  }

  resolveCuePoints(cue = {}) {
    const points = [...(cue.points ?? [])];
    for (const tokenId of cue.focusTokenIds ?? []) {
      const ghost = this.ghosts.get(tokenId);
      if (!ghost) continue;
      const width = Math.max(1, Number(ghost.snapshot?.pixelWidth) || canvas.grid?.size || 100);
      const height = Math.max(1, Number(ghost.snapshot?.pixelHeight) || canvas.grid?.size || 100);
      points.push({
        x: Number(ghost.display?.position?.x ?? ghost.snapshot?.x ?? 0) + (width / 2),
        y: Number(ghost.display?.position?.y ?? ghost.snapshot?.y ?? 0) + (height / 2)
      });
    }
    return points.filter((point) => Number.isFinite(point?.x) && Number.isFinite(point?.y));
  }

  async animateCamera(cue, points, speed, signal) {
    if (typeof canvas.animatePan !== "function" || !points.length) return;
    const bounds = pointBounds(points);
    const x = bounds.left + (bounds.width / 2);
    const y = bounds.top + (bounds.height / 2);
    const scale = computeCameraScale(cue, bounds, this.originalCamera?.scale);
    const duration = cue.transition === "cut"
      ? 80
      : Math.max(120, Number(cue.cameraDuration) / Math.max(0.5, speed));
    await Promise.resolve(canvas.animatePan({ x, y, scale, duration }));
    if (signal.aborted) return;
  }

  showDirectorCue(cue) {
    const badge = this.statusElement?.querySelector?.("[data-role='director-cue']");
    if (!badge) return;
    badge.dataset.kind = cue.kind;
    badge.innerHTML = `<i class="fa-solid ${directorCueIcon(cue.kind)}" aria-hidden="true"></i>${escapeHtml(
      localize(`BATTLE_REPLAY.director.cue.${cue.kind}`)
    )}`;
    badge.classList.remove("is-active");
    void badge.offsetWidth;
    badge.classList.add("is-active");
  }

  async playScreenShake(strength, speed, signal) {
    const board = canvas.app?.view ?? document.querySelector?.("#board");
    if (!board?.classList) return;
    board.style.setProperty("--battle-replay-shake", `${Math.max(2, Number(strength) || 2)}px`);
    board.classList.remove("battle-replay-cinematic-shake");
    void board.offsetWidth;
    board.classList.add("battle-replay-cinematic-shake");
    try {
      await sleep(360 / Math.max(0.5, speed), signal);
    } finally {
      board.classList.remove("battle-replay-cinematic-shake");
      board.style.removeProperty("--battle-replay-shake");
    }
  }

  async playDramaticFade(speed, signal) {
    this.directorOverlay?.remove();
    const overlay = document.createElement("div");
    overlay.className = "battle-replay-cinematic-fade";
    overlay.setAttribute("aria-hidden", "true");
    document.body.append(overlay);
    this.directorOverlay = overlay;
    try {
      await sleep(620 / Math.max(0.5, speed), signal);
    } finally {
      overlay.remove();
      if (this.directorOverlay === overlay) this.directorOverlay = null;
    }
  }

  displayEventSummary(event, replay) {
    const data = event?.data ?? {};
    switch (event?.type) {
      case "combat-start":
        this.updateStatus(localize("BATTLE_REPLAY.playback.combatStarted"));
        break;
      case "combat-end":
        this.updateStatus(localize("BATTLE_REPLAY.playback.combatEnded"));
        break;
      case "turn-change":
        this.showTurn(data.current, replay);
        break;
      case "token-move":
        this.showMovement(data, replay);
        break;
      case "combatant-added":
        this.updateStatus(localize("BATTLE_REPLAY.playback.combatantAdded", {
          actor: data.token?.name ?? localize("BATTLE_REPLAY.playback.unknownCombatant")
        }));
        break;
      case "item-use":
        this.showItemUse(data);
        break;
      case "attack-result":
        this.showAttack(data, { visual: false });
        break;
      case "damage-roll":
        this.showDamageRoll(data);
        break;
      case "damage":
      case "healing":
        this.showHealthChange(event.type, data);
        break;
      case "condition-added":
      case "condition-changed":
      case "condition-removed":
        this.showCondition(event.type, data);
        break;
      case "combatant-defeated":
        this.updateStatus(localize("BATTLE_REPLAY.playback.defeated", {
          actor: data.actorName ?? localize("BATTLE_REPLAY.playback.unknownCombatant")
        }));
        break;
      case "check-result":
        this.showCheck(data, { visual: false });
        break;
      case "template-created":
        this.updateStatus(localize("BATTLE_REPLAY.playback.template"));
        break;
      case "visual-effect":
        this.updateStatus(localize("BATTLE_REPLAY.playback.visualEffect", {
          effect: data.name ?? data.file?.split(/[\\/]/).at(-1) ?? "VFX"
        }));
        break;
      default:
        break;
    }
  }

  showItemUse(data = {}) {
    this.updateStatus(localize("BATTLE_REPLAY.playback.itemUse", {
      actor: data.source?.actorName ?? localize("BATTLE_REPLAY.playback.unknownCombatant"),
      item: data.item?.name ?? localize("BATTLE_REPLAY.playback.unknownAction")
    }));
  }

  showMovement(data = {}, replay = this.currentReplay) {
    const token = replay?.tokens?.find((entry) => entry.id === data.tokenId) ??
      this.ghosts.get(data.tokenId)?.snapshot;
    this.updateStatus(localize(data.teleport
      ? "BATTLE_REPLAY.playback.teleport"
      : "BATTLE_REPLAY.playback.movement", {
      actor: token?.name ?? localize("BATTLE_REPLAY.playback.unknownCombatant")
    }));
  }

  showAttack(data = {}, { visual = true } = {}) {
    const targets = data.targets?.map((target) => target.name).filter(Boolean).join(", ") ||
      localize("BATTLE_REPLAY.playback.unknownTarget");
    const outcome = localizeOutcome(data.outcome);
    this.updateStatus(localize("BATTLE_REPLAY.playback.attack", {
      actor: data.source?.actorName ?? localize("BATTLE_REPLAY.playback.unknownCombatant"),
      item: data.item?.name ?? localize("BATTLE_REPLAY.playback.unknownAction"),
      target: targets,
      outcome
    }));
    if (!visual) return null;
    const result = String(data.outcome ?? "").toLowerCase();
    const label = result === "criticalfailure"
      ? localize("BATTLE_REPLAY.playback.criticalMissLabel")
      : result === "failure"
        ? localize("BATTLE_REPLAY.playback.missLabel")
        : result === "criticalsuccess"
          ? localize("BATTLE_REPLAY.playback.criticalHitLabel")
          : localize("BATTLE_REPLAY.playback.hitLabel");
    const target = data.targets?.[0] ?? {};
    return this.createOutcomeIndicator({
      actorId: target.actorId,
      tokenId: target.tokenId,
      label,
      failure: ["failure", "criticalfailure"].includes(result),
      detail: formatRollDetail(data.total, data.dc, data.item?.name),
      icon: result.includes("critical") ? "★" : "d20"
    });
  }

  async showAttackEvent(data, speed, signal) {
    const indicator = this.showAttack(data);
    try {
      await sleep(800 / speed, signal);
    } finally {
      this.removeTransientIndicator(indicator);
    }
  }

  showDamageRoll(data = {}) {
    this.updateStatus(localize("BATTLE_REPLAY.playback.damageRoll", {
      actor: data.source?.actorName ?? localize("BATTLE_REPLAY.playback.unknownCombatant"),
      total: data.total ?? "?"
    }));
  }

  showHealthChange(type, data = {}) {
    this.updateGhostHealth(data);
    this.updateStatus(localize(
      type === "damage"
        ? "BATTLE_REPLAY.playback.damage"
        : "BATTLE_REPLAY.playback.healing",
      {
        actor: data.actorName ?? localize("BATTLE_REPLAY.playback.unknownCombatant"),
        amount: data.amount ?? "?"
      }
    ));
  }

  showCondition(type, data = {}) {
    this.updateGhostCondition(type, data);
    this.updateStatus(localize(
      type === "condition-added"
        ? "BATTLE_REPLAY.playback.conditionAdded"
        : type === "condition-changed"
          ? "BATTLE_REPLAY.playback.conditionChanged"
          : "BATTLE_REPLAY.playback.conditionRemoved",
      {
        actor: data.actorName ?? localize("BATTLE_REPLAY.playback.unknownCombatant"),
        condition: data.condition?.name ?? localize("BATTLE_REPLAY.playback.unknownCondition")
      }
    ));
  }

  showCheck(data = {}, { visual = true } = {}) {
    const check = formatCheckType(data.checkType);
    this.updateStatus(localize("BATTLE_REPLAY.playback.check", {
      actor: data.source?.actorName ?? localize("BATTLE_REPLAY.playback.unknownCombatant"),
      check,
      total: data.total ?? "?",
      outcome: localizeOutcome(data.outcome)
    }));
    if (!visual) return null;
    const result = String(data.outcome ?? "").toLowerCase();
    const succeeded = ["success", "criticalsuccess"].includes(result);
    return this.createOutcomeIndicator({
      actorId: data.source?.actorId,
      tokenId: data.source?.tokenId,
      label: data.isSavingThrow || /saving-throw|fortitude|reflex|will/i.test(data.checkType ?? "")
        ? `${check.toUpperCase()}: ${succeeded
          ? localize("BATTLE_REPLAY.playback.saveSuccessLabel")
          : localize("BATTLE_REPLAY.playback.saveFailureLabel")}`
        : `${check}: ${data.total ?? "?"}`,
      failure: !succeeded,
      detail: formatRollDetail(data.total, data.dc, check),
      icon: "d20"
    });
  }

  async showCheckEvent(data, speed, signal) {
    const indicator = this.showCheck(data);
    try {
      await sleep(650 / speed, signal);
    } finally {
      this.removeTransientIndicator(indicator);
    }
  }

  createOutcomeIndicator({
    actorId = null,
    tokenId = null,
    label,
    detail = "",
    failure = false,
    icon = "d20"
  } = {}) {
    const ghost = this.findGhost({ actorId, tokenId });
    if (!ghost || !label) return null;
    const width = Math.max(190, Math.min(280, Math.max(label.length * 8, detail.length * 6) + 72));
    const height = 54;
    const container = new PIXI.Container();
    const background = new PIXI.Graphics();
    const iconBackground = new PIXI.Graphics();
    const accentColor = failure ? 0xf45b69 : 0x47d7a0;
    const heading = createStyledPixiText(label, {
      fill: 0xffffff,
      fontSize: 13,
      fontWeight: "800"
    });
    const detailText = createStyledPixiText(detail, {
      fill: 0xcbd5e1,
      fontSize: 10,
      fontWeight: "600"
    });
    const iconText = createStyledPixiText(icon, {
      fill: 0xffffff,
      fontSize: icon === "d20" ? 10 : 17,
      fontWeight: "900"
    });
    drawRoundedRect(background, 0, 0, width, height, 12, 0x090e18, 0.96);
    drawRoundedRect(background, 0, 0, 5, height, 3, accentColor, 1);
    drawRoundedRect(iconBackground, 13, 9, 36, 36, 10, failure ? 0x7e2230 : 0x135f4a, 1);
    heading.anchor?.set?.(0, 0.5);
    heading.position.set(60, 19);
    detailText.anchor?.set?.(0, 0.5);
    detailText.position.set(60, 38);
    iconText.anchor?.set?.(0.5);
    iconText.position.set(31, 27);
    container.position.set((ghost.width - width) / 2, -82);
    container.zIndex = 40;
    container.addChild(background);
    container.addChild(iconBackground);
    container.addChild(heading);
    container.addChild(detailText);
    container.addChild(iconText);
    ghost.display.addChild(container);
    this.transientIndicators.add(container);
    return container;
  }

  removeTransientIndicator(indicator) {
    if (!indicator) return;
    this.transientIndicators.delete(indicator);
    indicator.removeFromParent?.();
    indicator.destroy?.({ children: true });
  }

  updateGhostCondition(type, data = {}) {
    const ghost = this.findGhost(data);
    const condition = data.condition;
    if (!ghost || !condition) return;
    const key = condition.uuid ?? condition.id ?? condition.slug ?? condition.name;
    if (type === "condition-removed") ghost.conditions.delete(key);
    else ghost.conditions.set(key, condition);
    renderConditionOverlay(ghost);
  }

  async addGhost(snapshot, replay = null, signal = null, healthOverride = undefined) {
    if (!snapshot?.id || !this.container || this.ghosts.has(snapshot.id)) return;
    const initialHealth = healthOverride === undefined
      ? normalizeHealthSnapshot(snapshot.health) ?? inferInitialHealth(replay, snapshot)
      : normalizeHealthSnapshot(healthOverride);
    const ghost = await createGhostSprite(snapshot, initialHealth, {
      revealSecrets: this.revealSecrets
    });
    if (signal?.aborted || !this.container) {
      ghost.display.destroy({ children: true });
      return;
    }
    ghost.display.zIndex = 10;
    this.container.addChild(ghost.display);
    this.ghosts.set(snapshot.id, ghost);
  }

  removeGhost(tokenId) {
    const ghost = this.ghosts.get(tokenId);
    if (!ghost) return;
    ghost.display.removeFromParent();
    ghost.display.destroy({ children: true });
    this.ghosts.delete(tokenId);
  }

  updateGhostHealth(data = {}) {
    const ghost = this.findGhost(data);
    if (!ghost) return;

    const current = ghost.healthState ?? {};
    const next = normalizeHealthSnapshot({
      value: finiteOrFallback(data.after, current.value),
      maximum: finiteOrFallback(data.maximum, current.maximum),
      temporary: current.temporary,
      temporaryMaximum: current.temporaryMaximum
    });
    if (!next) return;

    ghost.healthState = next;
    renderHealthOverlay(ghost.healthOverlay, next);
  }

  findGhost(data = {}) {
    if (data.tokenId && this.ghosts.has(data.tokenId)) {
      return this.ghosts.get(data.tokenId);
    }
    if (!data.actorId) return null;
    return [...this.ghosts.values()].find((ghost) => {
      return ghost.snapshot?.actorId === data.actorId;
    }) ?? null;
  }

  showTurn(current = {}, replay) {
    const token = replay.tokens.find((entry) => entry.id === current.tokenId);
    const round = current.round ?? "?";
    const actor = token?.name ?? localize("BATTLE_REPLAY.playback.unknownCombatant");
    this.updateStatus(localize("BATTLE_REPLAY.playback.turn", { round, actor }));
  }

  async playMovement(data, speed, signal) {
    const ghost = this.ghosts.get(data.tokenId);
    if (!ghost) return;

    const origin = pickPosition(data.origin);
    const destination = pickPosition(data.destination);
    if (Number.isFinite(origin.x) && Number.isFinite(origin.y)) {
      ghost.display.position.set(origin.x, origin.y);
      if (Number.isFinite(origin.rotation)) {
        ghost.sprite.angle = origin.rotation + ghost.textureRotation;
      }
    }

    const waypoints = (Array.isArray(data.waypoints) ? data.waypoints : [])
      .map(pickPosition)
      .filter((point) => Number.isFinite(point.x) && Number.isFinite(point.y));

    if (Number.isFinite(destination.x) && Number.isFinite(destination.y)) {
      const last = waypoints.at(-1);
      if (!last || last.x !== destination.x || last.y !== destination.y) {
        waypoints.push(destination);
      }
    }

    if (!waypoints.length) return;

    if (data.teleport) {
      ghost.display.alpha = 0.2;
      await sleep(90 / speed, signal);
      const destinationWaypoint = waypoints.at(-1);
      ghost.display.position.set(destinationWaypoint.x, destinationWaypoint.y);
      if (Number.isFinite(destinationWaypoint.rotation)) {
        ghost.sprite.angle = destinationWaypoint.rotation + ghost.textureRotation;
      }
      await sleep(90 / speed, signal);
      ghost.display.alpha = 1;
      return;
    }

    const originalDuration = Number(data.animationDuration);
    const totalDuration = clamp(
      Number.isFinite(originalDuration) && originalDuration > 0 ? originalDuration : 700,
      300,
      1800
    ) / speed;
    const segmentDuration = totalDuration / waypoints.length;

    for (const waypoint of waypoints) {
      await animateGhost(ghost, waypoint, segmentDuration, signal);
    }
  }

  async createVisualLayer(replay, signal = null) {
    this.destroyVisualLayer();
    this.captureCamera();
    this.hideNativeTokenLayer();

    const container = new PIXI.Container();
    container.label = `${MODULE_ID}-playback`;
    container.sortableChildren = true;
    container.zIndex = 10_000;

    const dimmer = PIXI.Sprite.from(PIXI.Texture.WHITE);
    dimmer.position.set(0, 0);
    dimmer.width = canvas.dimensions.width;
    dimmer.height = canvas.dimensions.height;
    dimmer.tint = 0x070b14;
    // Native Tokens are hidden separately; keep the map and reconstructed VFX readable.
    dimmer.alpha = 0.28;
    dimmer.zIndex = 0;
    container.addChild(dimmer);

    canvas.interface.addChild(container);
    this.container = container;

    for (const snapshot of replay.tokens.filter((entry) => entry.initial !== false)) {
      if (signal?.aborted) break;
      await this.addGhost(snapshot, replay, signal);
    }

    const access = {
      canMarkers: this.entitlements.can(FEATURES.TIMELINE_MARKERS),
      canScrub: this.entitlements.can(FEATURES.TIMELINE_SCRUB),
      canStep: this.entitlements.can(FEATURES.TIMELINE_STEP),
      liveRole: this.liveRole,
      readOnly: this.readOnly,
      tier: this.entitlements.status.tier,
      cinematicEnabled: this.director.enabled,
      cinematicPreset: this.director.preset,
      creatorFormat: this.director.creatorFormat
    };
    this.statusElement = createStatusElement(replay, access, {
      onMarker: (index) => this.seek(index),
      onPause: () => this.togglePause(),
      onSeek: (index) => this.seek(index),
      onStep: (delta) => this.step(delta),
      onStop: () => this.stop()
    });
  }

  resetGhosts() {
    for (const ghost of this.ghosts.values()) {
      ghost.display.removeFromParent();
      ghost.display.destroy({ children: true });
    }
    this.ghosts.clear();
  }

  destroyVisualLayer() {
    if (this.container) {
      this.container.removeFromParent();
      this.container.destroy({ children: true });
    }

    this.statusElement?.remove();
    this.directorOverlay?.remove();
    const board = globalThis.canvas?.app?.view;
    board?.classList?.remove?.("battle-replay-cinematic-shake");
    board?.style?.removeProperty?.("--battle-replay-shake");
    this.container = null;
    this.statusElement = null;
    this.directorOverlay = null;
    this.ghosts.clear();
    for (const indicator of this.transientIndicators) {
      indicator.destroy?.({ children: true });
    }
    this.transientIndicators.clear();
    this.restoreNativeTokenLayer();
    this.restoreCamera();
  }

  hideNativeTokenLayer() {
    const layer = globalThis.canvas?.tokens;
    if (!layer || this.nativeTokenLayerState) return;
    this.nativeTokenLayerState = {
      entries: new Map(),
      hookId: null
    };
    this.enforceNativeTokensHidden();
    if (typeof globalThis.Hooks?.on === "function") {
      this.nativeTokenLayerState.hookId = Hooks.on("refreshToken", (token) => {
        this.hideNativeDisplayObject(token);
        this.hideNativeDisplayObject(token?.mesh);
        this.hideNativeDisplayObject(token?.effects);
      });
    }
  }

  enforceNativeTokensHidden() {
    const layer = globalThis.canvas?.tokens;
    if (!layer || !this.nativeTokenLayerState) return;
    const placeables = Array.isArray(layer.placeables) ? layer.placeables : [];
    for (const object of [layer, layer.objects, layer.preview, ...placeables]) {
      this.hideNativeDisplayObject(object);
      this.hideNativeDisplayObject(object?.mesh);
      this.hideNativeDisplayObject(object?.bars);
      this.hideNativeDisplayObject(object?.nameplate);
      this.hideNativeDisplayObject(object?.effects);
    }
  }

  hideNativeDisplayObject(object) {
    if (!object || !this.nativeTokenLayerState) return;
    const entries = this.nativeTokenLayerState.entries;
    if (!entries.has(object)) {
      entries.set(object, {
        renderable: object.renderable,
        visible: object.visible
      });
    }
    try { object.visible = false; } catch { /* Foundry may expose a read-only visibility getter. */ }
    try { object.renderable = false; } catch { /* The child mesh fallback still applies. */ }
  }

  restoreNativeTokenLayer() {
    const state = this.nativeTokenLayerState;
    if (!state) return;
    if (state.hookId != null && typeof globalThis.Hooks?.off === "function") {
      Hooks.off("refreshToken", state.hookId);
    }
    for (const [object, prior] of state.entries) {
      if (object?.destroyed) continue;
      try { object.visible = prior.visible; } catch { /* Ignore disposed Foundry objects. */ }
      try { object.renderable = prior.renderable; } catch { /* Ignore disposed Foundry objects. */ }
    }
    this.nativeTokenLayerState = null;
  }

  captureCamera() {
    const pivot = globalThis.canvas?.stage?.pivot;
    const scale = globalThis.canvas?.stage?.scale;
    if (!pivot || !scale) return;
    this.originalCamera = {
      x: Number(pivot.x) || 0,
      y: Number(pivot.y) || 0,
      scale: Number(scale.x) || 1
    };
  }

  restoreCamera() {
    const camera = this.originalCamera;
    this.originalCamera = null;
    if (!camera || !globalThis.canvas?.ready || typeof globalThis.canvas.animatePan !== "function") return;
    void globalThis.canvas.animatePan({ ...camera, duration: 240 });
  }

  updateStatus(text) {
    const label = this.statusElement?.querySelector("[data-role='status']");
    if (label) label.textContent = text;
  }

  updateTimeline() {
    const element = this.statusElement;
    const total = this.currentReplay?.events?.length ?? 0;
    const current = clampTimelineIndex(this.currentIndex, total);
    const range = element?.querySelector?.("[data-role='timeline-range']");
    if (range) {
      range.value = String(current);
      range.max = String(total);
      range.setAttribute?.("aria-valuetext", localize("BATTLE_REPLAY.playback.eventPosition", {
        current,
        total
      }));
    }

    const counter = element?.querySelector?.("[data-role='event-position']");
    if (counter) {
      counter.textContent = localize("BATTLE_REPLAY.playback.eventPosition", { current, total });
    }

    const currentAt = current ? Number(this.currentReplay?.events?.[current - 1]?.at) || 0 : 0;
    const totalAt = Number(this.currentReplay?.events?.at(-1)?.at) || 0;
    const time = element?.querySelector?.("[data-role='time-position']");
    if (time) time.textContent = `${formatDuration(currentAt)} / ${formatDuration(totalAt)}`;

    const pauseButton = element?.querySelector?.("[data-action='pause']");
    if (pauseButton) {
      const paused = this.paused || this.completed;
      const label = localize(paused
        ? "BATTLE_REPLAY.playback.resume"
        : "BATTLE_REPLAY.playback.pause");
      pauseButton.setAttribute?.("aria-label", label);
      pauseButton.setAttribute?.("title", label);
      const icon = pauseButton.querySelector?.("i");
      if (icon) icon.className = `fa-solid ${paused ? "fa-play" : "fa-pause"}`;
      const text = pauseButton.querySelector?.("span");
      if (text) text.textContent = label;
    }

    element?.setAttribute?.("data-paused", String(this.paused));
    element?.setAttribute?.("data-completed", String(this.completed));
    for (const marker of element?.querySelectorAll?.("[data-marker-index]") ?? []) {
      const markerIndex = Number(marker.dataset?.markerIndex);
      marker.classList?.toggle?.("is-past", markerIndex < current);
      marker.classList?.toggle?.("is-current", markerIndex === current);
    }

    for (const card of element?.querySelectorAll?.("[data-event-index]") ?? []) {
      const cardIndex = Number(card.dataset?.eventIndex);
      card.classList?.toggle?.("is-past", cardIndex < current);
      card.classList?.toggle?.("is-current", cardIndex === current);
    }

    const activeCard = element?.querySelector?.(`[data-event-index="${current}"]`);
    const eventLane = element?.querySelector?.("[data-role='event-lane']");
    if (activeCard && eventLane && element.dataset.centeredEvent !== String(current)) {
      const left = activeCard.offsetLeft - ((eventLane.clientWidth - activeCard.offsetWidth) / 2);
      eventLane.scrollTo?.({ left: Math.max(0, left), behavior: "smooth" });
      element.dataset.centeredEvent = String(current);
    }
  }
}

function pointBounds(points) {
  const xs = points.map((point) => point.x);
  const ys = points.map((point) => point.y);
  const left = Math.min(...xs);
  const right = Math.max(...xs);
  const top = Math.min(...ys);
  const bottom = Math.max(...ys);
  return {
    left,
    top,
    width: Math.max(1, right - left),
    height: Math.max(1, bottom - top)
  };
}

function computeCameraScale(cue, bounds, fallback = 1) {
  const screen = globalThis.canvas?.app?.renderer?.screen;
  const viewportWidth = Math.max(320, Number(screen?.width) || window.innerWidth || 1280);
  const viewportHeight = Math.max(240, Number(screen?.height) || window.innerHeight || 720);
  const vertical = cue.creatorFormat === CREATOR_FORMATS.VERTICAL ||
    (cue.creatorFormat === CREATOR_FORMATS.AUTO && viewportHeight > viewportWidth);
  const usableWidth = vertical ? Math.min(viewportWidth, viewportHeight * (9 / 16)) : viewportWidth;
  const fit = Math.min(
    (usableWidth - 140) / (bounds.width + 260),
    (viewportHeight - 190) / (bounds.height + 260)
  );
  const preferred = {
    close: cue.preset === CINEMATIC_PRESETS.CREATOR ? 1.45 : 1.28,
    follow: cue.preset === CINEMATIC_PRESETS.CREATOR ? 1.3 : 1.12,
    pair: cue.preset === CINEMATIC_PRESETS.TACTICAL ? Number(fallback) || 1 : 1.05,
    wide: cue.preset === CINEMATIC_PRESETS.CREATOR ? 0.7 : 0.78
  }[cue.framing] ?? (Number(fallback) || 1);
  const scale = bounds.width > 1 || bounds.height > 1 ? Math.min(preferred, fit) : preferred;
  return clamp(scale, 0.35, cue.preset === CINEMATIC_PRESETS.CREATOR ? 1.55 : 1.4);
}

function directorCueIcon(kind) {
  return {
    action: "fa-bolt",
    area: "fa-bullseye",
    attack: "fa-crosshairs",
    critical: "fa-burst",
    defeat: "fa-skull",
    "large-spell": "fa-wand-sparkles",
    movement: "fa-person-running",
    spell: "fa-wand-magic-sparkles",
    turn: "fa-location-crosshairs",
    "visual-effect": "fa-sparkles"
  }[kind] ?? "fa-video";
}

function localizeOutcome(outcome) {
  const normalized = String(outcome ?? "unknown")
    .replaceAll("-", "")
    .replaceAll("_", "")
    .toLowerCase();
  const keys = {
    criticalsuccess: "criticalSuccess",
    success: "success",
    failure: "failure",
    criticalfailure: "criticalFailure"
  };
  const key = keys[normalized] ?? "unknownOutcome";
  return localize("BATTLE_REPLAY.playback." + key);
}

function formatCheckType(checkType) {
  const normalized = String(checkType ?? "check").trim().toLowerCase();
  const key = {
    fortitude: "fortitude",
    reflex: "reflex",
    will: "will",
    "saving-throw": "savingThrow"
  }[normalized];
  if (key) return localize(`BATTLE_REPLAY.playback.${key}`);
  return normalized.replaceAll("-", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

async function createGhostSprite(snapshot, initialHealth = null, options = {}) {
  const texture = await loadSnapshotTexture(snapshot);
  const gridSize = Number(canvas.grid?.size) || 100;
  const width = Math.max(1, Number(snapshot.pixelWidth) || (Number(snapshot.width) || 1) * gridSize);
  const height = Math.max(1, Number(snapshot.pixelHeight) || (Number(snapshot.height) || 1) * gridSize);
  const display = new PIXI.Container();
  const sprite = PIXI.Sprite.from(texture);
  const appearance = snapshot.appearance ?? {};
  const scaleX = finiteOrFallback(appearance.scaleX, 1) || 1;
  const scaleY = finiteOrFallback(appearance.scaleY, 1) || 1;
  const anchorX = clamp(finiteOrFallback(appearance.anchorX, 0.5) ?? 0.5, 0, 1);
  const anchorY = clamp(finiteOrFallback(appearance.anchorY, 0.5) ?? 0.5, 0, 1);
  const textureRotation = finiteOrFallback(appearance.rotation, 0) ?? 0;
  const baseAlpha = snapshot.hidden ? 0.72 : clamp(snapshot.alpha ?? 1, 0.2, 1);

  display.position.set(Number(snapshot.x ?? 0), Number(snapshot.y ?? 0));
  sprite.anchor?.set?.(anchorX, anchorY);
  sprite.position.set(
    (width * anchorX) + (finiteOrFallback(appearance.offsetX, 0) ?? 0),
    (height * anchorY) + (finiteOrFallback(appearance.offsetY, 0) ?? 0)
  );
  sprite.width = width * Math.abs(scaleX);
  sprite.height = height * Math.abs(scaleY);
  if (sprite.scale) {
    if (scaleX < 0) sprite.scale.x = -Math.abs(sprite.scale.x);
    if (scaleY < 0) sprite.scale.y = -Math.abs(sprite.scale.y);
  }
  sprite.angle = (snapshot.rotation ?? 0) + textureRotation;
  sprite.alpha = baseAlpha;

  const tint = colorToNumber(snapshot.appearance?.tint);
  if (Number.isFinite(tint)) {
    sprite.tint = tint;
  } else if (texture === PIXI.Texture.WHITE) {
    sprite.tint = dispositionColor(snapshot.disposition);
  }

  const healthOverlay = createHealthOverlay(width, height);
  const conditionOverlay = createConditionOverlay(width);
  display.addChild(sprite);
  display.addChild(healthOverlay.container);
  display.addChild(conditionOverlay.container);

  const ghost = {
    baseAlpha,
    conditions: new Map((snapshot.conditions ?? []).map((condition) => [
      condition.uuid ?? condition.id ?? condition.slug ?? condition.name,
      condition
    ])),
    conditionOverlay,
    display,
    healthOverlay,
    healthState: initialHealth,
    revealSecrets: Boolean(options.revealSecrets),
    snapshot,
    sprite,
    textureRotation,
    width,
    height
  };
  if (initialHealth) renderHealthOverlay(healthOverlay, initialHealth);
  renderConditionOverlay(ghost);
  return ghost;
}

function createConditionOverlay(tokenWidth) {
  const container = new PIXI.Container();
  const background = new PIXI.Graphics();
  const label = createPixiText();
  container.position.set(tokenWidth / 2, 5);
  container.visible = false;
  container.zIndex = 30;
  label.anchor?.set?.(0.5);
  container.addChild(background);
  container.addChild(label);
  return { background, container, label };
}

function renderConditionOverlay(ghost) {
  const conditions = [...(ghost.conditions?.values?.() ?? [])];
  const overlay = ghost.conditionOverlay;
  if (!overlay) return;
  const labels = conditions.map((condition) => String(condition.name ?? condition.slug ?? "").trim())
    .filter(Boolean);
  overlay.container.visible = labels.length > 0;
  overlay.label.text = labels.join(" • ");
  overlay.background.clear();
  if (labels.length) {
    const width = Math.max(60, Math.min(240, overlay.label.text.length * 7 + 16));
    drawRoundedRect(overlay.background, -width / 2, -10, width, 20, 6, 0x172235, 0.9);
  }

  const slugs = conditions.map((condition) => String(condition.slug ?? condition.name ?? "").toLowerCase());
  const invisible = slugs.some((slug) => /invisible|invisibility|hidden|undetected/.test(slug));
  const secret = ghost.snapshot?.hidden === true || invisible;
  ghost.display.visible = ghost.revealSecrets || !secret;
  ghost.sprite.alpha = invisible && ghost.revealSecrets
    ? Math.min(ghost.baseAlpha, 0.32)
    : ghost.baseAlpha;
}

export function getStoredTextureSource(snapshot = {}) {
  const candidates = [
    snapshot.appearance?.texture,
    typeof snapshot.texture === "string" ? snapshot.texture : snapshot.texture?.src
  ];
  return candidates.find((entry) => typeof entry === "string" && entry.trim())?.trim() ?? null;
}

async function loadSnapshotTexture(snapshot) {
  const source = getStoredTextureSource(snapshot);
  if (!source) return PIXI.Texture.WHITE;

  const loader = globalThis.foundry?.canvas?.loadTexture ?? globalThis.loadTexture;
  if (typeof loader !== "function") return PIXI.Texture.WHITE;

  try {
    const loaded = await loader(source, { fallback: "icons/svg/mystery-man.svg" });
    if (loaded?.baseTexture || loaded?.source) return loaded;
    const sheetTexture = Object.values(loaded?.textures ?? {})[0];
    return sheetTexture ?? PIXI.Texture.WHITE;
  } catch (error) {
    warn("Could not load recorded Token texture " + source + ".", error);
    return PIXI.Texture.WHITE;
  }
}

export function inferInitialHealth(replay, snapshot = {}) {
  if (!Array.isArray(replay?.events)) return null;
  const event = replay.events.find((entry) => {
    if (!["damage", "healing"].includes(entry?.type)) return false;
    const data = entry.data ?? {};
    return data.tokenId === snapshot.id ||
      (snapshot.actorId && data.actorId === snapshot.actorId);
  });
  if (!event) return null;

  return normalizeHealthSnapshot({
    value: event.data?.before,
    maximum: event.data?.maximum
  });
}

export function normalizeHealthSnapshot(health) {
  if (!health || typeof health !== "object") return null;
  const normalized = {
    value: finiteOrNull(health.value),
    maximum: finiteOrNull(health.maximum ?? health.max),
    temporary: finiteOrNull(health.temporary ?? health.temp),
    temporaryMaximum: finiteOrNull(health.temporaryMaximum ?? health.tempmax)
  };
  if (Object.values(normalized).every((entry) => entry === null)) return null;
  return normalized;
}

function createHealthOverlay(tokenWidth, tokenHeight) {
  const width = clamp(Number(tokenWidth) || 100, 54, 180);
  const height = clamp(Math.round(width * 0.12), 12, 18);
  const container = new PIXI.Container();
  const background = new PIXI.Graphics();
  const fill = new PIXI.Graphics();
  const label = createPixiText();

  container.position.set((tokenWidth - width) / 2, -height - 7);
  container.visible = false;
  container.zIndex = 20;
  drawRoundedRect(background, -2, -2, width + 4, height + 4, 5, 0x05070c, 0.92);
  drawRoundedRect(background, 0, 0, width, height, 3, 0x3a1116, 0.96);

  label.anchor?.set?.(0.5);
  label.position.set(width / 2, height / 2);
  label.zIndex = 2;
  container.addChild(background);
  container.addChild(fill);
  container.addChild(label);

  return { background, container, fill, height, label, width };
}

function renderHealthOverlay(overlay, health) {
  if (!overlay || !health) return;
  const maximum = finiteOrNull(health.maximum);
  const value = finiteOrNull(health.value);
  const hasValue = value !== null;
  const hasMaximum = maximum !== null && maximum > 0;
  if (!hasValue && !hasMaximum) return;

  const safeValue = hasValue ? Math.max(0, value) : maximum;
  const ratio = hasMaximum ? clamp(safeValue / maximum, 0, 1) : 1;
  const fillWidth = overlay.width * ratio;
  const color = ratio > 0.5 ? 0x2fbd5b : ratio > 0.25 ? 0xe0a126 : 0xd83a49;
  overlay.fill.clear();
  if (fillWidth > 0) {
    drawRoundedRect(overlay.fill, 0, 0, fillWidth, overlay.height, 3, color, 1);
  }

  const temporary = finiteOrNull(health.temporary);
  const temporaryLabel = temporary !== null && temporary > 0 ? ` +${temporary}` : "";
  overlay.label.text = hasMaximum
    ? `${Math.round(safeValue)} / ${Math.round(maximum)}${temporaryLabel}`
    : `${Math.round(safeValue)}${temporaryLabel}`;
  overlay.container.visible = true;
}

function createPixiText() {
  return createStyledPixiText("", {
    align: "center",
    fill: 0xffffff,
    fontFamily: "Arial, sans-serif",
    fontSize: 11,
    fontWeight: "700",
    stroke: 0x000000,
    strokeThickness: 3
  });
}

function createStyledPixiText(text, style = {}) {
  const resolvedStyle = {
    fontFamily: "Arial, sans-serif",
    ...style
  };
  const major = Number.parseInt(String(PIXI.VERSION ?? "7").split(".")[0], 10);
  return major >= 8
    ? new PIXI.Text({ text, style: resolvedStyle })
    : new PIXI.Text(text, resolvedStyle);
}

function formatRollDetail(total, dc, subject) {
  const parts = [];
  if (typeof subject === "string" && subject.trim()) parts.push(subject.trim());
  const roll = finiteOrNull(total);
  const difficulty = finiteOrNull(dc);
  if (roll !== null) {
    parts.push(localize("BATTLE_REPLAY.playback.rollTotal", { total: Math.round(roll) }));
  }
  if (difficulty !== null) {
    parts.push(localize("BATTLE_REPLAY.playback.difficultyClass", { dc: Math.round(difficulty) }));
  }
  return parts.join(" • ");
}

function drawRoundedRect(graphics, x, y, width, height, radius, color, alpha) {
  if (typeof graphics.roundRect === "function" && typeof graphics.fill === "function") {
    graphics.roundRect(x, y, width, height, radius).fill({ color, alpha });
    return;
  }
  graphics.beginFill(color, alpha);
  graphics.drawRoundedRect(x, y, width, height, radius);
  graphics.endFill();
}

function colorToNumber(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value !== "string" || !value.trim()) return null;
  const normalized = value.trim().replace(/^#/, "");
  if (!/^[0-9a-f]{6}$/i.test(normalized)) return null;
  return Number.parseInt(normalized, 16);
}

function finiteOrFallback(value, fallback) {
  const number = finiteOrNull(value);
  return number ?? finiteOrNull(fallback);
}

function finiteOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function dispositionColor(disposition) {
  if (disposition > 0) return 0x3fa75f;
  if (disposition < 0) return 0xc74646;
  return 0x4f87c7;
}

function createStatusElement(replay, access, callbacks) {
  const visualItems = access.canMarkers
    ? buildVisualTimelineItems(replay, { maxMarkers: 320 })
    : [];
  const markers = visualItems;
  const total = replay.events?.length ?? 0;
  const markerHtml = markers.map((marker) => {
    const category = timelineCategoryLabel(marker.category);
    const title = localize("BATTLE_REPLAY.playback.markerLabel", {
      category,
      current: marker.index,
      total
    });
    return [
      '<button type="button" class="battle-replay-timeline-marker category-',
      marker.category,
      '" data-marker-index="',
      String(marker.index),
      access.readOnly ? '" disabled data-read-only="true' : "",
      '" style="--marker-position:',
      marker.percent.toFixed(4),
      '%" aria-label="',
      escapeHtml(title),
      '" title="',
      escapeHtml(title),
      '"><i class="fa-solid ',
      marker.icon,
      '" aria-hidden="true"></i></button>'
    ].join("");
  }).join("");
  const categories = [...new Set(markers.map((marker) => marker.category))];
  const legendHtml = categories.map((category) => {
    return `<span class="category-${category}"><i aria-hidden="true"></i>${escapeHtml(
      timelineCategoryLabel(category)
    )}</span>`;
  }).join("");
  const visualEventHtml = visualItems.map((item) => {
    const event = replay.events?.[item.eventIndex] ?? {};
    const description = timelineEventDescription(event, replay);
    const title = timelineEventTitle(item, event);
    const image = item.image
      ? `<img src="${escapeHtml(item.image)}" alt="">`
      : "";
    const imageClass = item.image ? " has-image" : "";
    const badge = item.badge
      ? `<span class="battle-replay-event-badge">${escapeHtml(item.badge)}</span>`
      : "";
    return `
      <button type="button" class="battle-replay-event-card category-${item.category}"
        data-event-index="${item.index}" role="listitem"
        ${access.readOnly ? "disabled data-read-only=\"true\"" : ""}
        aria-label="${escapeHtml(description)}" title="${escapeHtml(description)}">
        <span class="battle-replay-event-art${imageClass}">
          ${image}
          <i class="fa-solid ${item.icon}" aria-hidden="true"></i>
          ${badge}
        </span>
        <span class="battle-replay-event-copy">
          <strong>${escapeHtml(title)}</strong>
          <small>${escapeHtml(description)}</small>
        </span>
        <span class="battle-replay-event-number">${item.index}</span>
      </button>
    `;
  }).join("");
  const premiumLocked = !access.readOnly &&
    (!access.canMarkers || !access.canScrub || !access.canStep);
  const liveBadge = access.liveRole
    ? `<span class="battle-replay-live-badge"><i class="fa-solid fa-tower-broadcast"></i>${escapeHtml(
        localize("BATTLE_REPLAY.playback.live")
      )}</span>`
    : "";
  const viewerNotice = access.readOnly
    ? `<span class="battle-replay-viewer-notice">${escapeHtml(
        localize("BATTLE_REPLAY.playback.gmControlled")
      )}</span>`
    : "";
  const directorBadge = access.cinematicEnabled
    ? `<span class="battle-replay-director-preset"><i class="fa-solid fa-video"></i>${escapeHtml(
        localize(`BATTLE_REPLAY.director.preset.${access.cinematicPreset}`)
      )}</span><span class="battle-replay-director-cue" data-role="director-cue"></span>`
    : "";
  const element = document.createElement("section");
  element.className = "battle-replay-playback-status";
  if (access.liveRole) element.classList.add("is-live-replay", `is-live-${access.liveRole}`);
  element.tabIndex = 0;
  element.innerHTML = `
    <div class="battle-replay-playback-heading">
      <i class="fa-solid fa-forward-fast" aria-hidden="true"></i>
      <span data-role="status"></span>
      ${liveBadge}
      ${viewerNotice}
      ${directorBadge}
      ${premiumLocked ? `<span class="battle-replay-tier-badge" title="${escapeHtml(
        localize("BATTLE_REPLAY.playback.patreonLockedHint")
      )}">Patreon</span>` : ""}
      ${access.readOnly ? "" : `<button type="button" data-action="stop" aria-label="${escapeHtml(
        localize("BATTLE_REPLAY.playback.stop")
      )}">
        <i class="fa-solid fa-stop" aria-hidden="true"></i>
        <span>${escapeHtml(localize("BATTLE_REPLAY.playback.stop"))}</span>
      </button>`}
      ${visualItems.length ? `<button type="button" data-action="toggle-events" aria-expanded="true"
        aria-label="${escapeHtml(localize("BATTLE_REPLAY.playback.hideEvents"))}"
        title="${escapeHtml(localize("BATTLE_REPLAY.playback.hideEvents"))}">
        <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
        <span>${escapeHtml(localize("BATTLE_REPLAY.playback.events"))}</span>
      </button>` : ""}
    </div>
    <div class="battle-replay-timeline-controls">
      <button type="button" data-action="previous" ${access.canStep && !access.readOnly ? "" : "disabled"}
        aria-label="${escapeHtml(localize("BATTLE_REPLAY.playback.previousEvent"))}"
        title="${escapeHtml(access.readOnly
          ? localize("BATTLE_REPLAY.playback.gmControlled")
          : access.canStep
          ? localize("BATTLE_REPLAY.playback.previousEvent")
          : localize("BATTLE_REPLAY.playback.patreonLockedHint"))}">
        <i class="fa-solid fa-backward-step" aria-hidden="true"></i>
      </button>
      <button type="button" data-action="pause" ${access.readOnly ? "disabled" : ""}
        aria-label="${escapeHtml(localize("BATTLE_REPLAY.playback.pause"))}"
        title="${escapeHtml(localize("BATTLE_REPLAY.playback.pause"))}">
        <i class="fa-solid fa-pause" aria-hidden="true"></i>
        <span>${escapeHtml(localize("BATTLE_REPLAY.playback.pause"))}</span>
      </button>
      <button type="button" data-action="next" ${access.canStep && !access.readOnly ? "" : "disabled"}
        aria-label="${escapeHtml(localize("BATTLE_REPLAY.playback.nextEvent"))}"
        title="${escapeHtml(access.readOnly
          ? localize("BATTLE_REPLAY.playback.gmControlled")
          : access.canStep
          ? localize("BATTLE_REPLAY.playback.nextEvent")
          : localize("BATTLE_REPLAY.playback.patreonLockedHint"))}">
        <i class="fa-solid fa-forward-step" aria-hidden="true"></i>
      </button>
      <span class="battle-replay-timeline-time" data-role="time-position">0:00 / 0:00</span>
    </div>
    <div class="battle-replay-timeline" aria-label="${escapeHtml(
      localize("BATTLE_REPLAY.playback.timeline")
    )}">
      <input data-role="timeline-range" type="range" min="0" max="${total}" value="0"
        step="1" ${access.canScrub && !access.readOnly ? "" : "disabled"}
        aria-label="${escapeHtml(localize("BATTLE_REPLAY.playback.timeline"))}"
        title="${escapeHtml(access.readOnly
          ? localize("BATTLE_REPLAY.playback.gmControlled")
          : access.canScrub
          ? localize("BATTLE_REPLAY.playback.timelineHint")
          : localize("BATTLE_REPLAY.playback.patreonLockedHint"))}">
      <div class="battle-replay-timeline-markers" aria-hidden="${markers.length ? "false" : "true"}">
        ${markerHtml}
      </div>
    </div>
    <div class="battle-replay-timeline-footer">
      <span data-role="event-position">${escapeHtml(localize(
        "BATTLE_REPLAY.playback.eventPosition",
        { current: 0, total }
      ))}</span>
      ${legendHtml ? `<span class="battle-replay-timeline-legend">${legendHtml}</span>` : ""}
    </div>
    ${visualItems.length ? `
      <section class="battle-replay-event-drawer" data-role="event-drawer">
        <div class="battle-replay-event-drawer-heading">
          <strong>${escapeHtml(localize("BATTLE_REPLAY.playback.eventLane"))}</strong>
          <span>${escapeHtml(localize("BATTLE_REPLAY.playback.eventLaneHint"))}</span>
        </div>
        <div class="battle-replay-event-lane" data-role="event-lane" role="list">
          ${visualEventHtml}
        </div>
      </section>
    ` : ""}
  `;
  element.querySelector("[data-action='stop']")?.addEventListener("click", callbacks.onStop);
  element.querySelector("[data-action='pause']")?.addEventListener("click", callbacks.onPause);
  element.querySelector("[data-action='toggle-events']")?.addEventListener("click", (event) => {
    const collapsed = element.classList.toggle("is-events-collapsed");
    const button = event.currentTarget;
    const label = localize(collapsed
      ? "BATTLE_REPLAY.playback.showEvents"
      : "BATTLE_REPLAY.playback.hideEvents");
    button.setAttribute("aria-expanded", String(!collapsed));
    button.setAttribute("aria-label", label);
    button.setAttribute("title", label);
    const icon = button.querySelector("i");
    if (icon) icon.className = `fa-solid ${collapsed ? "fa-chevron-up" : "fa-chevron-down"}`;
  });
  element.querySelector("[data-action='previous']")?.addEventListener("click", () => {
    callbacks.onStep(-1);
  });
  element.querySelector("[data-action='next']")?.addEventListener("click", () => {
    callbacks.onStep(1);
  });
  element.querySelector("[data-role='timeline-range']")?.addEventListener("input", (event) => {
    callbacks.onSeek(Number(event.currentTarget.value));
  });
  for (const marker of element.querySelectorAll?.("[data-marker-index]") ?? []) {
    marker.addEventListener("click", () => callbacks.onMarker(Number(marker.dataset.markerIndex)));
  }
  for (const card of element.querySelectorAll?.("[data-event-index]") ?? []) {
    card.addEventListener("click", () => callbacks.onMarker(Number(card.dataset.eventIndex)));
    const image = card.querySelector("img");
    image?.addEventListener("error", () => card.querySelector(".battle-replay-event-art")
      ?.classList.remove("has-image"), { once: true });
  }
  element.addEventListener?.("keydown", (event) => {
    if (event.target?.matches?.("input, button")) return;
    if (event.code === "Space") {
      event.preventDefault();
      callbacks.onPause();
    } else if (event.key === "ArrowLeft") {
      event.preventDefault();
      callbacks.onStep(-1);
    } else if (event.key === "ArrowRight") {
      event.preventDefault();
      callbacks.onStep(1);
    } else if (event.key === "Home") {
      event.preventDefault();
      callbacks.onSeek(0);
    } else if (event.key === "End") {
      event.preventDefault();
      callbacks.onSeek(total);
    }
  });
  document.body.append(element);
  return element;
}

function timelineEventTitle(item, event) {
  if (item.itemName) return item.itemName;
  if (event?.data?.condition?.name) return event.data.condition.name;
  if (item.actorName) return item.actorName;
  return timelineCategoryLabel(item.category);
}

function timelineEventDescription(event, replay) {
  const data = event?.data ?? {};
  const unknownCombatant = localize("BATTLE_REPLAY.playback.unknownCombatant");
  const actor = data.source?.actorName ?? data.actorName ??
    data.token?.name ?? data.snapshot?.name ??
    replay?.tokens?.find((token) => token.id === (
      data.tokenId ?? data.current?.tokenId ?? data.source?.tokenId
    ))?.name ?? unknownCombatant;
  const target = data.targets?.map((entry) => entry.name).filter(Boolean).join(", ") ||
    localize("BATTLE_REPLAY.playback.unknownTarget");

  switch (event?.type) {
    case "combat-start":
      return localize("BATTLE_REPLAY.playback.combatStarted");
    case "combat-end":
      return localize("BATTLE_REPLAY.playback.combatEnded");
    case "turn-change":
      return localize("BATTLE_REPLAY.playback.turn", {
        round: data.current?.round ?? "?",
        actor
      });
    case "token-move":
      return localize(data.teleport
        ? "BATTLE_REPLAY.playback.teleport"
        : "BATTLE_REPLAY.playback.movement", { actor });
    case "combatant-added":
      return localize("BATTLE_REPLAY.playback.combatantAdded", { actor });
    case "item-use":
      return localize("BATTLE_REPLAY.playback.itemUse", {
        actor,
        item: data.item?.name ?? localize("BATTLE_REPLAY.playback.unknownAction")
      });
    case "attack-result":
      return localize("BATTLE_REPLAY.playback.attack", {
        actor,
        item: data.item?.name ?? localize("BATTLE_REPLAY.playback.unknownAction"),
        target,
        outcome: localizeOutcome(data.outcome)
      });
    case "damage-roll":
      return localize("BATTLE_REPLAY.playback.damageRoll", { actor, total: data.total ?? "?" });
    case "damage":
    case "healing":
      return localize(
        event.type === "damage"
          ? "BATTLE_REPLAY.playback.damage"
          : "BATTLE_REPLAY.playback.healing",
        { actor, amount: data.amount ?? "?" }
      );
    case "condition-added":
    case "condition-changed":
    case "condition-removed":
      return localize(
        event.type === "condition-added"
          ? "BATTLE_REPLAY.playback.conditionAdded"
          : event.type === "condition-changed"
            ? "BATTLE_REPLAY.playback.conditionChanged"
            : "BATTLE_REPLAY.playback.conditionRemoved",
        {
          actor,
          condition: data.condition?.name ?? localize("BATTLE_REPLAY.playback.unknownCondition")
        }
      );
    case "combatant-defeated":
      return localize("BATTLE_REPLAY.playback.defeated", { actor });
    case "check-result":
      return localize("BATTLE_REPLAY.playback.check", {
        actor,
        check: formatCheckType(data.checkType),
        total: data.total ?? "?",
        outcome: localizeOutcome(data.outcome)
      });
    case "template-created":
      return localize("BATTLE_REPLAY.playback.template");
    case "visual-effect":
      return localize("BATTLE_REPLAY.playback.visualEffect", {
        effect: data.name ?? data.file?.split(/[\\/]/).at(-1) ?? "VFX"
      });
    default:
      return timelineCategoryLabel(timelineCategory(event) ?? "action");
  }
}

function timelineCategoryLabel(category) {
  const suffix = {
    action: "Action",
    attack: "Attack",
    condition: "Condition",
    defeat: "Defeat",
    health: "Health",
    magic: "Magic",
    movement: "Movement",
    save: "Save",
    turn: "Turn"
  }[category] ?? "Action";
  return localize(`BATTLE_REPLAY.playback.timelineCategory${suffix}`);
}

function animateGhost(ghost, destination, duration, signal) {
  const start = {
    x: ghost.display.x,
    y: ghost.display.y,
    rotation: ghost.sprite.angle
  };
  const targetRotation = Number.isFinite(destination.rotation)
    ? destination.rotation + ghost.textureRotation
    : start.rotation;

  return new Promise((resolve, reject) => {
    if (signal.aborted) {
      reject(new DOMException("Playback aborted", "AbortError"));
      return;
    }

    const startedAt = performance.now();

    function frame(now) {
      if (signal.aborted) {
        reject(new DOMException("Playback aborted", "AbortError"));
        return;
      }

      const progress = clamp((now - startedAt) / Math.max(1, duration), 0, 1);
      const eased = 1 - ((1 - progress) ** 3);
      ghost.display.position.set(
        start.x + ((destination.x - start.x) * eased),
        start.y + ((destination.y - start.y) * eased)
      );
      ghost.sprite.angle = start.rotation + ((targetRotation - start.rotation) * eased);

      if (progress >= 1) {
        resolve();
        return;
      }

      window.requestAnimationFrame(frame);
    }

    window.requestAnimationFrame(frame);
  });
}
