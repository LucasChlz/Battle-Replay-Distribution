import {
  DATA_FOLDER_NAME,
  MODULE_ID,
  SETTINGS,
  STORAGE_VERSION
} from "./constants.mjs";
import {
  migrateReplay,
  prepareReplayForSave,
  validateReplay
} from "./migrations.mjs";
import { safeParseJson, warn } from "./utils.mjs";

export class ReplayStorage {
  constructor() {
    this.folderId = null;
    this.useLegacy = false;
    this.writeQueue = Promise.resolve();
  }

  enableLegacyFallback() {
    this.useLegacy = true;
  }

  async initialize() {
    if (!game.user?.isGM) return;
    await this.ensureDataFolder();
    await this.migrateLegacySetting();
    await this.migrateStoredDocuments();
    await game.settings.set(MODULE_ID, SETTINGS.STORAGE_VERSION, STORAGE_VERSION);
  }

  getReplays() {
    if (this.useLegacy) {
      const stored = safeParseJson(game.settings.get(MODULE_ID, SETTINGS.REPLAYS), []);
      return (Array.isArray(stored) ? stored : [])
        .map(migrateReplay)
        .filter(Boolean)
        .sort((left, right) => Number(right.startedAt) - Number(left.startedAt));
    }
    return this.getReplayDocuments()
      .map((document) => migrateReplay(document.getFlag(MODULE_ID, "replay")))
      .filter(Boolean)
      .sort((left, right) => Number(right.startedAt) - Number(left.startedAt));
  }

  getReplay(replayId) {
    if (this.useLegacy) {
      return this.getReplays().find((replay) => replay.id === replayId) ?? null;
    }
    const document = this.getReplayDocument(replayId);
    return document ? migrateReplay(document.getFlag(MODULE_ID, "replay")) : null;
  }

  getStorageStats() {
    const replays = this.getReplays();
    return {
      count: replays.length,
      bytes: replays.reduce((total, replay) => total + JSON.stringify(replay).length, 0)
    };
  }

  getActiveRecording() {
    const stored = game.settings.get(MODULE_ID, SETTINGS.ACTIVE_RECORDING);
    const recording = safeParseJson(stored, null);
    return recording && typeof recording === "object" ? migrateReplay(recording) : null;
  }

  async saveActiveRecording(recording) {
    const prepared = recording ? prepareReplayForSave(recording) : null;
    const serialized = prepared ? JSON.stringify(prepared) : "";
    return this.enqueue(() => game.settings.set(
      MODULE_ID,
      SETTINGS.ACTIVE_RECORDING,
      serialized
    ));
  }

  async clearActiveRecording() {
    return this.saveActiveRecording(null);
  }

  async saveReplay(replay) {
    const prepared = prepareReplayForSave(replay);
    if (!prepared) throw new Error("Invalid replay.");

    if (this.useLegacy) {
      return this.enqueue(async () => {
        const maximum = Number(game.settings.get(MODULE_ID, SETTINGS.MAX_REPLAYS)) || 100;
        const replays = this.getReplays().filter((entry) => entry.id !== prepared.id);
        replays.unshift(prepared);
        await game.settings.set(
          MODULE_ID,
          SETTINGS.REPLAYS,
          JSON.stringify(replays.slice(0, maximum))
        );
        return prepared;
      });
    }

    return this.enqueue(async () => {
      if (!this.folderId || !game.folders.get(this.folderId)) {
        await this.ensureDataFolder();
      }
      const existing = this.getReplayDocument(prepared.id);
      const data = {
        name: documentName(prepared),
        folder: this.folderId,
        pages: [],
        ownership: {
          default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE
        },
        flags: {
          [MODULE_ID]: {
            replayId: prepared.id,
            replay: prepared
          }
        }
      };

      if (existing) {
        await existing.update(data);
      } else {
        await JournalEntry.create(data);
      }

      await this.enforceMaximum();
      return prepared;
    });
  }

  async updateReplay(replayId, changes) {
    const replay = this.getReplay(replayId);
    if (!replay) return null;
    const updated = {
      ...replay,
      ...changes,
      id: replay.id,
      metadata: replay.metadata
    };
    return this.saveReplay(updated);
  }

  async deleteReplay(replayId) {
    if (this.useLegacy) {
      return this.enqueue(() => game.settings.set(
        MODULE_ID,
        SETTINGS.REPLAYS,
        JSON.stringify(this.getReplays().filter((replay) => replay.id !== replayId))
      ));
    }
    return this.enqueue(async () => {
      const document = this.getReplayDocument(replayId);
      if (document) await document.delete();
    });
  }

  async deleteReplays(replayIds) {
    const ids = new Set(replayIds);
    if (this.useLegacy) {
      return this.enqueue(() => game.settings.set(
        MODULE_ID,
        SETTINGS.REPLAYS,
        JSON.stringify(this.getReplays().filter((replay) => !ids.has(replay.id)))
      ));
    }
    return this.enqueue(async () => {
      const documents = this.getReplayDocuments().filter((document) => {
        return ids.has(document.getFlag(MODULE_ID, "replayId"));
      });
      for (const document of documents) await document.delete();
    });
  }

  async importReplay(source) {
    const validation = validateReplay(source);
    if (!validation.valid) return validation;

    const replay = validation.replay;
    if (this.getReplay(replay.id)) replay.id = foundry.utils.randomID();
    await this.saveReplay(replay);
    return { valid: true, replay };
  }

  async ensureDataFolder() {
    const storedId = game.settings.get(MODULE_ID, SETTINGS.DATA_FOLDER_ID);
    let folder = storedId ? game.folders.get(storedId) : null;
    if (folder?.type !== "JournalEntry") folder = null;

    folder ??= game.folders.find((entry) => {
      return entry.type === "JournalEntry" && entry.getFlag(MODULE_ID, "dataFolder");
    }) ?? null;

    if (!folder) {
      folder = await Folder.create({
        name: DATA_FOLDER_NAME,
        type: "JournalEntry",
        sorting: "a",
        flags: {
          [MODULE_ID]: {
            dataFolder: true
          }
        }
      });
    }

    this.folderId = folder.id;
    if (storedId !== folder.id) {
      await game.settings.set(MODULE_ID, SETTINGS.DATA_FOLDER_ID, folder.id);
    }
    return folder;
  }

  getReplayDocuments() {
    if (!game.journal) return [];
    return game.journal.filter((document) => {
      return Boolean(document.getFlag(MODULE_ID, "replayId"));
    });
  }

  getReplayDocument(replayId) {
    return this.getReplayDocuments().find((document) => {
      return document.getFlag(MODULE_ID, "replayId") === replayId;
    }) ?? null;
  }

  enqueue(operation) {
    const next = this.writeQueue.then(operation, operation);
    this.writeQueue = next.catch((error) => {
      warn("Storage operation failed.", error);
    });
    return next;
  }

  async enforceMaximum() {
    const maximum = Number(game.settings.get(MODULE_ID, SETTINGS.MAX_REPLAYS)) || 100;
    const documents = this.getReplayDocuments()
      .map((document) => ({
        document,
        replay: migrateReplay(document.getFlag(MODULE_ID, "replay"))
      }))
      .filter((entry) => entry.replay)
      .sort((left, right) => Number(right.replay.startedAt) - Number(left.replay.startedAt));

    for (const entry of documents.slice(maximum)) {
      await entry.document.delete();
    }
  }

  async migrateLegacySetting() {
    const stored = game.settings.get(MODULE_ID, SETTINGS.REPLAYS);
    const legacy = safeParseJson(stored, []);
    if (!Array.isArray(legacy) || !legacy.length) return;

    for (const source of legacy) {
      const replay = migrateReplay(source);
      if (replay && !this.getReplay(replay.id)) await this.saveReplay(replay);
    }

    await game.settings.set(MODULE_ID, SETTINGS.REPLAYS, "[]");
  }

  async migrateStoredDocuments() {
    for (const document of this.getReplayDocuments()) {
      const source = document.getFlag(MODULE_ID, "replay");
      const replay = migrateReplay(source);
      if (!replay) continue;
      if (Number(source?.schemaVersion) !== replay.schemaVersion || !source?.metadata) {
        await document.update({
          name: documentName(replay),
          ["flags." + MODULE_ID + ".replay"]: replay
        });
      }
    }
  }
}

function documentName(replay) {
  const date = new Date(Number(replay.startedAt)).toLocaleDateString();
  return String(replay.title + " — " + date).slice(0, 120);
}
