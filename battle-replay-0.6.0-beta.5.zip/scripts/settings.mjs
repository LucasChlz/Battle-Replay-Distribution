import {
  CINEMATIC_PRESETS,
  CREATOR_FORMATS,
  LIMITS,
  MODULE_ID,
  SETTINGS
} from "./constants.mjs";

export function registerSettings() {
  game.settings.register(MODULE_ID, SETTINGS.AUTO_RECORD, {
    name: "BATTLE_REPLAY.settings.autoRecord.name",
    hint: "BATTLE_REPLAY.settings.autoRecord.hint",
    scope: "world",
    config: false,
    type: Boolean,
    default: true,
    requiresReload: false
  });

  game.settings.register(MODULE_ID, SETTINGS.MAX_REPLAYS, {
    name: "BATTLE_REPLAY.settings.maxReplays.name",
    hint: "BATTLE_REPLAY.settings.maxReplays.hint",
    scope: "world",
    config: true,
    type: Number,
    default: 100,
    range: {
      min: LIMITS.MIN_REPLAYS,
      max: LIMITS.MAX_REPLAYS,
      step: 1
    },
    requiresReload: false
  });

  game.settings.register(MODULE_ID, SETTINGS.PLAYBACK_SPEED, {
    name: "BATTLE_REPLAY.settings.playbackSpeed.name",
    hint: "BATTLE_REPLAY.settings.playbackSpeed.hint",
    scope: "client",
    config: true,
    type: Number,
    default: 2,
    choices: {
      1: "1×",
      2: "2×",
      4: "4×",
      8: "8×"
    },
    requiresReload: false
  });

  game.settings.register(MODULE_ID, SETTINGS.CINEMATIC_PRESET, {
    name: "BATTLE_REPLAY.settings.cinematicPreset.name",
    hint: "BATTLE_REPLAY.settings.cinematicPreset.hint",
    scope: "world",
    config: false,
    type: String,
    default: CINEMATIC_PRESETS.CINEMATIC,
    choices: {
      [CINEMATIC_PRESETS.OFF]: "BATTLE_REPLAY.library.directorOff",
      [CINEMATIC_PRESETS.TACTICAL]: "BATTLE_REPLAY.library.directorTactical",
      [CINEMATIC_PRESETS.CINEMATIC]: "BATTLE_REPLAY.library.directorCinematic",
      [CINEMATIC_PRESETS.CREATOR]: "BATTLE_REPLAY.library.directorCreator"
    },
    requiresReload: false
  });

  game.settings.register(MODULE_ID, SETTINGS.CINEMATIC_ENABLED, {
    name: "BATTLE_REPLAY.settings.cinematicEnabled.name",
    hint: "BATTLE_REPLAY.settings.cinematicEnabled.hint",
    scope: "world",
    config: false,
    type: Boolean,
    default: true,
    requiresReload: false
  });

  game.settings.register(MODULE_ID, SETTINGS.CREATOR_FORMAT, {
    name: "BATTLE_REPLAY.settings.creatorFormat.name",
    hint: "BATTLE_REPLAY.settings.creatorFormat.hint",
    scope: "world",
    config: false,
    type: String,
    default: CREATOR_FORMATS.AUTO,
    choices: {
      [CREATOR_FORMATS.AUTO]: "BATTLE_REPLAY.library.creatorFormatAuto",
      [CREATOR_FORMATS.LANDSCAPE]: "BATTLE_REPLAY.library.creatorFormatLandscape",
      [CREATOR_FORMATS.VERTICAL]: "BATTLE_REPLAY.library.creatorFormatVertical"
    },
    requiresReload: false
  });

  game.settings.register(MODULE_ID, SETTINGS.LIBRARY_THEME, {
    scope: "client",
    config: false,
    type: String,
    default: "dark"
  });

  game.settings.register(MODULE_ID, SETTINGS.REPLAYS, {
    scope: "world",
    config: false,
    type: String,
    default: "[]"
  });

  game.settings.register(MODULE_ID, SETTINGS.ACTIVE_RECORDING, {
    scope: "world",
    config: false,
    type: String,
    default: ""
  });

  game.settings.register(MODULE_ID, SETTINGS.CHECKPOINT_INTERVAL, {
    name: "BATTLE_REPLAY.settings.checkpointInterval.name",
    hint: "BATTLE_REPLAY.settings.checkpointInterval.hint",
    scope: "world",
    config: true,
    type: Number,
    default: 5,
    range: {
      min: LIMITS.MIN_CHECKPOINT_INTERVAL,
      max: LIMITS.MAX_CHECKPOINT_INTERVAL,
      step: 1
    },
    requiresReload: false
  });

  game.settings.register(MODULE_ID, SETTINGS.DATA_FOLDER_ID, {
    scope: "world",
    config: false,
    type: String,
    default: ""
  });

  game.settings.register(MODULE_ID, SETTINGS.STORAGE_VERSION, {
    scope: "world",
    config: false,
    type: Number,
    default: 1
  });
}
