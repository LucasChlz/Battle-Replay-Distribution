import { LIMITS, REPLAY_SCHEMA_VERSION } from "./constants.mjs";

export function migrateReplay(source) {
  if (!source || typeof source !== "object" || Array.isArray(source)) return null;

  let replay;
  try {
    replay = JSON.parse(JSON.stringify(source));
  } catch {
    return null;
  }
  const version = Number(replay.schemaVersion ?? 1);
  if (!Number.isInteger(version) || version < 1 || version > REPLAY_SCHEMA_VERSION) {
    return null;
  }

  replay.schemaVersion = REPLAY_SCHEMA_VERSION;
  replay.title = String(replay.title ?? replay.sceneName ?? "Battle Replay").trim() || "Battle Replay";
  replay.tags = sanitizeStringArray(replay.tags);
  replay.favorite = Boolean(replay.favorite);
  replay.tokens = Array.isArray(replay.tokens)
    ? replay.tokens.map(migrateTokenSnapshot).filter(Boolean)
    : [];
  replay.events = Array.isArray(replay.events) ? replay.events : [];
  replay.metadata = {
    ...(replay.metadata && typeof replay.metadata === "object" ? replay.metadata : {}),
    ...summarizeReplay(replay)
  };

  return replay;
}

export function validateReplay(source) {
  const replay = migrateReplay(source);
  if (!replay) return { valid: false, reason: "schema" };
  if (JSON.stringify(replay).length > LIMITS.MAX_IMPORT_BYTES) {
    return { valid: false, reason: "size" };
  }

  const requiredStrings = ["id", "sceneId", "sceneName", "title"];
  if (requiredStrings.some((key) => typeof replay[key] !== "string" || !replay[key])) {
    return { valid: false, reason: "identity" };
  }

  if (!Number.isFinite(Number(replay.startedAt))) {
    return { valid: false, reason: "time" };
  }

  if (replay.events.length > LIMITS.MAX_EVENTS_PER_REPLAY) {
    return { valid: false, reason: "event-limit" };
  }

  const eventSequences = new Set();
  for (const event of replay.events) {
    if (!event || typeof event.type !== "string") return { valid: false, reason: "event" };
    const sequence = Number(event.sequence);
    if (!Number.isInteger(sequence) || sequence < 0 || eventSequences.has(sequence)) {
      return { valid: false, reason: "sequence" };
    }
    eventSequences.add(sequence);
  }

  replay.events.sort((left, right) => left.sequence - right.sequence);
  return { valid: true, replay };
}

export function summarizeReplay(replay) {
  const events = Array.isArray(replay.events) ? replay.events : [];
  const tokens = Array.isArray(replay.tokens) ? replay.tokens : [];
  const eventCounts = {};
  let rounds = 0;
  let actionCount = 0;

  for (const event of events) {
    eventCounts[event.type] = (eventCounts[event.type] ?? 0) + 1;
    const round = Number(event.data?.current?.round ?? event.data?.round);
    if (Number.isFinite(round)) rounds = Math.max(rounds, round);
    if ([
      "item-use",
      "attack-result",
      "damage-roll",
      "damage",
      "healing",
      "condition-added",
      "condition-changed",
      "condition-removed",
      "combatant-defeated",
      "visual-effect"
    ].includes(event.type)) {
      actionCount += 1;
    }
  }

  return {
    actionCount,
    duration: Math.max(0, Number(replay.endedAt ?? replay.startedAt) - Number(replay.startedAt)),
    eventCount: events.length,
    eventCounts,
    participantCount: tokens.length,
    participants: tokens.map((token) => String(token.name ?? "Token")),
    rounds
  };
}

export function prepareReplayForSave(replay) {
  const migrated = migrateReplay(replay);
  if (!migrated) return null;
  migrated.metadata = summarizeReplay(migrated);
  return migrated;
}

function sanitizeStringArray(value) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value
    .map((entry) => String(entry ?? "").trim())
    .filter(Boolean)
    .slice(0, 20))];
}

export function migrateTokenSnapshot(source) {
  if (!source || typeof source !== "object" || Array.isArray(source)) return null;
  const token = { ...source };
  const legacyTexture = typeof token.texture === "string"
    ? token.texture
    : token.texture?.src;
  const appearance = token.appearance && typeof token.appearance === "object"
    ? { ...token.appearance }
    : {};
  const texture = cleanString(appearance.texture) ?? cleanString(legacyTexture);

  token.texture = texture;
  token.appearance = {
    ...appearance,
    texture,
    scaleX: finiteOrDefault(appearance.scaleX, 1),
    scaleY: finiteOrDefault(appearance.scaleY, 1),
    anchorX: finiteOrDefault(appearance.anchorX, 0.5),
    anchorY: finiteOrDefault(appearance.anchorY, 0.5),
    offsetX: finiteOrDefault(appearance.offsetX, 0),
    offsetY: finiteOrDefault(appearance.offsetY, 0),
    rotation: finiteOrDefault(appearance.rotation, 0),
    tint: primitiveOrNull(appearance.tint)
  };
  token.health = migrateHealthSnapshot(token.health);
  token.conditions = Array.isArray(token.conditions)
    ? token.conditions.filter((condition) => condition && typeof condition === "object")
      .map((condition) => ({ ...condition }))
    : [];
  return token;
}

function migrateHealthSnapshot(source) {
  if (!source || typeof source !== "object" || Array.isArray(source)) return null;
  const health = {
    value: finiteOrNull(source.value),
    maximum: finiteOrNull(source.maximum ?? source.max),
    temporary: finiteOrNull(source.temporary ?? source.temp),
    temporaryMaximum: finiteOrNull(source.temporaryMaximum ?? source.tempmax)
  };
  return Object.values(health).every((entry) => entry === null) ? null : health;
}

function cleanString(value) {
  if (typeof value !== "string") return null;
  return value.trim() || null;
}

function finiteOrDefault(value, fallback) {
  return finiteOrNull(value) ?? fallback;
}

function finiteOrNull(value) {
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function primitiveOrNull(value) {
  return ["string", "number"].includes(typeof value) ? value : null;
}
