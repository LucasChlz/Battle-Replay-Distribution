import { escapeHtml, localize } from "./utils.mjs";

export async function requestRecordingDecision({ automatic, scene, startedAt }) {
  const fallbackTitle = defaultReplayTitle(scene, startedAt);
  const content = [
    '<div class="battle-replay-start-form">',
    '<p>',
    localize(automatic
      ? "BATTLE_REPLAY.recordingPrompt.automaticDescription"
      : "BATTLE_REPLAY.recordingPrompt.manualDescription"),
    '</p>',
    '<div class="form-group">',
    '<label for="battle-replay-title">',
    localize("BATTLE_REPLAY.recordingPrompt.name"),
    '</label>',
    '<input id="battle-replay-title" name="replayTitle" type="text" maxlength="120" ',
    'value="',
    escapeHtml(fallbackTitle),
    '" autocomplete="off" autofocus required>',
    '<p class="hint">',
    localize("BATTLE_REPLAY.recordingPrompt.nameHint"),
    '</p>',
    '</div>',
    '</div>'
  ].join("");

  const buttons = [{
    action: "record",
    icon: "fa-solid fa-circle",
    label: localize("BATTLE_REPLAY.recordingPrompt.record"),
    default: true,
    callback: (_event, button) => {
      const title = String(
        button.form?.querySelector?.("[name='replayTitle']")?.value ?? ""
      ).trim();
      if (!title) {
        ui.notifications.warn(localize("BATTLE_REPLAY.notifications.nameRequired"));
        return false;
      }
      return { record: true, title };
    }
  }];

  if (!automatic) {
    buttons.push({
      action: "skip",
      icon: "fa-solid fa-forward",
      label: localize("BATTLE_REPLAY.recordingPrompt.skip"),
      callback: () => ({ record: false, title: null })
    });
  }

  const result = await foundry.applications.api.DialogV2.wait({
    window: {
      title: localize(automatic
        ? "BATTLE_REPLAY.recordingPrompt.automaticTitle"
        : "BATTLE_REPLAY.recordingPrompt.manualTitle")
    },
    content,
    buttons,
    modal: true,
    rejectClose: false
  });

  if (result && typeof result === "object") return result;
  return automatic
    ? { record: true, title: fallbackTitle }
    : { record: false, title: null };
}

function defaultReplayTitle(scene, startedAt) {
  return scene.name + " — " + new Date(startedAt).toLocaleString();
}
